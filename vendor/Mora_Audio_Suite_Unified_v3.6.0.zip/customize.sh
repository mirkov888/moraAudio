# Mora Audio Suite - made by Mora & Claude Code
# Mora Audio Suite v3 - MMT Extended based installer (Magisk / KernelSU / KernelSU Next / APatch)
PARTITIONS="/system_ext /mi_ext /product /odm /my_product"
PARTOVER=true

REPLACE="
"

set_permissions() {
  [ -d "$MODPATH/system/bin" ] && set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
  for f in post-fs-data.sh service.sh uninstall.sh action.sh set_audio_mode.sh get_audio_status.sh mora_cfg.sh dax_toggle.sh viper_fix.sh banner_ctl.sh report.sh setup_check.sh monitor.sh backup_ctl.sh profile_ctl.sh profile_daemon.sh bass_ctl.sh viper_status.sh nlsound_service.sh nlsound_tools.sh; do
    [ -f "$MODPATH/$f" ] && set_perm $MODPATH/$f 0 0 0755
  done
  [ -d "$MODPATH/rysound" ] && set_perm_recursive $MODPATH/rysound 0 0 0755 0644
  for f in $MODPATH/rysound/tools/*.sh $MODPATH/rysound/verify_audio.sh; do [ -f "$f" ] && set_perm $f 0 0 0755; done
  [ -f "$MODPATH/sepolicy.rule" ] && set_perm $MODPATH/sepolicy.rule 0 0 0644
}

SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
. $TMPDIR/functions.sh
