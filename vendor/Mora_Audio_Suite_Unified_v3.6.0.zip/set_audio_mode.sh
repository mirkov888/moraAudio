#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Usage: set_audio_mode.sh [audiophile|movie|power_saver|apply|tinymix_only]
#   apply          re-apply the saved mode (restarts audioserver only when a live value changed)
#   NO_RESTART=1   never restart audioserver
MODDIR="${0%/*}"
. "$MODDIR/lib/mora_lib.sh"
cfg_init

tm() {
    if type tinymix_ext >/dev/null 2>&1; then tinymix_ext set "$1" "$2" >/dev/null 2>&1
    elif type tinymix >/dev/null 2>&1; then tinymix set "$1" "$2" >/dev/null 2>&1 || tinymix "$1" "$2" >/dev/null 2>&1
    else return 1; fi
}
tm_unless_nls() { nls_sets_control "$1" || tm "$1" "$2"; }

apply_tinymix_hw() {
    type tinymix_ext >/dev/null 2>&1 || type tinymix >/dev/null 2>&1 || return 0
    tm_unless_nls "DAC Volume" "100%"
    tm_unless_nls "Headphone Playback Volume" "100%"
    if [ "$1" = power_saver ]; then
        tm_unless_nls "RX_HPH_PWR_MODE" ULP
        tm_unless_nls "WSA_COMP1 Switch" 1
        tm_unless_nls "WSA_COMP2 Switch" 1
    else
        tm_unless_nls "RX_HPH_PWR_MODE" LOHIFI
        tm_unless_nls "WSA_COMP1 Switch" 0
        tm_unless_nls "WSA_COMP2 Switch" 0
    fi
}

json() { printf '{"status":"%s","mode":"%s","message":"%s"}\n' "$1" "$2" "$3"; }

ARG="$1"
case "$ARG" in
    tinymix_only)
        apply_tinymix_hw "$(cfg_get MODE)"
        json success "$(cfg_get MODE)" "Applied ALSA mixer settings"
        exit 0 ;;
    audiophile|movie|power_saver)
        MODE="$ARG" ;;
    battery|saver) MODE=power_saver ;;
    film|video) MODE=movie ;;
    ""|apply) MODE="$(cfg_get MODE)" ;;
    *) json error "$(cfg_get MODE)" "Unknown mode"; exit 1 ;;
esac

PREV="$(cfg_get MODE)"
cfg_set MODE "$MODE"
apply_mode_props "$MODE"
apply_tinymix_hw "$MODE"
mlog "mode $PREV -> $MODE (props changed: $PROPS_CHANGED)"

RESTART=0
case "$ARG" in ""|apply) [ "$PROPS_CHANGED" = 1 ] && RESTART=1 ;; *) RESTART=1 ;; esac
[ "$NO_RESTART" = 1 ] && RESTART=0
[ "$RESTART" = 1 ] && restart_audioserver

json success "$MODE" "Switched to $MODE"
