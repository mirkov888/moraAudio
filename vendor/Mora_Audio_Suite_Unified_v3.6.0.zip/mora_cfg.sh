#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Usage: mora_cfg.sh set KEY VALUE   |   mora_cfg.sh apply   (re-apply props, restart audio only if needed)
MODDIR="${0%/*}"
. "$MODDIR/lib/mora_lib.sh"
cfg_init
case "$1" in
    set)
        if cfg_set "$2" "$3"; then
            mlog "config $2=$3"
            case "$2" in YAYANG_*) yayang_apply "$MODDIR" ;; esac
            printf '{"status":"success","key":"%s","value":"%s"}\n' "$2" "$3"
        else
            printf '{"status":"error","message":"invalid key or value"}\n'; exit 1
        fi ;;
    apply)
        apply_mode_props "$(cfg_get MODE)"
        yayang_apply "$MODDIR"
        [ "$PROPS_CHANGED" = 1 ] && [ "$NO_RESTART" != 1 ] && restart_audioserver
        printf '{"status":"success","changed":%s}\n' "$PROPS_CHANGED" ;;
    *) printf '{"status":"error","message":"usage"}\n'; exit 1 ;;
esac
