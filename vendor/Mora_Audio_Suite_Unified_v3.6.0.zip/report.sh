#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Plain-text support report (device, root, driver state, effect configs, log). Safe to paste: no serials/accounts.
MODDIR="${0%/*}"
. "$MODDIR/lib/mora_lib.sh"
cfg_init
p() { getprop "$1"; }
echo "== Mora Audio Suite report =="
echo "module: $(grep '^version=' "$MODDIR/module.prop" | cut -d= -f2) ($(date '+%F %T'))"
echo "device: $(p ro.product.manufacturer) $(p ro.product.model) / $(p ro.product.device) / $(p ro.board.platform)"
echo "rom: Android $(p ro.build.version.release) (SDK $(p ro.build.version.sdk)) $(p ro.build.display.id)"
echo "abi: $(p ro.product.cpu.abilist)"
echo "selinux: $(getenforce 2>/dev/null)"
if [ -x /data/adb/ksud ]; then echo "root: KernelSU $(timeout 3 /data/adb/ksud --version 2>/dev/null | head -n 1)"
elif [ -d /data/adb/magisk ]; then echo "root: Magisk $(magisk -V 2>/dev/null)"
elif [ -x /data/adb/apd ]; then echo "root: APatch"
else echo "root: unknown"; fi
echo
echo "== ViPER driver =="
echo "reason: $(v4a_reason "$MODDIR")"
echo "aidl_effect_hal: $(rys_aidl && echo yes || echo no)"
echo "ignore_effects: $(p ro.audio.ignore_effects)"
echo "audioserver: $(p init.svc.audioserver)"
echo "live registered configs: $(v4a_live_reg_count)"
for f in $(v4a_live_files); do echo "  $f registered=$(v4a_registered "$f" && echo yes || echo no)"; done
echo "module effect files:"; for f in $(module_effect_files "$MODDIR"); do echo "  ${f#$MODDIR/} registered=$(v4a_registered "$f" && echo yes || echo no)"; done
echo "libv4a_re.so:"; for l in /vendor/lib64/soundfx /vendor/lib/soundfx /odm/lib64/soundfx /system/lib64/soundfx; do [ -e "$l/libv4a_re.so" ] && echo "  $l ($(ls -Z "$l/libv4a_re.so" 2>/dev/null | cut -d' ' -f1))"; done
echo "module libs:"; v4a_module_libs "$MODDIR" | sed "s#^$MODDIR/#  #"
echo
echo "== Effect Hub / audio path =="
echo "hub: enabled=$(cfg_get FXHUB) safe=$(head -n 1 "$FX_SAFE" 2>/dev/null) registered=$(fx_count) fx_bits=$(fx_bits)"; sed 's/^/  /' "$FX_LIST" 2>/dev/null
for f in /*/bin/hw/*audio*; do [ -f "$f" ] && echo "  hal $f $(elf_bits "$f")-bit"; done
for pn in $(pidof android.hardware.audio.service android.hardware.audio.service-aidl 2>/dev/null) $(pidof audioserver 2>/dev/null); do
  echo "  process $pn ($(cat /proc/$pn/cmdline 2>/dev/null | tr '\0' ' ' | cut -c1-60)): maps viper=$(grep -c libv4a_re /proc/$pn/maps 2>/dev/null)"
done
echo "  audio path props: offload.disable=$(p audio.offload.disable) pcm24=$(p audio.offload.pcm.24bit.enable) deep_buffer=$(p audio.deep_buffer.media) hifi=$(p persist.vendor.audio.hifi) FXPATH=$(cfg_get FXPATH)"
echo "  audio_flinger (output threads / effect chains):"
dumpsys media.audio_flinger 2>/dev/null | awk '
  /^ *Output thread/ {show=1; n=0}
  /^ *Library / {print "    " $0}
  show && /(Output thread|Standby:|HAL format|Output devices|Effect Chains|Effect ID|UUID|Session|State|Enabled|Suspended|Registered|(yes|no) +(yes|no)|[0-9]+ +(yes|no) )/ {print "    " $0; n++}
  show && n>70 {show=0}' | cut -c1-170 | head -n 110
echo "  apps: viper=$(pm list packages 2>/dev/null | grep -iE 'viper|v4a' | tr '\n' ' ')"
echo "  running: $(pidof com.pittvandewitt.viperfx com.llsl.viper4android com.audlabs.viperfx com.wstxda.viper4android 2>/dev/null)"
echo "  logd: svc=$(getprop init.svc.logd) lines_in_buffer=$(logcat -d 2>/dev/null | wc -l)"
echo "  logcat (effects / SELinux):"
logcat -d -t 2000 2>/dev/null | grep -iE "EffectsFactory|EffectBundle|v4a|viper|effect.*(fail|error|not found)|avc: denied.*(hal_audio|audioserver)" | tail -n 20 | cut -c1-220 | sed 's/^/    /'
echo

echo "== Modules =="
for m in /data/adb/modules/*/ /data/adb/ksu/modules/*/; do
    [ -f "${m}module.prop" ] || continue
    s=on; [ -e "${m}disable" ] && s=OFF
    echo "  $(basename "$m") v$(grep '^version=' "${m}module.prop" | cut -d= -f2) [$s]$(grep -q '^metamodule=1' "${m}module.prop" && echo ' (metamodule)')"
done 2>/dev/null
echo
echo "== Config =="
for k in $CFG_KEYS; do echo "  $k=$(cfg_get "$k")"; done
echo
echo "== Log (last 40) =="
tail -n 40 "$MORA_LOG" 2>/dev/null
