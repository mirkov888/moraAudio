Effect Hub table (Mora Audio Suite - made by Mora & Claude Code)
Columns (tab separated): library file | effect name | library name | UUID | stream (music or -)
Built from the effect/UUID list of Audio Modification Library (c) Rei Ryuki, MIT licence
(original idea: Zackptg5 & ahrion). Multi-effect and Dolby DAX/DAP entries are intentionally left out.
