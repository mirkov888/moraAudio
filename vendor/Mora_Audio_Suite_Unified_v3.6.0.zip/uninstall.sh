#!/system/bin/sh
[ -s /data/adb/mora_audio_suite/profile_daemon.pid ] && kill "$(cat /data/adb/mora_audio_suite/profile_daemon.pid)" 2>/dev/null
# Mora Audio Suite - made by Mora & Claude Code
rm -rf /data/adb/sound_universal /data/misc/audio/sound_universal.conf /data/misc/audio/sound_universal.conf.tmp /data/adb/mora_audio_suite /data/adb/mora_audio_suite.log /data/adb/mora_audio_suite_viper_install.log
(
    sleep 20
    settings delete system volume_steps_music
    settings delete global safe_media_volume_enabled
    settings delete global audio_safe_csd_next_warning
    settings put global audio_safe_volume_state 1
) >/dev/null 2>&1 &
exit 0
