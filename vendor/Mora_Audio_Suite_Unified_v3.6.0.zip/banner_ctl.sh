#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Banner picker backend.
#   banner_ctl.sh set b03          use a bundled banner (webroot/banners/b03.jpg)
#   banner_ctl.sh file /sdcard/x.jpg   use your own image file
#   banner_ctl.sh put N BASE64     upload a custom banner in chunks (N=0 starts over), then: commit
#   banner_ctl.sh commit | reset | status
MODDIR="${0%/*}"
. "$MODDIR/lib/mora_lib.sh"
cfg_init
ok()  { printf '{"status":"success","choice":"%s"}\n' "$(banner_choice)"; }
err() { printf '{"status":"error","message":"%s"}\n' "$1"; exit 1; }
case "$1" in
    set)
        case "$2" in b[0-9][0-9]|rotate_daily|rotate_boot) ;; *) err "bad name" ;; esac
        case "$2" in b*) ;; *) echo "$2" > "$MORA_DATA/banner_choice"; banner_apply "$MODDIR"; ok; exit 0 ;; esac
        [ -f "$MODDIR/webroot/banners/$2.jpg" ] || err "not found"
        echo "$2" > "$MORA_DATA/banner_choice"; banner_apply "$MODDIR"; ok ;;
    file)
        [ -r "$2" ] || err "file not readable"
        cp -f "$2" "$MORA_DATA/banner_custom.jpg" || err "copy failed"
        echo custom > "$MORA_DATA/banner_choice"; banner_apply "$MODDIR"; ok ;;
    put)
        mkdir -p "$MORA_DATA"
        if [ "$2" = 0 ]; then printf '%s' "$3" > "$MORA_DATA/banner_upload.b64"
        else printf '%s' "$3" >> "$MORA_DATA/banner_upload.b64"; fi
        echo '{"status":"success"}' ;;
    commit)
        [ -s "$MORA_DATA/banner_upload.b64" ] || err "nothing uploaded"
        base64 -d "$MORA_DATA/banner_upload.b64" > "$MORA_DATA/banner_custom.tmp" 2>/dev/null; rm -f "$MORA_DATA/banner_upload.b64"
        [ -s "$MORA_DATA/banner_custom.tmp" ] || { rm -f "$MORA_DATA/banner_custom.tmp"; err "decode failed"; }
        mv -f "$MORA_DATA/banner_custom.tmp" "$MORA_DATA/banner_custom.jpg"
        echo custom > "$MORA_DATA/banner_choice"; banner_apply "$MODDIR"; ok ;;
    reset)
        rm -f "$MORA_DATA/banner_choice" "$MORA_DATA/banner_custom.jpg"; banner_apply "$MODDIR"; ok ;;
    status|"") ok ;;
    *) err "usage" ;;
esac
