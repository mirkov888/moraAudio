#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
#   backup_ctl.sh export [file]   default /sdcard/Download/mora_backup.tar.gz
#   backup_ctl.sh import [file]
MODDIR="${0%/*}"
. "$MODDIR/lib/mora_lib.sh"
cfg_init
F="${2:-/sdcard/Download/mora_backup.tar.gz}"
out() { printf '{"status":"%s","message":"%s","file":"%s"}\n' "$1" "$2" "$F"; }
case "$1" in
    export)
        mkdir -p "${F%/*}" 2>/dev/null
        rm -f "$MORA_DATA/banner_upload.b64"
        tar czf "$F" -C /data/adb mora_audio_suite 2>/dev/null && [ -s "$F" ] && out success "Cadangan dibuat" || out error "Gagal membuat cadangan" ;;
    import)
        [ -r "$F" ] || { out error "File tidak ditemukan"; exit 1; }
        bad="$(tar tzf "$F" 2>/dev/null | grep -vE '^mora_audio_suite(/|$)|^\./mora_audio_suite(/|$)' | head -n 1)"
        [ -n "$bad" ] && { out error "Isi file tidak valid"; exit 1; }
        tar tzf "$F" 2>/dev/null | grep -q '\.\./' && { out error "Path tidak aman"; exit 1; }
        tar xzf "$F" -C /data/adb 2>/dev/null || { out error "Gagal mengekstrak"; exit 1; }
        cfg_init; banner_apply "$MODDIR"
        NO_RESTART=1 sh "$MODDIR/set_audio_mode.sh" apply >/dev/null 2>&1
        sh "$MODDIR/bass_ctl.sh" apply >/dev/null 2>&1
        mlog "backup imported from $F"
        out success "Pengaturan dipulihkan. Reboot untuk menerapkan penuh." ;;
    *) out error "usage: export|import [file]"; exit 1 ;;
esac
