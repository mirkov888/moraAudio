#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
MODDIR="${0%/*}"
. "$MODDIR/lib/mora_lib.sh"
cfg_init
echo "Mora Audio Suite $(grep '^version=' "$MODDIR/module.prop" | cut -d= -f2)"
echo "Android $(getprop ro.build.version.release) / $(getprop ro.product.model)"
echo "Mode: $(cfg_get MODE)"
echo ""
sh "$MODDIR/viper_status.sh" 2>/dev/null | tr ',' '\n' | sed 's/[{}"]//g'
echo ""
echo "Duplicate modules enabled: $(conflict_scan | tr '\n' ' ')"
echo "Open the WebUI for controls and the full status."
echo "Log: $MORA_LOG"
