# Mora Audio Suite Unified v3.5

One module for KernelSU / KernelSU Next / APatch / Magisk (Android 8+), built from:

- **ViPER4Android RE driver** (libv4a_re, registered in every audio_effects config, 64/32-bit)
- **NLSound v4.5** (Qualcomm) - patched to be ViPER-safe, with an Indonesian installer and a "Mora recommended" preset
- **Audio misc. settings v1.3.12** - USB period, de-spatialized Bluetooth policy, safe-volume / spatializer / volume-listener / AOC tweaks
- **RySound v0.7.0** - software DSP effect (20-band EQ, bass, vocal, stereo width, compressor, limiter) for legacy/HIDL audio HALs. Registered next to ViPER in the same overlays; its DSP is **off** until you turn it on in its page (Tuning > Buka pengaturan RySound). On AIDL-HAL devices (Android 14+) only the settings page is available.
- **Dolby DAX switch** (only on Redmi Note 10 Pro (sweet) with a Dolby ROM, `dms-hal-2-0` + `/vendor/etc/dolby/dax-default.xml`) - swap dax-default.xml between stock, a new config and four bottom-speaker balance levels (-3/-6/-9/-12 dB) from Tuning, no reflash. The original file is backed up once to `/data/adb/dax_toggle/stock.xml`. Variants were built on a Redmi Note 10 Pro (sweet) ROM; on other ROMs the WebUI warns that they replace the whole Dolby tuning.
- **BassBoost** (system app, global bass boost / low-band dynamics / loudness on the output mix, Android 13+) - controlled from the Bass & Loudness card in Tuning or from the Mora Audio app. All effects are off until you turn them on. Saved values are re-sent at every boot.
- **Mora WebUI** - Listen (modes), Sound (10-band EQ helper), Tuning (toggles, NLSound summary, diagnostics), System (driver status)

## Install
Flash the zip, choose the NLSound option with the volume keys (VOL+ next, VOL- select; 45 s idle = Mora recommended), reboot, then install the ViPER4Android RE app.
Standalone NLSound / Audio misc. / ViPER RE modules are disabled automatically (they would conflict).

## RySound safety
If boot fails twice or the audio process crashes in libsounduniversal, only RySound is removed from the overlays (safe mode); ViPER and everything else stay. Leave safe mode from the RySound page. Turn the hook off permanently in Tuning (needs a reboot).

## Notes
- `NLSound "disable all effects"` is blocked: it would kill the ViPER driver.
- Config lives in `/data/adb/mora_audio_suite/mora.conf`; log in `/data/adb/mora_audio_suite.log`.
- Tested by script simulation (KSU and Magisk layouts), not on a physical device.

Made by Mora & Claude Code. Components bundled from other open projects and their licenses are listed in THIRD_PARTY_NOTICES.md (the AGPL-3.0 text is in LICENSE).

## v3.4 - perbaikan "driver not found" ViPER
- `viper_fix.sh [diag|fix]`: menentukan penyebab (`not_mounted`, `not_registered`, `ignore_effects`, `not_loaded`, ...) dan memperbaiki: relabel SELinux, bind-mount config/library bila overlay root manager tidak ter-mount, restart audioserver.
- `service.sh` menjalankan pemeriksaan + perbaikan otomatis setelah boot.
- Aturan sepolicy tambahan untuk audioserver / audio HAL.
- Tombol **Perbaiki driver ViPER** di WebUI dan aplikasi.

### Banner
15 banner bawaan di `webroot/banners/`. Ganti lewat WebUI → tab **Sistem** → **Banner** (pilih thumbnail, **Pilih dari galeri**, atau **Kembalikan bawaan**). Pilihan disimpan di `/data/adb/mora_audio_suite/banner_choice` dan dipasang ulang tiap boot, jadi tetap ada setelah update module. CLI: `banner_ctl.sh set b05 | file /sdcard/x.jpg | reset`.

## Pemecahan masalah "Driver not found" (dari laporan pengguna lain)
Perbaikan v3.4 disusun dari kasus nyata di tempat lain:
- Config `audio_effects` yang sudah di-patch tidak pernah ter-mount (mis. `/odm` simbolik di ColorOS) → modul sekarang mengecek config *live* dan memasangnya lewat bind-mount bila perlu. ([ViPERFX_RE #36](https://github.com/likelikeslike/ViPERFX_RE/issues/36))
- audioserver start pertama setelah boot belum mendaftarkan efek → modul menunggu (polling) lalu restart sekali lagi, bukan `sleep` tetap. ([ViPERFX_RE #31](https://github.com/likelikeslike/ViPERFX_RE/issues/31))
- Metamodule / Hybrid Mount memblokir modul → di KernelSU 3.x tanpa metamodule, file modul tidak di-mount sama sekali. ([ViPERFX_RE #29](https://github.com/likelikeslike/ViPERFX_RE/issues/29), [dokumentasi KernelSU](https://kernelsu.org/guide/metamodule.html))
- Dua build ViPER aktif bersamaan (UUID sama) saling bentrok → terdeteksi sebagai `other_viper`.
- HAL efek AIDL tidak memuat driver HIDL `libv4a_re` → terdeteksi sebagai `aidl_hal`.

## v3.5 (rencana: ditandai v3.4 di zip) - fitur tambahan
`report.sh` (laporan diagnosa), `setup_check.sh` (cek pemasangan), `monitor.sh` (baterai/suhu), `backup_ctl.sh` (ekspor/impor), `profile_ctl.sh` + `profile_daemon.sh` (mode per aplikasi), rotasi banner (`banner_ctl.sh set rotate_daily|rotate_boot`), warna aksen dari banner, nada tes, dan cek pembaruan GitHub di WebUI.


### Profil Yayang (opsional, mati secara bawaan)
Tab Tuning → **Profil Yayang**: *Sony+* dan *Speaker V2* (properti dari modul YayangProject, disaring), serta slider gain speaker/headphone 0-10 untuk kernel yang punya `sound_control`. Perubahan properti kembali normal setelah reboot bila dimatikan. Modul Yayang asli bentrok dengan Mora (mengubah SELinux ke permissive), jadi dideteksi sebagai konflik; hapus keduanya.


## v3.6 - fokus ViPER, tanpa Dolby Atmos
- **Effect Hub** (pengganti AML): Mora memindai modul lain yang aktif, mencari library efek yang dikenal (JamesDSP, Dirac, Arkamys, MaxxAudio, DTS, dan lainnya; daftar di `fxhub/libs.tsv`), lalu mendaftarkannya di satu file audio_effects milik Mora. Jangan pasang modul AML terpisah: dua modul yang menulis ulang file yang sama saling menimpa, jadi Mora menonaktifkan `aml` bila ditemukan.
- Pendaftaran aman: file disalin dulu, tag XML dicek seimbang, ukuran tambahan dibatasi, dan gagal berarti file asli tidak diubah. UUID yang sudah dimiliki ROM tidak didaftarkan dua kali. Entri modul yang sudah dimatikan atau dihapus dibersihkan otomatis saat boot.
- Pengaman boot: tiga boot berturut-turut yang tidak selesai mematikan Effect Hub sendiri (`/data/adb/mora_audio_suite/fx_safe`).
- **Jalur efek** (FXPATH, bawaan hidup): mematikan offload audio supaya ViPER dan efek lain tidak dilewati.
- **Dolby Atmos Magic Revision dihapus** dari modul (tidak lagi dibawa di build ini maupun berikutnya). Sisa data lama dibersihkan otomatis. Modul `Atmos` dan `aml` yang berdiri sendiri tetap dinonaktifkan Mora karena menimpa file efek yang sama dengan ViPER.
- Laporan (WebUI > Sistem > Salin laporan) menampilkan HAL audio, efek yang aktif, dan status layanan log.
