#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# One-tap ViPER driver repair. Usage: viper_fix.sh [diag|fix]   (prints one JSON line)
MODDIR="${0%/*}"
. "$MODDIR/lib/mora_lib.sh"
cfg_init
act="${1:-fix}"
before="$(v4a_reason "$MODDIR")"; fixed=0; after="$before"
if [ "$act" = fix ]; then
    mlog "viper_fix: start (reason=$before)"
    if [ "$before" = ignore_effects ]; then prop_set ro.audio.ignore_effects false; fixed=1; fi
    # re-register in the module overlays first (ROM update / other module may have replaced them)
    v4a_refresh "$MODDIR"
    n="$(v4a_ensure "$MODDIR")"; [ "${n:-0}" -gt 0 ] && fixed=$((fixed + n))
    if [ "$before" != ok ]; then
        V4A_ENGINE= v4a_restart_and_wait
        fixed=$((fixed + 1))
    fi
    after="$(v4a_reason "$MODDIR")"
    mlog "viper_fix: done (reason=$after)"
fi
case "$after" in
    ok) hint="Driver aktif. Buka ViPER4Android lalu putar musik." ;;
    no_module_lib) hint="Library ViPER tidak ada di modul. Flash ulang modul." ;;
    ignore_effects) hint="ro.audio.ignore_effects=true mematikan efek. Matikan opsi Tanpa efek lalu reboot." ;;
    not_mounted) hint="Root manager tidak me-mount file modul. KernelSU 3.x butuh metamodule (mis. meta-overlayfs); jika memakai Hybrid Mount, hapus modul ini dari blacklist-nya. Lalu reboot." ;;
    other_viper) hint="Ada modul ViPER lain yang aktif. Nonaktifkan atau hapus, lalu reboot." ;;
    aidl_hal) hint="HAL efek audio perangkat ini AIDL; driver HIDL libv4a_re tidak dimuat. Perlu build ViPER versi AIDL." ;;
    not_registered) hint="Konfigurasi audio_effects ROM tidak memuat ViPER. Reboot lalu jalankan perbaikan lagi." ;;
    no_audioserver) hint="audioserver tidak berjalan. Reboot." ;;
    not_loaded) hint="Terdaftar tapi belum dimuat. Reboot sekali; jika tetap, SELinux memblokir (lihat log)." ;;
    *) hint="" ;;
esac
printf '{"before":"%s","after":"%s","repairs":%s,"hint":"%s"}\n' "$before" "$after" "$fixed" "$hint"
