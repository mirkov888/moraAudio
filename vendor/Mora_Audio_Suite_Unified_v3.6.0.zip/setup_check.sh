#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Installation checklist as JSON: {"items":[{"id","title","status":"ok|warn|bad","detail"}]}
MODDIR="${0%/*}"
. "$MODDIR/lib/mora_lib.sh"
cfg_init
J=""
js() { printf '%s' "$1" | tr -d '"\\\r\n'; }
item() { J="${J}${J:+,}{\"id\":\"$1\",\"title\":\"$(js "$2")\",\"status\":\"$3\",\"detail\":\"$(js "$4")\"}"; }

root=unknown
if [ -x /data/adb/ksud ]; then root=ksu; elif [ -d /data/adb/magisk ]; then root=magisk; elif [ -x /data/adb/apd ]; then root=apatch; fi
case "$root" in
    ksu) item root "Root manager" ok "KernelSU" ;;
    magisk) item root "Root manager" ok "Magisk" ;;
    apatch) item root "Root manager" ok "APatch" ;;
    *) item root "Root manager" warn "Tidak dikenali" ;;
esac

# KernelSU 3.x mounts nothing unless a metamodule is installed
if [ "$root" = ksu ]; then
    meta=""
    for m in /data/adb/modules/*/ /data/adb/ksu/modules/*/; do
        [ -e "${m}disable" ] && continue
        grep -q '^metamodule=1' "${m}module.prop" 2>/dev/null && meta="$(basename "$m")"
    done
    if [ -n "$meta" ]; then item meta "Metamodule mount" ok "$meta aktif"
    else item meta "Metamodule mount" warn "Tidak ada metamodule. KernelSU 3.x tidak me-mount modul tanpanya; pasang meta-overlayfs jika file modul tidak muncul. Mora tetap mencoba bind-mount cadangan."; fi
    bl=""
    for t in /data/adb/modules/*/module_blacklist.toml /data/adb/modules/*/*blacklist*; do
        [ -f "$t" ] && grep -q "mora_audio_suite" "$t" 2>/dev/null && bl="$t"
    done 2>/dev/null
    [ -n "$bl" ] && item blacklist "Blacklist mount" bad "mora_audio_suite ada di $bl. Hapus dari blacklist lalu reboot."
fi

[ -e "$MODDIR/disable" ] && item enabled "Modul aktif" bad "Modul dinonaktifkan di manager" || item enabled "Modul aktif" ok "Aktif"
[ "$(getprop sys.boot_completed)" = 1 ] && item boot "Boot selesai" ok "Ya" || item boot "Boot selesai" warn "Belum"

rys_aidl && hal="AIDL" || hal="HIDL/XML"
if [ "$hal" = AIDL ]; then item hal "HAL efek audio" warn "AIDL. Driver HIDL libv4a_re tidak dimuat; butuh build ViPER AIDL."
else item hal "HAL efek audio" ok "$hal"; fi

r="$(V4A_ENGINE= v4a_reason "$MODDIR")"
case "$r" in
    ok) item viper "Driver ViPER" ok "Aktif" ;;
    not_loaded|not_registered|not_mounted) item viper "Driver ViPER" bad "$r. Tekan Perbaiki driver ViPER." ;;
    other_viper) item viper "Driver ViPER" bad "Ada modul ViPER lain yang aktif." ;;
    *) item viper "Driver ViPER" warn "$r" ;;
esac

c="$(conflict_scan | tr '\n' ' ')"
[ -n "$c" ] && item conflict "Modul bentrok" warn "Terdeteksi: $c" || item conflict "Modul bentrok" ok "Tidak ada"
se="$(getenforce 2>/dev/null)"; item selinux "SELinux" ok "${se:-?}"
if pm path dev.kazuyoo.bassboost >/dev/null 2>&1; then item bass "Aplikasi BassBoost" ok "Terpasang"
else item bass "Aplikasi BassBoost" warn "Belum terpasang. Reboot sekali setelah flash."; fi
printf '{"items":[%s]}\n' "$J"
