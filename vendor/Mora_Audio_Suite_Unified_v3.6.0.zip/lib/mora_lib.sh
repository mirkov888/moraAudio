# Mora Audio Suite - made by Mora & Claude Code
# Mora Audio Suite runtime library (POSIX sh; sourced by boot scripts, WebUI helpers and the installer)
MORA_DATA=/data/adb/mora_audio_suite
MORA_CONF="$MORA_DATA/mora.conf"
MORA_LOG=/data/adb/mora_audio_suite.log
dax_ns() { if command -v nsenter >/dev/null 2>&1; then nsenter -t 1 -m -- "$@"; else "$@"; fi; }
export PATH="/system/bin:/system/xbin:/vendor/bin:/data/adb/ksu/bin:/data/adb/ap/bin:/data/adb/magisk:$PATH"

mlog() { mkdir -p /data/adb 2>/dev/null; echo "[$(date '+%H:%M:%S')] $*" >> "$MORA_LOG" 2>/dev/null; }

# ---------------------------------------------------------------- config
# Defaults (1 = on). NOEFFECTS must stay 0 while ViPER is used.
CFG_KEYS="MODE YAYANG_SONY YAYANG_V2 YAYANG_SPK_GAIN YAYANG_HP_GAIN RYSOUND FXHUB FXPATH VOLSTEPS100 SAFEVOL_OFF SPATIALIZER_OFF VOLLISTENER_OFF DOLBY_OFF NOEFFECTS USB_PERIOD AOC_STOP GUARD RESTART_BOOT BB_BASS BB_STRENGTH BB_LOUDNESS BB_TARGET BB_DP BB_GAIN"
cfg_default() {
    case "$1" in
        MODE) echo audiophile ;;
        VOLSTEPS100|SAFEVOL_OFF|SPATIALIZER_OFF|VOLLISTENER_OFF|DOLBY_OFF|AOC_STOP|GUARD|RESTART_BOOT|RYSOUND|FXHUB|FXPATH) echo 1 ;;
        NOEFFECTS|BB_BASS|BB_LOUDNESS|BB_DP|YAYANG_SONY|YAYANG_V2|YAYANG_SPK_GAIN|YAYANG_HP_GAIN) echo 0 ;;
        BB_STRENGTH) echo 600 ;;
        BB_TARGET) echo 300 ;;
        BB_GAIN) echo 4 ;;
        USB_PERIOD) echo auto ;;
        *) echo "" ;;
    esac
}
cfg_valid() {
    case "$1" in
        MODE) case "$2" in audiophile|movie|power_saver) return 0 ;; esac ;;
        BB_STRENGTH) case "$2" in ''|*[!0-9]*) return 1 ;; esac; [ "$2" -le 1000 ] && return 0 ;;
        BB_TARGET) case "$2" in ''|*[!0-9]*) return 1 ;; esac; [ "$2" -le 1000 ] && return 0 ;;
        BB_GAIN) case "$2" in ''|*[!0-9]*) return 1 ;; esac; [ "$2" -le 15 ] && return 0 ;;
        BB_BASS|BB_LOUDNESS|BB_DP|YAYANG_SONY|YAYANG_V2) case "$2" in 0|1) return 0 ;; esac ;;
        YAYANG_SPK_GAIN|YAYANG_HP_GAIN) case "$2" in ''|*[!0-9]*) return 1 ;; esac; [ "$2" -le 10 ] && return 0 ;;
        USB_PERIOD) case "$2" in auto) return 0 ;; ''|*[!0-9]*) return 1 ;; esac
                    [ "$2" -ge 500 ] && [ "$2" -le 20000 ] && return 0 ;;
        VOLSTEPS100|SAFEVOL_OFF|SPATIALIZER_OFF|VOLLISTENER_OFF|DOLBY_OFF|NOEFFECTS|AOC_STOP|GUARD|RESTART_BOOT|RYSOUND|FXHUB|FXPATH)
            case "$2" in 0|1) return 0 ;; esac ;;
    esac
    return 1
}
cfg_get() {
    local v=""
    [ -r "$MORA_CONF" ] && v="$(grep "^$1=" "$MORA_CONF" 2>/dev/null | tail -n 1 | cut -d= -f2- | tr -d ' \r\n')"
    if [ -n "$v" ] && cfg_valid "$1" "$v"; then echo "$v"; else cfg_default "$1"; fi
}
cfg_set() {
    cfg_valid "$1" "$2" || return 1
    mkdir -p "$MORA_DATA" 2>/dev/null
    local tmp="$MORA_CONF.tmp.$$"
    { [ -r "$MORA_CONF" ] && grep -v "^$1=" "$MORA_CONF"; echo "$1=$2"; } > "$tmp" 2>/dev/null && mv -f "$tmp" "$MORA_CONF"
    chmod 0600 "$MORA_CONF" 2>/dev/null
    return 0
}
cfg_init() {
    mkdir -p "$MORA_DATA" 2>/dev/null
    if [ ! -f "$MORA_CONF" ]; then
        local old=""
        for f in "$MODDIR/mode.conf" /data/adb/modules/mora_audio_suite/mode.conf; do
            [ -r "$f" ] && old="$(grep '^MODE=' "$f" | cut -d= -f2 | tr -d ' \r\n')" && break
        done
        { for k in $CFG_KEYS; do
            v="$(cfg_default "$k")"
            [ "$k" = MODE ] && cfg_valid MODE "$old" && v="$old"
            # a ROM that ships Dolby keeps it unless the user turns it off
            [ "$k" = DOLBY_OFF ] && dolby_present && v=0
            echo "$k=$v"
          done; } > "$MORA_CONF"
        chmod 0600 "$MORA_CONF" 2>/dev/null
    fi
    sed -i '/^ATMOS/d' "$MORA_CONF" 2>/dev/null
    # one-time repair (v3.5): older versions could save DOLBY_OFF=1 on a ROM that ships Dolby, which hides the
    # Dolby app's service and makes it fail to open. Put the ROM's Dolby back; the user can switch it off again.
    if [ ! -f "$MORA_DATA/dolby_fix_v35" ] && [ -f "$MORA_CONF" ] && dolby_present; then
        sed -i 's/^DOLBY_OFF=1$/DOLBY_OFF=0/' "$MORA_CONF"
        echo done > "$MORA_DATA/dolby_fix_v35" 2>/dev/null
    fi
}

# NLSound choices saved by the installer (settings.nls inside the module)
nls_get() {
    local f="$MODDIR/settings.nls"
    [ -r "$f" ] || { echo ""; return; }
    grep "^$1=" "$f" 2>/dev/null | tail -n 1 | cut -d= -f2- | tr -d ' \r\n"'
}
nls_sets_control() {
    # true when NLSound's tinymix_ext list already sets this ALSA control (Mora then leaves it alone)
    [ -r "$MODDIR/nlsound_service.sh" ] && grep -q "set \"$1\"" "$MODDIR/nlsound_service.sh" 2>/dev/null
}

# ---------------------------------------------------------------- props
which_resetprop() {
    if type resetprop >/dev/null 2>&1; then echo resetprop
    elif [ -x /data/adb/ksu/bin/resetprop ]; then echo /data/adb/ksu/bin/resetprop
    elif [ -x /data/adb/ap/bin/resetprop ]; then echo /data/adb/ap/bin/resetprop
    elif [ -x /data/adb/magisk/resetprop ]; then echo /data/adb/magisk/resetprop
    elif type resetprop_phh >/dev/null 2>&1; then echo resetprop_phh
    else echo ""; fi
}
RP="$(which_resetprop)"
prop_set() {
    if [ -n "$RP" ]; then
        case "$1" in
            ro.*) "$RP" --delete "$1" >/dev/null 2>&1; "$RP" -n "$1" "$2" >/dev/null 2>&1 || "$RP" "$1" "$2" >/dev/null 2>&1 ;;
            *)    "$RP" -n "$1" "$2" >/dev/null 2>&1 || "$RP" "$1" "$2" >/dev/null 2>&1 ;;
        esac
    else
        case "$1" in ro.*) return 1 ;; esac
        setprop "$1" "$2" >/dev/null 2>&1
    fi
}
prop_del() { [ -n "$RP" ] && "$RP" --delete "$1" >/dev/null 2>&1; return 0; }

# Platform profile (values from the Audio Misc module, per SoC / Android version)
platform_profile() {
    local board sdk
    board="$(getprop ro.board.platform)"
    sdk="$(getprop ro.build.version.sdk)"; case "$sdk" in ''|*[!0-9]*) sdk=34 ;; esac
    PSD_EN=44100; PSD_STOP=179; PSD_HALF=408; PSD_TBW=99; PSD_CUT=""; USB_P=2000
    case "$board" in
        pineapple) PSD_STOP=194; PSD_HALF=520; PSD_TBW=98 ;;
        kona|kalama|shima|yupik) USB_P=4000 ;;
        gs*|zuma*|laguna*|malibu*) PSD_EN=48000; PSD_STOP=194; PSD_HALF=520; PSD_TBW=83 ;;
    esac
    if [ -z "$(getprop ro.product.cpu.abilist64)" ]; then
        PSD_EN=48000; PSD_STOP=165; PSD_HALF=360; PSD_TBW=104; USB_P=2250
    fi
    # Android 11 and older: AudioFlinger's resampler aliases near Nyquist, use a safer transition band
    if [ "$sdk" -le 30 ]; then PSD_STOP=159; PSD_HALF=480; PSD_TBW=""; PSD_CUT=92; fi
    local up="$(cfg_get USB_PERIOD)"
    [ "$up" != auto ] && USB_P="$up"
    return 0
}

# Prints the full property plan for a mode: "set key value" / "del key"
mode_props() {
    local mode="$1" buf adm deepbuf hifi rq standby
    platform_profile
    case "$mode" in
        power_saver) deepbuf=true;  adm=10; hifi=false; rq=4; standby=60 ;;
        movie)       deepbuf=true;  adm=10; hifi=true;  rq=7; standby=200 ;;
        *)           deepbuf=false; adm=2;  hifi=true;  rq=7; standby=200; mode=audiophile ;;
    esac
    echo "set audio.deep_buffer.media $deepbuf"
    echo "set vendor.audio.adm.buffering.ms $adm"
    echo "set persist.vendor.audio.hifi $hifi"
    echo "set persist.vendor.audio.hifi.int_codec $hifi"
    echo "set af.resampler.quality $rq"
    echo "set ro.audio.flinger_standbytime_ms $standby"
    if [ "$(cfg_get FXPATH)" = 1 ]; then
        # effects (ViPER, Dolby, hub) only run on mixer outputs: PCM/compress offload streams skip them
        echo "set audio.offload.pcm.24bit.enable false"
        echo "set audio.offload.pcm.16bit.enable false"
        echo "set audio.offload.disable true"
    else
        echo "set audio.offload.pcm.24bit.enable true"
        echo "del audio.offload.pcm.16bit.enable"
        echo "del audio.offload.disable"
    fi
    if [ "$mode" = power_saver ]; then
        for k in enable_at_samplerate stopband halflength tbwcheat cutoff_percent; do echo "del ro.audio.resampler.psd.$k"; done
    else
        echo "set ro.audio.resampler.psd.enable_at_samplerate $PSD_EN"
        echo "set ro.audio.resampler.psd.stopband $PSD_STOP"
        echo "set ro.audio.resampler.psd.halflength $PSD_HALF"
        if [ -n "$PSD_TBW" ]; then echo "set ro.audio.resampler.psd.tbwcheat $PSD_TBW"; echo "del ro.audio.resampler.psd.cutoff_percent"
        else echo "set ro.audio.resampler.psd.cutoff_percent $PSD_CUT"; echo "del ro.audio.resampler.psd.tbwcheat"; fi
    fi
    echo "set vendor.audio.usb.perio $USB_P"
    echo "set vendor.audio.usb.out.period_us $USB_P"
    echo "set vendor.audio.usb.out.period_count 2"
    echo "set vendor.audio_hal.period_size 120"
    echo "set vendor.audio_hal.period_multiplier 1"
    echo "set persist.bluetooth.sbc_hd_higher_bitrate 1"
    if [ "$(cfg_get SAFEVOL_OFF)" = 1 ]; then
        echo "set audio.safemedia.bypass true"; echo "set audio.safemedia.force false"; echo "set audio.safemedia.csd.force false"
    else
        echo "del audio.safemedia.bypass"; echo "del audio.safemedia.force"; echo "del audio.safemedia.csd.force"
    fi
    if [ "$(cfg_get SPATIALIZER_OFF)" = 1 ] || [ "$(nls_get STEP12)" = part ]; then echo "set ro.audio.spatializer_enabled false"; fi
    if [ "$(cfg_get DOLBY_OFF)" = 1 ] && [ "$(dax_state)" = stock ]; then
        echo "set ro.vendor.audio.dolby.dax.support false"
        echo "set vendor.audio.dolby.control.support false"
        echo "set persist.audio.dolby.enabled false"
    fi
    local steps="$(nls_get VOLSTEPS)"
    case "$steps" in ''|*[!0-9]*) steps=""; [ "$(cfg_get VOLSTEPS100)" = 1 ] && steps=100 ;; esac
    if [ -n "$steps" ]; then
        # HyperOS / Motorola stock ROMs ignore this property
        local miui="$(getprop ro.miui.ui.version.code)" moto="$(getprop ro.mot.build.customerid)"
        local rel="$(getprop ro.system.build.version.release)"; case "$rel" in ''|*[!0-9]*) rel=0 ;; esac
        if { [ -n "$miui" ] && [ "$miui" -ge 14 ] 2>/dev/null; } || { [ -n "$moto" ] && [ "$rel" -ge 15 ]; }; then :; else
            echo "set ro.config.media_vol_steps $steps"
        fi
    fi
    # ViPER and the effects framework are mutually exclusive
    if [ "$(cfg_get NOEFFECTS)" = 1 ]; then echo "set ro.audio.ignore_effects true"; fi
}

# Applies the plan. Sets PROPS_CHANGED=1 when a live value actually differed.
apply_mode_props() {
    PROPS_CHANGED=0
    mode_props "$1" | while read -r op k v; do
        case "$op" in
            set) [ "$(getprop "$k")" = "$v" ] || { prop_set "$k" "$v"; echo "$k" >> "$MORA_DATA/.changed.$$"; } ;;
            del) [ -n "$(getprop "$k")" ] && { prop_del "$k"; echo "$k" >> "$MORA_DATA/.changed.$$"; } ;;
        esac
    done
    if [ -s "$MORA_DATA/.changed.$$" ]; then PROPS_CHANGED=1; mlog "props changed: $(tr '\n' ' ' < "$MORA_DATA/.changed.$$")"; fi
    rm -f "$MORA_DATA/.changed.$$" 2>/dev/null
}

restart_audioserver() {
    [ -n "$(getprop init.svc.audioserver)" ] || return 0
    setprop ctl.restart audioserver
    sleep 1.2
    if [ "$(getprop init.svc.audioserver)" != "running" ]; then
        local pid="$(getprop init.svc_debug_pid.audioserver)"
        [ -n "$pid" ] && kill -HUP "$pid" >/dev/null 2>&1
    fi
}

# ---------------------------------------------------------------- conflicts
# Standalone modules that this suite already contains. Running both causes duplicate overlays and
# competing system.prop values (audio-misc/NLSound can even disable the effect framework ViPER needs).
CONFLICT_IDS="YayangProjectAudioSony+ Yayang_Audio_V2 NLSound audio-misc-settings audio-misc-settings-ksu-webui ViPER4Android-RE-Fork ViPER4Android-RE sound_universal dax_toggle_sweet BB aml Atmos"
conflict_scan() {
    for id in $CONFLICT_IDS; do
        d="/data/adb/modules/$id"
        [ -d "$d" ] || continue
        [ -e "$d/remove" ] && continue
        echo "$id"
    done
}
conflict_disable() {
    for id in $(conflict_scan); do
        d="/data/adb/modules/$id"
        if [ ! -e "$d/disable" ]; then
            touch "$d/disable" && mlog "conflict guard: disabled duplicate module $id (reboot to apply)"
            echo "$id"
        fi
    done
}

# ---------------------------------------------------------------- ViPER registration
V4A_UUID=90380da3-8536-4744-a6a3-5731970e640f
v4a_registered() { grep -q 'v4a_standard_re' "$1" 2>/dev/null && grep -q 'v4a_re' "$1" 2>/dev/null; }
v4a_patch_xml() {
    sed -i "/v4a_standard_re/d" "$1"
    sed -i "/v4a_re/d" "$1"
    sed -i "/<libraries>/ a\        <library name=\"v4a_re\" path=\"libv4a_re.so\"\/>" "$1"
    sed -i "/<effects>/ a\        <effect name=\"v4a_standard_re\" library=\"v4a_re\" uuid=\"$V4A_UUID\"\/>" "$1"
    v4a_registered "$1"
}
v4a_patch_conf() {
    sed -i "/v4a_standard_re {/,/}/d" "$1"
    sed -i "/v4a_re {/,/}/d" "$1"
    sed -i "s/^libraries {/libraries {\n  v4a_re {\n    path \/vendor\/lib\/soundfx\/libv4a_re.so\n  }/g" "$1"
    sed -i "s/^effects {/effects {\n  v4a_standard_re {\n    library v4a_re\n    uuid $V4A_UUID\n  }/g" "$1"
    v4a_registered "$1"
}
v4a_patch_file() {
    case "$1" in
        *.xml)  v4a_patch_xml "$1" ;;
        *.conf) v4a_patch_conf "$1" ;;
        *) return 1 ;;
    esac
}

# module file -> the real path it overrides (system/vendor/x and vendor/x both mean /vendor/x)
real_of() {
    local rel="${1#$2}"
    case "$rel" in
        /system/vendor/*|/system/odm/*|/system/product/*|/system/system_ext/*|/system/my_product/*|/system/mi_ext/*) rel="${rel#/system}" ;;
    esac
    echo "$rel"
}
sum_of() { sha1sum "$1" 2>/dev/null | cut -d' ' -f1; }

# every audio_effects config shipped by this module
module_effect_files() {
    find "$1" \( -path "$1/webroot" -o -path "$1/common" -o -path "$1/lib" \) -prune -o -type f \( -name 'audio_effects*.xml' -o -name 'audio_effects*.conf' \) -print 2>/dev/null
}

# Boot-time safety net: keep ViPER registered in every overlay, and notice ROM updates
v4a_refresh() {
    local dir="$1" f real cur old changed=0
    [ -d "$dir" ] || return 0
    for f in $(module_effect_files "$dir"); do
        real="$(real_of "$f" "$dir")"
        cur="$(sum_of "$real")"
        old="$(grep " $real\$" "$dir/stock.sum" 2>/dev/null | head -n 1 | cut -d' ' -f1)"
        if [ -n "$old" ] && [ -n "$cur" ] && [ "$old" != "$cur" ]; then
            # The ROM changed underneath us: rebuild from the new stock file (NLSound edits to this file are dropped)
            if cp -f "$real" "$f" 2>/dev/null; then
                grep -v " $real\$" "$dir/stock.sum" > "$dir/stock.sum.tmp"; echo "$cur $real" >> "$dir/stock.sum.tmp"; mv -f "$dir/stock.sum.tmp" "$dir/stock.sum"
                touch "$MORA_DATA/ota_changed"; mlog "ROM update detected for $real: overlay rebuilt from new stock"
            fi
        fi
        if ! v4a_registered "$f"; then
            v4a_patch_file "$f" && mlog "ViPER registration restored in $f" || mlog "WARNING: could not register ViPER in $f"
        fi
        chmod 0644 "$f" 2>/dev/null
        chcon u:object_r:vendor_configs_file:s0 "$f" 2>/dev/null
    done
}


# ---------------------------------------------------------------- ViPER driver: diagnose + repair
# Live view (what audioserver really reads) versus what the module ships. Every function is read-only
# except v4a_ensure, which is idempotent.
v4a_live_files() { find /odm/etc /vendor/etc /system/etc /product/etc /system_ext/etc -type f \( -name 'audio_effects*.xml' -o -name 'audio_effects*.conf' \) 2>/dev/null; }
v4a_live_reg_count() { local n=0 f; for f in $(v4a_live_files); do v4a_registered "$f" && n=$((n + 1)); done; echo "$n"; }
v4a_engine() {
    case "$V4A_ENGINE" in 1) return 0 ;; 0) return 1 ;; esac   # caller already knows (keeps the status script fast)
    timeout 3 dumpsys media.audio_flinger 2>/dev/null | grep -qi "$V4A_UUID" && return 0
    timeout 3 dumpsys media.audio_policy 2>/dev/null | grep -qiE "v4a_standard_re|$V4A_UUID" && return 0
    return 1
}
v4a_module_libs() { find "$1" -path "$1/rysound" -prune -o -name libv4a_re.so -print 2>/dev/null; }

# Poll (instead of a fixed sleep) until audioserver reports the ViPER effect; returns 0 once seen.
v4a_wait_engine() {   # seconds
    local i=0; V4A_ENGINE=
    while [ "$i" -lt "${1:-10}" ]; do v4a_engine && return 0; sleep 1; i=$((i + 1)); done
    return 1
}
# restart audio, wait for the effect, retry once (first start after boot is sometimes too early)
v4a_restart_and_wait() {
    restart_audioserver; v4a_wait_engine 10 && return 0
    mlog "viper: effect not registered after first restart, retrying"
    restart_audioserver; v4a_wait_engine 10
}

# one-word cause: ok | no_module_lib | ignore_effects | other_viper | aidl_hal | not_mounted | not_registered | not_loaded | no_audioserver
v4a_reason() {
    local d="$1" ml live_lib=0 l other
    ml="$(v4a_module_libs "$d" | head -n 1)"
    [ -n "$ml" ] || { echo no_module_lib; return; }
    [ "$(getprop ro.audio.ignore_effects)" = true ] && { echo ignore_effects; return; }
    # another ViPER build (e.g. the AIDL fork) answers for the same UUID and fights ours
    other="$(ls -d /data/adb/modules/*/ /data/adb/ksu/modules/*/ 2>/dev/null | while read -r m; do
        case "${m%/}" in */mora_audio_suite) continue ;; esac; [ -e "${m}disable" ] && continue
        find "$m" -maxdepth 5 -name 'libv4a*.so' 2>/dev/null | head -n 1
    done | head -n 1)"
    [ -n "$other" ] && { echo other_viper; return; }
    # the AIDL Audio Effects HAL never loads a HIDL-era libv4a_re.so (needs the AIDL ViPER build)
    rys_aidl && { echo aidl_hal; return; }
    for l in /vendor/lib64/soundfx /vendor/lib/soundfx /odm/lib64/soundfx /odm/lib/soundfx /system/lib64/soundfx /system/lib/soundfx; do
        [ -s "$l/libv4a_re.so" ] && live_lib=1
    done
    [ "$live_lib" = 1 ] || { echo not_mounted; return; }
    [ "$(v4a_live_reg_count)" -gt 0 ] || { echo not_registered; return; }
    [ -n "$(getprop init.svc.audioserver)" ] || { echo no_audioserver; return; }
    v4a_engine && echo ok || echo not_loaded
}

# give the module's ViPER files the labels the audio HAL is allowed to load
v4a_relabel() {
    local d="$1" f
    for f in $(v4a_module_libs "$d"); do
        chmod 0644 "$f" 2>/dev/null; chcon u:object_r:vendor_file:s0 "$f" 2>/dev/null
        chcon u:object_r:vendor_file:s0 "$(dirname "$f")" 2>/dev/null
    done
    for f in $(module_effect_files "$d"); do chmod 0644 "$f" 2>/dev/null; chcon u:object_r:vendor_configs_file:s0 "$f" 2>/dev/null; done
}

# Repair what the root manager's mount did not deliver. Prints the number of repairs; non-zero exit = nothing to do.
V4A_STAGE="$MORA_DATA/v4a_stage"
v4a_ensure() {
    local d="$1" n=0 f real ml dir live stage
    v4a_relabel "$d"
    # (a) a config that exists on the device but is not registered live: bind our patched copy over it
    for f in $(module_effect_files "$d"); do
        real="$(real_of "$f" "$d")"
        [ -f "$real" ] || continue
        v4a_registered "$f" || continue
        if ! v4a_registered "$real"; then
            if dax_ns mount --bind "$f" "$real" 2>/dev/null && v4a_registered "$real"; then
                n=$((n + 1)); mlog "viper: bound $real (overlay was not mounted)"
            else mlog "viper: bind failed for $real"; fi
        fi
    done
    # (b) library missing from the live soundfx dir: build a mirror of that dir + our lib and bind it over
    for ml in $(v4a_module_libs "$d"); do
        dir="${ml%/soundfx/libv4a_re.so}"; dir="${dir##*/}"        # lib | lib64
        for live in /vendor/$dir/soundfx /odm/$dir/soundfx; do
            [ -d "$live" ] || continue
            [ -s "$live/libv4a_re.so" ] && continue
            stage="$V4A_STAGE/$(echo "$live" | tr '/' '_')"
            rm -rf "$stage"; mkdir -p "$stage" || continue
            cp -a "$live/." "$stage/" 2>/dev/null
            cp -f "$ml" "$stage/libv4a_re.so"
            chmod 0755 "$stage"; chmod 0644 "$stage"/* 2>/dev/null
            chcon -R u:object_r:vendor_file:s0 "$stage" 2>/dev/null
            if dax_ns mount --bind "$stage" "$live" 2>/dev/null && [ -s "$live/libv4a_re.so" ]; then
                n=$((n + 1)); mlog "viper: mirrored $live with libv4a_re.so"
            else mlog "viper: could not mount $live"; fi
            break
        done
    done
    echo "$n"
    [ "$n" -gt 0 ]
}

# ---------------------------------------------------------------- RySound (software DSP effect)
# RySound registers one more effect (sound_universal) in the same audio_effects overlays that carry ViPER.
# It lives inside Mora so there is a single overlay per file; its boot guard only removes RySound,
# never the rest of the module.
RYS_STATE=/data/adb/sound_universal
RYS_UUID=7e3522c1-9347-4c81-a23a-1a233a220001

rys_status_write() {   # dir mode [reason] [config]
    local f="$1/rysound/integration.status"
    {
        echo "mode=$2"
        [ -n "$3" ] && echo "reason=$3"
        [ -n "$4" ] && echo "config=$4"
        echo "boot_id=$(head -n 1 /proc/sys/kernel/random/boot_id 2>/dev/null)"
        echo "staged_at=$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
    } > "$f.tmp" 2>/dev/null && mv -f "$f.tmp" "$f"
}
rys_status_mode() { sed -n 's/^mode=//p' "$1/rysound/integration.status" 2>/dev/null | head -n 1; }

# AIDL audio effects HAL (Android 14+ devices): the legacy XML hook cannot load the library there
rys_aidl() {
    local mf
    for mf in /vendor/etc/vintf/manifest.xml /vendor/etc/vintf/manifest/*.xml /odm/etc/vintf/manifest.xml /odm/etc/vintf/manifest/*.xml \
              /system/etc/vintf/manifest.xml /system/etc/vintf/manifest/*.xml /system_ext/etc/vintf/manifest.xml /system_ext/etc/vintf/manifest/*.xml \
              /product/etc/vintf/manifest.xml /product/etc/vintf/manifest/*.xml; do
        [ -f "$mf" ] || continue
        grep -q 'android.hardware.audio.effect' "$mf" 2>/dev/null || continue
        grep -q 'format="aidl"' "$mf" 2>/dev/null || continue
        awk '
            /<hal[ >]/ { in_hal=1; aidl=($0 ~ /format="aidl"/) }
            in_hal && /format="aidl"/ { aidl=1 }
            in_hal && /<name>android\.hardware\.audio\.effect<\/name>/ && aidl { found=1 }
            in_hal && /<\/hal>/ { in_hal=0; aidl=0 }
            END { exit(found?0:1) }' "$mf" && return 0
    done
    return 1
}

# patch one effects XML in place; refuses to write a file whose tags no longer balance
rys_patch_file() {   # file moduledir
    local f="$1" rd="$2/rysound" tmp="$1.rys.tmp" bo bn no nn
    case "$f" in *.xml) ;; *) return 1 ;; esac
    grep -q '<audio_effects_conf' "$f" 2>/dev/null || return 1
    awk -f "$rd/tools/patch_audio_effects.awk" "$f" > "$tmp" 2>/dev/null || { rm -f "$tmp"; return 1; }
    if ! { grep -q "uuid=\"$RYS_UUID\"" "$tmp" && grep -q '<postprocess' "$tmp"; }; then rm -f "$tmp"; return 1; fi
    bo="$(awk -f "$rd/tools/xml_balance.awk" "$f" 2>/dev/null)"; bn="$(awk -f "$rd/tools/xml_balance.awk" "$tmp" 2>/dev/null)"
    no="$(wc -l < "$f" 2>/dev/null)"; nn="$(wc -l < "$tmp" 2>/dev/null)"
    if [ -z "$bn" ] || [ "$bo" != "$bn" ] || [ "$nn" -lt "$no" ] || [ $((nn - no)) -gt 40 ]; then rm -f "$tmp"; return 1; fi
    mv -f "$tmp" "$f" && chmod 0644 "$f" && chcon u:object_r:vendor_configs_file:s0 "$f" 2>/dev/null
    return 0
}
rys_unpatch_file() {
    [ -f "$1" ] || return 0
    grep -q sound_universal "$1" 2>/dev/null || return 0
    sed -i -e '/<library name="sound_universal"/d' -e '/<effect name="sound_universal"/d' -e 's|<apply effect="sound_universal"/>||g' "$1"
}

# copy the DSP libraries next to the ViPER library (same soundfx directory = same SELinux/loader rules)
rys_stage_libs() {   # moduledir -> number of libraries placed
    local d="$1" rd="$1/rysound" n=0 v dir abis
    abis="$(getprop ro.product.cpu.abilist) $(getprop ro.product.cpu.abi)"
    for v in $(find "$d" -path "$d/rysound" -prune -o -name libv4a_re.so -print 2>/dev/null); do
        dir="${v%/*}"
        case "$dir" in
            */lib64/soundfx) case " $abis " in *arm64-v8a*) src="$rd/native_effect/build/libsounduniversal.so" ;; *) continue ;; esac ;;
            */lib/soundfx)   case " $abis " in *armeabi*|*arm64-v8a*) src="$rd/native_effect/build/libsounduniversal_arm.so" ;; *) continue ;; esac ;;
            *) continue ;;
        esac
        [ -s "$src" ] || continue
        cp -f "$src" "$dir/libsounduniversal.so" && chmod 0644 "$dir/libsounduniversal.so" && chcon u:object_r:vendor_file:s0 "$dir/libsounduniversal.so" 2>/dev/null && n=$((n + 1))
    done
    echo "$n"
}

# idempotent: make the overlays carry RySound. Prints the number of XML files patched.
rys_apply() {
    local d="$1" n=0 f
    [ "$(rys_stage_libs "$d")" -gt 0 ] || { echo 0; return 1; }
    for f in $(module_effect_files "$d"); do
        rys_patch_file "$f" "$d" && n=$((n + 1))
    done
    echo "$n"
    [ "$n" -gt 0 ]
}
rys_remove() {
    local d="$1" f
    for f in $(module_effect_files "$d"); do rys_unpatch_file "$f"; done
    find "$d" -path "$d/rysound" -prune -o -name libsounduniversal.so -exec rm -f {} + 2>/dev/null
}
rys_quarantine() {   # dir reason
    rys_remove "$1"
    mkdir -p "$RYS_STATE" 2>/dev/null
    echo "$2" > "$RYS_STATE/safe_mode"
    rys_status_write "$1" quarantined "$2"
    mlog "RySound quarantined: $2"
}
# install-time / re-enable: stage and write a fresh status (needs one reboot before it can load)
rys_stage() {
    local d="$1" n
    mkdir -p "$RYS_STATE" 2>/dev/null; chmod 0700 "$RYS_STATE" 2>/dev/null
    if [ -f "$RYS_STATE/safe_mode" ]; then rys_status_write "$d" quarantined "$(head -n 1 "$RYS_STATE/safe_mode")"; return 1; fi
    if rys_aidl; then rys_remove "$d"; rys_status_write "$d" webui_only "AIDL Audio Effects HAL detected; legacy XML hook intentionally skipped"; return 1; fi
    case " $(getprop ro.product.cpu.abilist) $(getprop ro.product.cpu.abi) " in
        *arm*) ;;
        *) rys_remove "$d"; rys_status_write "$d" webui_only "prebuilt DSP libraries support ARM only"; return 1 ;;
    esac
    n="$(rys_apply "$d")"
    if [ "${n:-0}" -gt 0 ]; then rys_status_write "$d" legacy_xml_staged "" "patched $n file(s)"; return 0; fi
    rys_remove "$d"
    rys_status_write "$d" webui_only "no supported legacy audio_effects.xml or ViPER library directory found"
    return 1
}

# post-fs-data (runs BEFORE the root manager mounts the overlay, so a failed hook is undone on the same boot)
rys_boot() {
    local d="$1" N m
    [ -d "$d/rysound" ] || return 0
    mkdir -p "$RYS_STATE" 2>/dev/null; chmod 0700 "$RYS_STATE" 2>/dev/null
    m="$(rys_status_mode "$d")"
    if [ "$(cfg_get RYSOUND)" != 1 ]; then
        if [ "$m" != disabled ]; then rys_remove "$d"; rys_status_write "$d" disabled "turned off in Mora Tuning"; fi
        return 0
    fi
    if [ -f "$RYS_STATE/safe_mode" ]; then rys_remove "$d"; [ "$m" = quarantined ] || rys_status_write "$d" quarantined "$(head -n 1 "$RYS_STATE/safe_mode")"; return 0; fi
    case "$m" in
        webui_only) return 0 ;;
        ''|disabled) rys_stage "$d" && sed -i '/^boot_id=/d' "$d/rysound/integration.status" 2>/dev/null; return 0 ;;
    esac
    N="$(head -n 1 "$RYS_STATE/boot_pending" 2>/dev/null)"; case "$N" in ''|*[!0-9]*) N=0 ;; esac
    N=$((N + 1)); echo "$N" > "$RYS_STATE/boot_pending"
    if [ "$N" -ge 3 ]; then rys_quarantine "$d" "boot_guard: $((N - 1)) consecutive boots did not finish"; return 0; fi
    rys_apply "$d" >/dev/null || mlog "RySound: could not (re)apply overlay"
    sh "$d/rysound/tools/sync_settings.sh" "$d/rysound" >/dev/null 2>&1
}

# service.sh (background): reset the boot counter, watch for crashes, verify the live hook
rys_service() {
    local d="$1" m
    [ -d "$d/rysound" ] || return 0
    [ "$(cfg_get RYSOUND)" = 1 ] || return 0
    sleep 45
    [ "$(getprop sys.boot_completed)" = 1 ] && echo 0 > "$RYS_STATE/boot_pending"
    sh "$d/rysound/tools/sync_settings.sh" "$d/rysound" >/dev/null 2>&1
    if [ ! -f "$RYS_STATE/safe_mode" ] && command -v logcat >/dev/null 2>&1 && logcat -d -b crash 2>/dev/null | grep -qi libsounduniversal; then
        rys_quarantine "$d" "watchdog: libsounduniversal crashed in an audio process"
        return 0
    fi
    for k in boot retry1 retry2; do
        sh "$d/rysound/tools/boot_audio_check.sh" "$d/rysound" >/dev/null 2>&1
        m="$(rys_status_mode "$d")"
        case "$m" in legacy_xml_runtime_loaded|webui_only|legacy_xml_staged|quarantined|disabled) break ;; esac
        [ "$k" = retry2 ] || sleep 60
    done
    mlog "RySound check: ${m:-unknown}"
}


# ---------------------------------------------------------------- Dolby DAX A/B (config swap)
# Bind-mounts one of the bundled dax-default.xml variants over the ROM's file. The original is backed up once.
DAX_DIR=/data/adb/dax_toggle
DAX_TARGET=/vendor/etc/dolby/dax-default.xml
DAX_STOCK_HASH=67c6e28da2ebfa31103562c54d062cc411d6b9f12a5e257c48c1181f7e20db87
dolby_present() { [ -f "$DAX_TARGET" ]; }
# the variants were built and tuned on Redmi Note 10 Pro (sweet) only: other devices never see the switch
dax_device_ok() {
    case "$(getprop ro.product.device) $(getprop ro.product.vendor.device)" in
        sweet\ *|sweetin\ *|*\ sweet|*\ sweetin|sweet\ sweet*) return 0 ;;
    esac
    return 1
}
dax_supported() { dax_device_ok && dolby_present && [ -n "$(getprop init.svc.dms-hal-2-0)" ]; }
dax_state() {
    local s; s="$(head -n 1 "$DAX_DIR/state" 2>/dev/null | tr -d ' \r\n')"
    case "$s" in new|bal3|bal6|bal9|bal12) echo "$s" ;; *) echo stock ;; esac
}
dax_ns() { if command -v nsenter >/dev/null 2>&1; then nsenter -t 1 -m -- "$@"; else "$@"; fi; }
dax_prepare() {   # moduledir: copy variants to /data and back up the stock file once
    local d="$1" f
    mkdir -p "$DAX_DIR"; chmod 755 "$DAX_DIR"
    [ -f "$DAX_DIR/stock.xml" ] || { [ -f "$DAX_TARGET" ] && cp -f "$DAX_TARGET" "$DAX_DIR/stock.xml"; }
    for f in new bal3 bal6 bal9 bal12; do
        [ -f "$d/dax/$f.xml" ] && cp -f "$d/dax/$f.xml" "$DAX_DIR/$f.xml"
    done
    chmod 644 "$DAX_DIR"/*.xml 2>/dev/null
}
dax_mount() {   # state: mounts (or unmounts for stock); returns non-zero on failure
    local st="$1" src
    # drop any previous bind first so mounts never stack
    dax_ns umount "$DAX_TARGET" 2>/dev/null
    [ "$st" = stock ] && return 0
    src="$DAX_DIR/$st.xml"; [ -f "$src" ] || return 1
    chcon u:object_r:vendor_configs_file:s0 "$src" 2>/dev/null
    dax_ns mount --bind "$src" "$DAX_TARGET" 2>/dev/null
}
dax_reload() {   # dms reads the XML, audioserver recreates the effect
    local b i=0
    b="$(pidof vendor.dolby.hardware.dms@2.0-service)"
    setprop ctl.restart dms-hal-2-0 2>/dev/null
    while [ $i -lt 20 ]; do
        [ "$(getprop init.svc.dms-hal-2-0)" = running ] && [ -n "$(pidof vendor.dolby.hardware.dms@2.0-service)" ] && [ "$(pidof vendor.dolby.hardware.dms@2.0-service)" != "$b" ] && break
        sleep 0.5; i=$((i + 1))
    done
    restart_audioserver
}
dax_set() {   # moduledir state
    local d="$1" st="$2"
    case "$st" in stock|new|bal3|bal6|bal9|bal12) ;; *) return 2 ;; esac
    dax_supported || return 3
    dax_prepare "$d"
    if dax_mount "$st"; then echo "$st" > "$DAX_DIR/state"; else echo stock > "$DAX_DIR/state"; dax_mount stock; return 1; fi
    mlog "dax: state=$st"
    return 0
}
dax_boot() {   # post-fs-data: re-apply the saved state before dms starts
    local st; st="$(dax_state)"
    [ "$st" = stock ] && return 0
    [ -f "$DAX_DIR/$st.xml" ] || return 0
    local i=0
    while [ ! -e "$DAX_TARGET" ] && [ $i -lt 20 ]; do sleep 0.5; i=$((i + 1)); done
    dax_mount "$st" && mlog "dax: restored $st at boot" || mlog "dax: could not restore $st"
}


# ---------------------------------------------------------------- BassBoost (system priv-app, global effects on session 0)
BB_PKG=dev.kazuyoo.bassboost
bb_installed() { pm path "$BB_PKG" >/dev/null 2>&1; }
bb_staged() { [ -f "$MODDIR/system/priv-app/BassBoost/BassBoost.apk" ]; }
# the app only reacts to intents sent to its (non-exported) service; root may start it
bb_send() {   # ACTION VALUE
    am start-foreground-service -n "$BB_PKG/.BassService" -a "$BB_PKG.$1" --ei value "$2" >/dev/null 2>&1 \
        || am startservice -n "$BB_PKG/.BassService" -a "$BB_PKG.$1" --ei value "$2" >/dev/null 2>&1
}
bb_apply() {   # push Mora's saved values to the app; returns non-zero when the app is not present yet
    bb_installed || return 1
    bb_send SET_BASS_STRENGTH "$(cfg_get BB_STRENGTH)"
    bb_send SET_LOW_GAIN "$(cfg_get BB_GAIN)"
    bb_send SET_LOUDNESS_TARGET "$(cfg_get BB_TARGET)"
    bb_send SET_BASS_ENABLED "$(cfg_get BB_BASS)"
    bb_send SET_LOUDNESS_ENABLED "$(cfg_get BB_LOUDNESS)"
    bb_send SET_DP_ENABLED "$(cfg_get BB_DP)"
    mlog "bassboost: bass=$(cfg_get BB_BASS)/$(cfg_get BB_STRENGTH) dp=$(cfg_get BB_DP)/$(cfg_get BB_GAIN) loud=$(cfg_get BB_LOUDNESS)/$(cfg_get BB_TARGET)"
}


# ---------------------------------------------------------------- banner (WebUI hero image)
banner_choice() { local c; c="$(cat "$MORA_DATA/banner_choice" 2>/dev/null)"; echo "${c:-b00}"; }
# rotate_daily / rotate_boot resolve to one of the 15 bundled banners
banner_resolve() {
    case "$1" in
        rotate_daily) printf 'b%02d' $(( $(date +%s) / 86400 % 16 )) ;;
        rotate_boot) printf 'b%02d' $(( $(date +%s) % 16 )) ;;
        *) echo "$1" ;;
    esac
}
# copy the chosen banner to webroot/banner.jpg (a module update restores the default, so boot re-applies the choice)
banner_apply() {   # moduledir
    local d="$1" c src
    c="$(banner_resolve "$(banner_choice)")"
    case "$c" in
        custom) src="$MORA_DATA/banner_custom.jpg" ;;
        *) src="$d/webroot/banners/$c.jpg" ;;
    esac
    [ -s "$src" ] || src="$d/webroot/banners/b00.jpg"
    [ -s "$src" ] || return 1
    cp -f "$src" "$d/webroot/banner.jpg" && chmod 0644 "$d/webroot/banner.jpg"
    # root-manager module card: darkened variant (cNN) of the bundled banner, or the custom image as is
    case "$c" in
        custom) cp -f "$src" "$d/banner.jpg" ;;
        *) if [ -s "$d/webroot/banners/c${c#b}.jpg" ]; then cp -f "$d/webroot/banners/c${c#b}.jpg" "$d/banner.jpg"; else cp -f "$src" "$d/banner.jpg"; fi ;;
    esac
    chmod 0644 "$d/banner.jpg" 2>/dev/null
    return 0
}


# ---------------------------------------------------------------- Yayang profiles (Sony+ / Speaker V2)
# Curated property lists + optional kernel sound_control gain. Anything the listening mode already manages
# is skipped so Musik/Film/Hemat always win.
yayang_apply() {
    local d="${1:-$MODDIR}" mode managed list k v n=0 f val
    mode="$(cfg_get MODE)"
    managed="$(mode_props "$mode" 2>/dev/null | awk '{print $2}' | tr '\n' ' ') audio.offload. ro.config.media_vol_steps ro.config.vc_call_vol_steps"
    for list in sony v2; do
        [ "$(cfg_get "YAYANG_$(echo "$list" | tr 'a-z' 'A-Z')")" = 1 ] || continue
        f="$d/yayang/$list.props"; [ -f "$f" ] || continue
        while IFS='=' read -r k v; do
            case "$k" in ''|\#*) continue ;; esac
            case " $managed " in *" $k "*) continue ;; esac
            case "$k" in audio.offload.*) continue ;; esac
            [ "$(getprop "$k")" = "$v" ] && continue
            prop_set "$k" "$v"; n=$((n + 1))
        done < "$f"
    done
    [ "$n" -gt 0 ] && mlog "yayang: set $n props"
    # kernel sound_control gains (only where the kernel exposes them); 0 = leave untouched
    val="$(cfg_get YAYANG_SPK_GAIN)"
    if [ "$val" -gt 0 ]; then for f in /sys/kernel/sound_control/speaker_gain /sys/class/misc/snd_soc_card/speaker_gain; do [ -w "$f" ] && echo "$val" > "$f" 2>/dev/null; done; fi
    val="$(cfg_get YAYANG_HP_GAIN)"
    if [ "$val" -gt 0 ]; then for f in /sys/kernel/sound_control/headphone_gain /sys/class/misc/snd_soc_card/headphone_gain; do [ -w "$f" ] && echo "$val" > "$f" 2>/dev/null; done; fi
    return 0
}


# ---------------------------------------------------------------- Effect Hub (AML-style)
# Effect Hub: other modules' sound-effect libraries are registered inside Mora's single audio_effects overlay,
# so no second module has to rewrite the same files. Effect/UUID list: Audio Modification Library (Rei Ryuki, MIT).
FX_LIST="$MORA_DATA/fxhub.list"
FX_SAFE="$MORA_DATA/fx_safe"
FX_SKIP_IDS="mora_audio_suite $CONFLICT_IDS"

elf_bits() { case "$(od -An -tx1 -j4 -N1 "$1" 2>/dev/null | tr -d ' \n')" in 01) echo 32 ;; 02) echo 64 ;; esac; }
fx_bits() {   # bitness of the process that loads effect libraries: the audio HAL (HIDL), else audioserver
    local p b f
    [ -n "$FX_BITS" ] && { echo "$FX_BITS"; return; }
    for f in ${FX_HAL_GLOB:-/*/bin/hw/*audio*service* /*/bin/hw/*audio*}; do
        [ -f "$f" ] && b="$(elf_bits "$f")" && [ -n "$b" ] && break
        b=
    done
    if [ -z "$b" ]; then
        p="$(pidof audioserver 2>/dev/null | cut -d' ' -f1)"
        [ -n "$p" ] && b="$(elf_bits "/proc/$p/exe")"
    fi
    if [ -z "$b" ]; then if [ -n "$(getprop ro.product.cpu.abilist64)" ]; then b=64; else b=32; fi; fi
    echo "$b"
}
# ---- hub internals
fx_enabled() { [ "$(cfg_get FXHUB)" = 1 ] && [ ! -f "$FX_SAFE" ]; }
fx_skip_id() { local i; for i in $FX_SKIP_IDS; do [ "$i" = "$1" ] && return 0; done; return 1; }
fx_files() { module_effect_files "$1"; }

# prints: libfile|effect|library|uuid|stream|realdir|source   one line per library found
fx_scan() {   # moduledir
    local d="$1" tsv="$1/fxhub/libs.tsv" bits m id lf en ln uu st f rd seen tab
    [ -r "$tsv" ] || return 0
    tab="$(printf '\t')"
    bits="$(fx_bits)"
    while IFS="$tab" read -r lf en ln uu st; do
        [ -n "$lf" ] || continue
        seen=
        for m in "${FX_MODULES:-/data/adb/modules}"/*; do
            [ -d "$m" ] || continue
            id="${m##*/}"
            fx_skip_id "$id" && continue
            if [ -e "$m/disable" ] || [ -e "$m/remove" ]; then continue; fi
            for f in $(find "$m" -type f -name "$lf" -path '*soundfx*' 2>/dev/null); do
                case "$f" in */lib64/*) [ "$bits" = 64 ] || continue ;; */lib/*) [ "$bits" = 32 ] || continue ;; esac
                rd="$(real_of "${f%/*}" "$m")"
                echo "$lf|$en|$ln|$uu|$st|$rd|$id"; seen=1; break
            done
            [ -n "$seen" ] && break
        done
    done < "$tsv"
}

fx_balance_ok() {   # old new moduledir
    local bo bn no nn t="$3/rysound/tools/xml_balance.awk"
    case "$1" in *.xml) ;; *) return 0 ;; esac
    [ -f "$t" ] || return 0
    bo="$(awk -f "$t" "$1" 2>/dev/null)"; bn="$(awk -f "$t" "$2" 2>/dev/null)"
    no="$(wc -l < "$1")"; nn="$(wc -l < "$2")"
    [ -n "$bn" ] && [ "$bo" = "$bn" ] && [ "$nn" -ge "$no" ] && [ $((nn - no)) -le 14 ]
}
fx_has() {   # file effect library
    case "$1" in
        *.xml) grep -q "name=\"$3\"" "$1" 2>/dev/null && grep -q "name=\"$2\"" "$1" 2>/dev/null ;;
        *)     grep -q "^[[:space:]]*$3 {" "$1" 2>/dev/null && grep -q "^[[:space:]]*$2 {" "$1" 2>/dev/null ;;
    esac
}
# register one library in one overlay file; refuses to leave a damaged file behind. 0 ok, 2 UUID already owned, 1 failed
fx_reg() {   # moduledir file libfile effect library uuid stream realdir
    local sn d="$1" f="$2" lf="$3" en="$4" ln="$5" uu="$6" st="$7" rd="$8" tmp="${2%/*}/fx_tmp_${2##*/}"
    fx_has "$f" "$en" "$ln" && return 0
    grep -qi "$uu" "$f" 2>/dev/null && return 2
    cp -f "$f" "$tmp" || return 1
    case "$f" in
        *.xml)
            if ! { grep -q '<libraries>' "$tmp" && grep -q '<effects>' "$tmp"; }; then rm -f "$tmp"; return 1; fi
            sed -i "/<libraries>/ a\        <library name=\"$ln\" path=\"$lf\"/>" "$tmp"
            sed -i "/<effects>/ a\        <effect name=\"$en\" library=\"$ln\" uuid=\"$uu\"/>" "$tmp"
            if [ "$st" != "-" ] && ! grep -q '<postprocess>' "$tmp" && grep -q '</effects>' "$tmp"; then
                sed -i "/<\/effects>/ a\    <postprocess>\n    <\/postprocess>" "$tmp"
            fi
            if [ "$st" != "-" ] && grep -q '<postprocess>' "$tmp"; then
                for sn in $(echo "$st" | tr ',' ' '); do
                    grep -q "<stream type=\"$sn\">" "$tmp" || sed -i "/<postprocess>/ a\        <stream type=\"$sn\">\n        <\/stream>" "$tmp"
                    sed -i "/<stream type=\"$sn\">/ a\            <apply effect=\"$en\"/>" "$tmp"
                done
            fi ;;
        *.conf)
            if ! { grep -q '^libraries {' "$tmp" && grep -q '^effects {' "$tmp"; }; then rm -f "$tmp"; return 1; fi
            sed -i "s|^libraries {|libraries {\n  $ln {\n    path $rd/$lf\n  }|" "$tmp"
            sed -i "s|^effects {|effects {\n  $en {\n    library $ln\n    uuid $uu\n  }|" "$tmp"
            if [ "$st" != "-" ] && ! grep -q '^output_session_processing {' "$tmp"; then
                printf '\noutput_session_processing {\n}\n' >> "$tmp"
            fi
            if [ "$st" != "-" ] && grep -q '^output_session_processing {' "$tmp"; then
                for sn in $(echo "$st" | tr ',' ' '); do
                    grep -q "^    $sn {" "$tmp" || sed -i "/^output_session_processing {/ a\    $sn {\n    }" "$tmp"
                    sed -i "/^output_session_processing {/,/^}/ s/^\( *\)$sn {\$/&\n\1    $en {\n\1    }/" "$tmp"
                done
            fi ;;
        *) rm -f "$tmp"; return 1 ;;
    esac
    if ! fx_has "$tmp" "$en" "$ln" || ! fx_balance_ok "$f" "$tmp" "$d"; then rm -f "$tmp"; return 1; fi
    mv -f "$tmp" "$f" && chmod 0644 "$f" && chcon u:object_r:vendor_configs_file:s0 "$f" 2>/dev/null
    return 0
}
fx_unreg() {   # file effect library
    local f="$1" en="$2" ln="$3"
    [ -f "$f" ] || return 0
    case "$f" in
        *.xml) sed -i -e "/<library name=\"$ln\" path=/d" -e "/<effect name=\"$en\" library=\"$ln\"/d" -e "/<apply effect=\"$en\"[ ]*\/>/d" "$f" ;;
        *.conf) sed -i -e "/^[[:space:]]*$ln {/,/}/d" -e "/^[[:space:]]*$en {/,/}/d" "$f" ;;
    esac
}
fx_clear() {   # moduledir: remove everything the hub added
    local d="$1" f lf en ln rest
    if [ -f "$FX_LIST" ]; then
        while IFS='|' read -r lf en ln rest; do
            [ -n "$en" ] || continue
            for f in $(fx_files "$d"); do fx_unreg "$f" "$en" "$ln"; done
        done < "$FX_LIST"
    fi
    : > "$FX_LIST" 2>/dev/null
    return 0
}
# register every library found; remove entries whose module is gone. Prints the number registered.
fx_apply() {   # moduledir
    local old d="$1" n=0 new="$FX_LIST.new" scan lf en ln uu st rd src f r files rest
    mkdir -p "$MORA_DATA" 2>/dev/null
    if ! fx_enabled; then fx_clear "$d"; echo 0; return 0; fi
    files="$(fx_files "$d")"
    [ -n "$files" ] || { echo 0; return 0; }
    : > "$new"
    scan="$MORA_DATA/fx_scan.tmp"
    fx_scan "$d" > "$scan"
    while IFS='|' read -r lf en ln uu st rd src; do
        [ -n "$lf" ] || continue
        r=0
        old="$(grep "^$lf|$en|" "$FX_LIST" 2>/dev/null | head -n 1 | cut -d'|' -f6)"
        if [ -n "$old" ] && [ "$old" != "$st" ]; then
            for f in $files; do fx_unreg "$f" "$en" "$ln"; done
            mlog "Effect Hub: $en streams changed ($old -> $st)"
        fi
        for f in $files; do
            fx_reg "$d" "$f" "$lf" "$en" "$ln" "$uu" "$st" "$rd"
            [ $? -eq 0 ] && r=$((r + 1))
        done
        if [ "$r" -gt 0 ]; then
            echo "$lf|$en|$ln|$src|$uu|$st" >> "$new"; n=$((n + 1)); mlog "Effect Hub: $en ($lf from $src) registered in $r file(s)"
        else
            mlog "Effect Hub: $en skipped (UUID already provided by the ROM, or the file could not be patched safely)"
        fi
    done < "$scan"
    rm -f "$scan"
    if [ -f "$FX_LIST" ]; then
        while IFS='|' read -r lf en ln rest; do
            [ -n "$en" ] || continue
            grep -q "^$lf|$en|" "$new" 2>/dev/null && continue
            for f in $files; do fx_unreg "$f" "$en" "$ln"; done
            mlog "Effect Hub: $en removed (module gone or disabled)"
        done < "$FX_LIST"
    fi
    mv -f "$new" "$FX_LIST"
    echo "$n"
}
# post-fs-data guard: three boots that never finished -> hub turns itself off
fx_boot() {   # moduledir
    local d="$1" n
    rm -rf "$MORA_DATA/atmos_pre" "$MORA_DATA/atmos.status" 2>/dev/null
    if [ -f "$FX_SAFE" ]; then fx_clear "$d"; return 0; fi
    n="$(head -n 1 "$MORA_DATA/fx_pending" 2>/dev/null)"; case "$n" in ''|*[!0-9]*) n=0 ;; esac
    n=$((n + 1)); echo "$n" > "$MORA_DATA/fx_pending"
    if [ "$n" -ge 3 ]; then
        fx_clear "$d"; echo "boot_guard: $((n - 1)) consecutive boots did not finish" > "$FX_SAFE"
        mlog "Effect Hub switched off by the boot guard"; return 0
    fi
    fx_apply "$d" >/dev/null
}
fx_service_ok() { echo 0 > "$MORA_DATA/fx_pending" 2>/dev/null; }
fx_count() { local n; n="$(grep -c . "$FX_LIST" 2>/dev/null)"; echo "${n:-0}"; }
