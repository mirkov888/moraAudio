#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Verifies the live audio hook and reports runtime evidence separately from configuration.
# It never restarts audioserver and never modifies protected system partitions.
MODDIR="${1:-$(CDPATH= cd -- "$(dirname -- "$0")" 2>/dev/null && pwd)}"
MODID=sound_universal
STATE_DIR="${SU_STATE_DIR:-/data/adb/${MODID}}"
STATUS_FILE="$STATE_DIR/audio_verify_status.txt"
LOG_FILE="$STATE_DIR/audio_verify.log"
SU_STATUS="$MODDIR/integration.status"
. "$MODDIR/tools/hook_probe.sh" 2>/dev/null || { echo '[Audio Verify] ERROR: tools/hook_probe.sh is missing.'; exit 1; }
mkdir -p "$STATE_DIR" 2>/dev/null
chmod 0700 "$STATE_DIR" 2>/dev/null
umask 077
TMP_OUT="$STATE_DIR/audio_verify.tmp.$$"
: > "$TMP_OUT" 2>/dev/null || TMP_OUT="/data/local/tmp/audio_verify.tmp.$$"
: > "$TMP_OUT" 2>/dev/null || { echo '[Audio Verify] ERROR: cannot create temporary report.'; exit 1; }
say() { echo "$*" >> "$TMP_OUT"; }
say '=== AUDIO ENGINE VERIFICATION ==='
say "Module: $MODID"
say "Android: $(getprop ro.build.version.release 2>/dev/null) (SDK $(getprop ro.build.version.sdk 2>/dev/null))"
say ''

MODULE_OK=1; BOOT_OK=0
BOOT_DONE=$(getprop sys.boot_completed 2>/dev/null)
INTEGRATION_MODE=$(su_status_get mode)
if [ -e "${MODDIR%/rysound}/disable" ] || [ -e "${MODDIR%/rysound}/remove" ]; then
  MODULE_OK=0
  say '[GAGAL] Modul mempunyai file disable/remove.'
else
  say '[OK] Tidak ada file disable/remove pada direktori modul.'
fi
if [ "$BOOT_DONE" = '1' ]; then
  BOOT_OK=1
  say '[OK] Android selesai booting.'
else
  say "[PERINGATAN] Android belum selesai booting (sys.boot_completed=$BOOT_DONE)."
fi
say "Mode integrasi tercatat: ${INTEGRATION_MODE:-unknown}"

su_evaluate
PENDING_CHECK=0; su_pending_reboot && PENDING_CHECK=1
CONFIG_OK=0; LIB_OK=0
if [ -n "$CFG_ACTIVE" ]; then
  CONFIG_OK=1
  say "[OK] UUID efek terlihat pada konfigurasi aktif: $CFG_ACTIVE"
  if [ -n "$CFG_FIRST" ] && [ "$CFG_FIRST" != "$CFG_ACTIVE" ]; then
    say "[PERINGATAN] Android membaca $CFG_FIRST lebih dulu, dan file itu belum memuat hook."
  fi
else
  say '[PERINGATAN] UUID efek tidak terlihat pada konfigurasi audio aktif.'
  case "$INTEGRATION_MODE" in
    legacy_xml_staged) say '[INFO] Overlay baru disiapkan. Reboot diperlukan agar root manager me-mount overlay dan Android membaca ulang konfigurasi.' ;;
    legacy_xml_overlay_not_active) say '[PERINGATAN] Pemeriksaan sebelumnya juga tidak menemukan overlay pada konfigurasi aktif. Pastikan modul aktif dan root manager mendukung mount overlay.' ;;
    webui_only) say "[INFO] Mode WEBUI ONLY: $(su_status_get reason)" ;;
  esac
  if [ "$PENDING_CHECK" != 1 ] && [ "$KSU_ENV" = 1 ] && [ -z "$MM_NAME" ]; then
    say '[PENTING] KernelSU terdeteksi tetapi tidak ada metamodule aktif. KernelSU resmi v3.0+ dan ReSukiSU tidak me-mount folder system/ modul tanpa metamodule (mis. meta-overlayfs). Pasang metamodule, reboot, lalu periksa lagi.'
  fi
fi
if [ -n "$ACTIVE_LIB" ]; then
  LIB_OK=1
  say "[OK] Library native terlihat di jalur aktif: $ACTIVE_LIB"
else
  say '[PERINGATAN] Library native tidak ditemukan pada jalur audio-effect standar untuk ABI perangkat.'
fi

if [ "$RT_OK" = 1 ]; then
  say "[OK] Library dimuat oleh proses audio (${RT_PROC:-?}, pid:$RT_PIDS). Ini bukti hook termuat."
else
  say '[PERINGATAN] Belum ada proses audio yang memuat library RySound (/proc/<pid>/maps).'
fi

AUDIO_OK=0; AF_SIG=0
AUDIO_DUMP=$(dumpsys media.audio_flinger 2>/dev/null)
if [ -n "$AUDIO_DUMP" ] && ! echo "$AUDIO_DUMP" | grep -qiE 'permission denied|can.t find service|not found'; then
  AUDIO_OK=1
  say '[OK] AudioFlinger merespons dumpsys.'
  if echo "$AUDIO_DUMP" | grep -qiE 'RySound 20-band DSP|sound_universal|7e3522c1-9347-4c81-a23a-1a233a220001'; then
    AF_SIG=1
    say '[OK] Signature RySound ditemukan pada dump AudioFlinger (instance efek aktif).'
  else
    say '[INFO] Dump AudioFlinger belum menunjukkan instance efek. Putar musik lalu jalankan Action lagi; ketiadaan signature tidak selalu berarti gagal.'
  fi
else
  say '[PERINGATAN] AudioFlinger tidak dapat diperiksa melalui dumpsys.'
fi

if [ "$LOG_ERROR" = 1 ]; then
  say '[GAGAL] Logcat menunjukkan error pemuatan/SELinux untuk RySound:'
  echo "$LOG_HITS" | tail -n 4 | cut -c1-200 >> "$TMP_OUT"
elif [ -n "$LOG_HITS" ]; then
  say '[INFO] Logcat menyebut RySound tanpa tanda error.'
fi

if [ "${FX_FAIL:-0}" = 1 ]; then
  say '[GAGAL] Logcat: AudioPolicyEffects gagal membuat efek sound_universal. Artinya library tidak termuat di audio HAL (SELinux / jalur library / ABI) walau XML sudah aktif. Kirim file log lengkap di bawah.'
fi
case "${CONF_ACCESS:-ok}" in
  ok) say '[OK] File setelan DSP bisa dibaca proses audio (izin folder dan file benar).' ;;
  missing) say '[PERINGATAN] File /data/misc/audio/sound_universal.conf belum ada. Buka WebUI lalu tekan Simpan sekarang.' ;;
  dir_blocked) say '[GAGAL] Folder /data/misc/audio tidak bisa dilewati proses audio (izin 0700). Setelan tidak akan sampai ke DSP. Buka WebUI lalu tekan Simpan sekarang (izin diperbaiki otomatis).' ;;
  file_blocked) say '[GAGAL] File sound_universal.conf tidak bisa dibaca proses non-root. Tekan Simpan sekarang di WebUI.' ;;
  denied) say '[GAGAL] SELinux menolak proses audio membaca sound_universal.conf. Pastikan sepolicy.rule modul termuat (reboot) lalu cek ulang.' ;;
esac
if [ -f "$STATE_DIR/safe_mode" ]; then
  say "[PERINGATAN] MODE AMAN aktif: $(head -n 1 "$STATE_DIR/safe_mode" 2>/dev/null)"
fi

# Final verdict. A live process that mapped the library is proof; paths alone are not.
PENDING=0
su_pending_reboot && PENDING=1
if [ -f "$STATE_DIR/safe_mode" ]; then
  RESULT='SAFE_MODE'; WRITE=0
  say ''; say 'HASIL: MODE AMAN (overlay dimatikan otomatis untuk mencegah bootloop). Buka WebUI > Keluar mode aman bila ingin mencoba lagi.'
elif [ "$MODULE_OK" != 1 ]; then
  RESULT='NOT_VERIFIED'; WRITE=0
  say ''; say 'HASIL: BELUM DIVERIFIKASI (modul dinonaktifkan/dihapus)'
elif [ "$INTEGRATION_MODE" = 'webui_only' ]; then
  RESULT='WEBUI_ONLY'; WRITE=0
  say ''; say 'HASIL: WEBUI ONLY (hook native tidak dipasang pada ROM ini)'
elif [ "$PENDING" = 1 ]; then
  RESULT='WAITING_FOR_BOOT_OR_OVERLAY'; WRITE=0
  say ''; say 'HASIL: MENUNGGU REBOOT (overlay baru disiapkan)'
elif [ "$BOOT_OK" != 1 ]; then
  RESULT='WAITING_FOR_BOOT_OR_OVERLAY'; WRITE=0
  say ''; say 'HASIL: MENUNGGU BOOT SELESAI'
else
  WRITE=1
  [ "$AF_SIG" != 1 ] || { RT_OK=1; SU_MODE=legacy_xml_runtime_loaded; }
  case "$SU_MODE" in
    legacy_xml_runtime_loaded) RESULT='RUNTIME_VERIFIED'; say ''; say 'HASIL: HOOK TERVERIFIKASI (library termuat di proses audio)' ;;
    legacy_xml_config_active) RESULT='CONFIG_ACTIVE_RUNTIME_UNCONFIRMED'; say ''; say 'HASIL: KONFIGURASI AKTIF, PEMUATAN RUNTIME BELUM TERKONFIRMASI' ;;
    legacy_xml_load_error) RESULT='LOAD_ERROR'; say ''; say 'HASIL: HOOK ADA TETAPI GAGAL DIMUAT (lihat error logcat di atas)' ;;
    legacy_xml_config_active_library_missing) RESULT='LIBRARY_MISSING'; say ''; say 'HASIL: KONFIGURASI AKTIF, LIBRARY TIDAK DITEMUKAN' ;;
    *) RESULT='OVERLAY_NOT_ACTIVE'; say ''; say 'HASIL: OVERLAY HOOK TIDAK AKTIF SETELAH BOOT' ;;
  esac
  STAGED_CFG=$(su_status_get staged_config); [ -n "$STAGED_CFG" ] || STAGED_CFG=$(su_status_get config)
  [ "$STAGED_CFG" != none ] || STAGED_CFG=''
  su_write_result "$STAGED_CFG"
fi

{
  echo "STATUS=$RESULT"
  echo "MODULE_ID=$MODID"
  echo "CHECKED_AT=$(su_now)"
  echo "ANDROID_RELEASE=$(getprop ro.build.version.release 2>/dev/null)"
  echo "SDK=$(getprop ro.build.version.sdk 2>/dev/null)"
  echo "INTEGRATION_MODE=${SU_MODE:-${INTEGRATION_MODE:-unknown}}"
  echo "ACTIVE_CONFIG=${CFG_ACTIVE:-none}"
  echo "ACTIVE_LIBRARY=${ACTIVE_LIB:-none}"
  echo "RUNTIME_PROCESS=${RT_PROC:-none}"
  [ "$KSU_ENV" != 1 ] || echo "METAMODULE=${MM_NAME:-none}"
} > "$STATUS_FILE" 2>/dev/null
cat "$TMP_OUT" | tee "$LOG_FILE"
echo ''
echo "Status tersimpan: $STATUS_FILE"
DBG=$(sh "$MODDIR/tools/collect_debug.sh" "$MODDIR" 2>/dev/null | tail -n 1)
[ -z "$DBG" ] || echo "Log lengkap untuk dikirim: $DBG"
rm -f "$TMP_OUT"
case "$RESULT" in RUNTIME_VERIFIED|CONFIG_ACTIVE_RUNTIME_UNCONFIRMED) exit 0 ;; *) exit 1 ;; esac
