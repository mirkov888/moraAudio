#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# RySound 🎧 - shared hook probes. This file is SOURCED, never run directly.
# Test-only overrides (empty/default on a real device): SU_FS_ROOT, SU_PROC_ROOT.
SU_UUID='7e3522c1-9347-4c81-a23a-1a233a220001'
SU_FS="${SU_FS_ROOT:-}"
SU_PROC="${SU_PROC_ROOT:-/proc}"
SU_MODULES="${SU_MODULES_ROOT:-/data/adb/modules}"
SU_KSU_DIR="${SU_KSU_ROOT:-/data/adb/ksu}"
# AOSP EffectsConfig reads the first existing file in this order (odm, vendor, system).
SU_CFG_CANDIDATES='/odm/etc/audio_effects.xml /vendor/etc/audio_effects.xml /system_ext/etc/audio_effects.xml /system/etc/audio_effects.xml'

su_now() { date '+%Y-%m-%d %H:%M:%S' 2>/dev/null; }
su_boot_id() { head -n 1 "$SU_PROC/sys/kernel/random/boot_id" 2>/dev/null; }
su_status_get() { sed -n "s/^$1=//p" "$SU_STATUS" 2>/dev/null | head -n 1; }

# Writes $SU_STATUS atomically. Usage: { echo key=value; ... } | su_status_write MODE
su_status_write() {
  _t="$SU_STATUS.tmp.$$"
  { echo "mode=$1"; cat; } > "$_t" 2>/dev/null || { rm -f "$_t"; return 1; }
  chmod 0644 "$_t" 2>/dev/null
  mv "$_t" "$SU_STATUS" 2>/dev/null || { rm -f "$_t"; return 1; }
}

# Is the overlay still waiting for its first reboot? (same boot as the install)
su_pending_reboot() {
  [ "$(su_status_get mode)" = "legacy_xml_staged" ] || return 1
  _st=$(su_status_get boot_id); _cur=$(su_boot_id)
  [ -n "$_st" ] && [ -n "$_cur" ] && [ "$_st" = "$_cur" ]
}

# Sets CFG_FIRST (XML the audio stack reads first) and CFG_ACTIVE (first XML that contains our UUID).
su_probe_config() {
  CFG_FIRST=''; CFG_ACTIVE=''
  for _p in $SU_CFG_CANDIDATES; do
    [ -s "$SU_FS$_p" ] || continue
    [ -n "$CFG_FIRST" ] || CFG_FIRST="$_p"
    if [ -z "$CFG_ACTIVE" ] && grep -q "$SU_UUID" "$SU_FS$_p" 2>/dev/null; then CFG_ACTIVE="$_p"; fi
  done
}

su_find_lib() {
  for _part in /odm /vendor /system_ext /system; do
    _f="$_part/$1/soundfx/libsounduniversal.so"
    if [ -s "$SU_FS$_f" ]; then ACTIVE_LIB="$_f"; return 0; fi
  done
  return 1
}

# Sets ACTIVE_LIB: library for this device's ABI that is visible in the live system.
su_probe_lib() {
  ACTIVE_LIB=''
  _abis="$(getprop ro.product.cpu.abilist 2>/dev/null) $(getprop ro.product.cpu.abi 2>/dev/null)"
  case " $_abis " in *arm64-v8a*) su_find_lib lib64 ;; esac
  if [ -z "$ACTIVE_LIB" ]; then
    case " $_abis " in *armeabi*) su_find_lib lib ;; esac
  fi
}

# Sets KSU_ENV (1 on KernelSU-family) and MM_NAME (id of an enabled metamodule, if any).
# Official KernelSU v3.0+ and ReSukiSU only mount a module's system/ folder when a
# metamodule (for example meta-overlayfs) is installed; without one the hook never appears.
su_probe_metamodule() {
  MM_NAME=''; KSU_ENV=0
  [ -d "$SU_KSU_DIR" ] && KSU_ENV=1
  for _d in "$SU_MODULES"/*/; do
    [ -f "${_d}module.prop" ] || continue
    [ -e "${_d}disable" ] || [ -e "${_d}remove" ] && continue
    if grep -qiE '^metamodule=(1|true)' "${_d}module.prop" 2>/dev/null; then
      _n=${_d%/}; MM_NAME=${_n##*/}; break
    fi
  done
}

# Sets RT_OK / RT_PROC / RT_PIDS: strongest proof - an audio process has our library mapped.
su_probe_runtime() {
  RT_OK=0; RT_PROC=''; RT_PIDS=''
  _files=$(grep -l 'libsounduniversal' "$SU_PROC"/[0-9]*/maps 2>/dev/null)
  for _m in $_files; do
    _pid=${_m%/maps}; _pid=${_pid##*/}
    RT_PIDS="$RT_PIDS $_pid"
    [ -n "$RT_PROC" ] || RT_PROC=$(head -n 1 "$SU_PROC/$_pid/comm" 2>/dev/null)
  done
  [ -z "$RT_PIDS" ] || RT_OK=1
}

# Sets LOG_HITS / LOG_ERROR / CONF_DENIED. LOG_ERROR = library gagal dimuat; CONF_DENIED = SELinux
# menolak proses audio membaca sound_universal.conf (library termuat tapi setelan tidak sampai).
su_probe_log() {
  LOG_HITS=''; LOG_ERROR=0; CONF_DENIED=0; FX_FAIL=0
  command -v logcat >/dev/null 2>&1 || return 0
  _lt=$(logcat -d -b all -t 8000 2>/dev/null)
  [ -n "$_lt" ] || _lt=$(logcat -d -t 8000 2>/dev/null)
  LOG_HITS=$(echo "$_lt" | grep -iE 'sounduniversal|sound_universal' | tail -n 8)
  [ -n "$LOG_HITS" ] || return 0
  if echo "$LOG_HITS" | grep -iE 'libsounduniversal|soundfx' | grep -qiE 'dlopen failed|cannot locate|failed to load|couldn.t load|could not load|avc: +denied|no such file'; then LOG_ERROR=1; fi
  if echo "$LOG_HITS" | grep -i 'avc: *denied' | grep -qi 'sound_universal.conf'; then CONF_DENIED=1; fi
  # AudioPolicyEffects gagal membuat efek: library tidak termuat di audio HAL atau SELinux menolaknya.
  if echo "$LOG_HITS" | grep -qi 'failed to create Fx'; then FX_FAIL=1; fi
}

# Sets CONF_ACCESS: ok | dir_blocked | file_blocked | missing | denied. Memeriksa bit izin "other":
# proses audio HAL bukan root, jadi folder harus bisa dilewati dan file harus bisa dibaca.
su_probe_conf() {
  CONF_ACCESS=ok
  _d=/data/misc/audio; _f=$_d/sound_universal.conf
  if [ ! -f "$_f" ]; then CONF_ACCESS=missing; return 0; fi
  _dm=$(stat -c %a "$_d" 2>/dev/null); _fm=$(stat -c %a "$_f" 2>/dev/null)
  case "${_dm#${_dm%?}}" in 1|3|5|7) ;; ?*) CONF_ACCESS=dir_blocked ;; esac
  if [ "$CONF_ACCESS" = ok ]; then case "${_fm#${_fm%?}}" in 4|5|6|7) ;; ?*) CONF_ACCESS=file_blocked ;; esac; fi
  [ "$CONF_DENIED" != 1 ] || CONF_ACCESS=denied
}

# Runs all probes and sets SU_MODE. Runtime evidence beats path heuristics.
su_evaluate() {
  su_probe_config; su_probe_lib; su_probe_runtime; su_probe_log; su_probe_conf; su_probe_metamodule
  if [ -f "${SU_STATE_DIR:-/data/adb/sound_universal}/safe_mode" ]; then SU_MODE=quarantined
  elif [ "$RT_OK" = 1 ]; then SU_MODE=legacy_xml_runtime_loaded
  elif [ -n "$CFG_ACTIVE" ] && [ -n "$ACTIVE_LIB" ]; then
    if [ "$LOG_ERROR" = 1 ]; then SU_MODE=legacy_xml_load_error; else SU_MODE=legacy_xml_config_active; fi
  elif [ -n "$CFG_ACTIVE" ]; then SU_MODE=legacy_xml_config_active_library_missing
  else SU_MODE=legacy_xml_overlay_not_active
  fi
}

# Persists the result of su_evaluate into integration.status ($1 = previously staged config, optional).
su_write_result() {
  {
    echo "config=${CFG_ACTIVE:-none}"
    echo "library=${ACTIVE_LIB:-none}"
    [ -z "$RT_PROC" ] || echo "runtime_process=$RT_PROC"
    [ -z "$CFG_FIRST" ] || echo "first_config=$CFG_FIRST"
    [ -z "$1" ] || echo "staged_config=$1"
    [ "$KSU_ENV" != 1 ] || echo "metamodule=${MM_NAME:-none}"
    echo "conf_access=${CONF_ACCESS:-unknown}"
    echo "checked_at=$(su_now)"
    case "$SU_MODE" in
      legacy_xml_runtime_loaded) echo 'note=The native library is mapped inside an audio process: the hook loaded. Audible change still depends on the ROM audio path.' ;;
      quarantined) echo "reason=$(head -n 1 "${SU_STATE_DIR:-/data/adb/sound_universal}/safe_mode" 2>/dev/null)" ;;
      legacy_xml_config_active) echo 'note=Active XML and ABI-matched library are visible, but no audio process has loaded the library yet. Play audio, then check again.' ;;
      legacy_xml_load_error) echo 'note=XML and library are visible but logcat shows a load/SELinux error for RySound.' ;;
      legacy_xml_config_active_library_missing) echo 'reason=The active XML contains the RySound UUID but the matching soundfx library was not found in standard paths.' ;;
      legacy_xml_overlay_not_active) echo 'reason=The overlay was staged but the active audio_effects.xml does not contain the RySound UUID after boot.'
        echo 'note=Check that the module is enabled and that the root manager mounted module overlays before audioserver started.' ;;
    esac
  } | su_status_write "$SU_MODE"
}
