#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Kumpulkan log diagnosis ke /sdcard/Download/RySound_debug.txt (kirim file ini kalau hook gagal).
MODDIR=${1:-${0%/*}/..}
OUT="${SU_DEBUG_OUT:-/sdcard/Download/RySound_debug.txt}"
STATE="${SU_STATE_DIR:-/data/adb/sound_universal}"
mkdir -p "${OUT%/*}" 2>/dev/null
T="$OUT.tmp.$$"
sec() { { echo; echo "##### $*"; } >> "$T"; }
: > "$T" 2>/dev/null || { T="/data/local/tmp/RySound_debug.$$"; : > "$T" || exit 1; OUT="/data/local/tmp/RySound_debug.txt"; }
{
  echo "RySound debug - $(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
  echo "module: $(sed -n 's/^version=//p' "${MODDIR%/rysound}/module.prop" 2>/dev/null | head -n 1)"
} >> "$T"
sec DEVICE
{
  echo "model=$(getprop ro.product.model) device=$(getprop ro.product.device)"
  echo "android=$(getprop ro.build.version.release) sdk=$(getprop ro.build.version.sdk)"
  echo "rom=$(getprop ro.build.display.id)"
  echo "miui/hyperos=$(getprop ro.miui.ui.version.name) $(getprop ro.mi.os.version.name)"
  echo "abilist=$(getprop ro.product.cpu.abilist)"
  echo "selinux=$(getenforce 2>/dev/null)"
  echo "root: KSU=${KSU:-?} ksud=$([ -d /data/adb/ksu ] && echo yes || echo no) magisk=$(command -v magisk >/dev/null 2>&1 && magisk -v 2>/dev/null || echo no)"
  echo "boot_completed=$(getprop sys.boot_completed) boot_pending=$(cat "$STATE/boot_pending" 2>/dev/null)"
} >> "$T" 2>&1
sec STATUS
{ cat "$MODDIR/integration.status" 2>/dev/null || echo 'integration.status tidak ada'; echo '--- safe_mode:'; cat "$STATE/safe_mode" 2>/dev/null || echo 'tidak aktif'; echo '--- guard.log:'; tail -n 15 "$STATE/guard.log" 2>/dev/null; echo '--- service.log:'; tail -n 10 "$STATE/service.log" 2>/dev/null; } >> "$T" 2>&1
sec 'AUDIO EFFECT HAL (vintf)'
for mf in /vendor/etc/vintf/manifest.xml /vendor/etc/vintf/manifest/*.xml /odm/etc/vintf/manifest.xml /odm/etc/vintf/manifest/*.xml /system/etc/vintf/manifest.xml /system/etc/vintf/manifest/*.xml; do
  [ -f "$mf" ] && grep -H -A3 'android.hardware.audio.effect' "$mf" 2>/dev/null | head -n 8
done >> "$T" 2>&1
sec 'XML / LIBRARY'
for p in /odm/etc/audio_effects.xml /vendor/etc/audio_effects.xml /system_ext/etc/audio_effects.xml /system/etc/audio_effects.xml; do
  [ -s "$p" ] || continue
  echo "$p : $(grep -c 'sound_universal' "$p" 2>/dev/null) baris sound_universal"
done >> "$T" 2>&1
ls -lZ /vendor/lib64/soundfx/libsounduniversal.so /vendor/lib/soundfx/libsounduniversal.so /odm/lib64/soundfx/libsounduniversal.so /system/lib64/soundfx/libsounduniversal.so /system/lib/soundfx/libsounduniversal.so 2>&1 | grep -v 'No such file' >> "$T"
echo '--- overlay di modul:' >> "$T"; (cd "$MODDIR" && find . -maxdepth 6 -name "libsounduniversal*" -type f 2>/dev/null | head -n 15) >> "$T" 2>&1
sec 'CONFIG DSP'
{ ls -ldZ /data/misc/audio 2>&1; ls -lZ /data/misc/audio/sound_universal.conf 2>&1; cat /data/misc/audio/sound_universal.conf 2>&1; } >> "$T"
sec 'PROSES YANG MEMUAT LIBRARY'
grep -l 'libsounduniversal' /proc/[0-9]*/maps 2>/dev/null | while read -r m; do pid=${m#/proc/}; pid=${pid%/maps}; echo "pid=$pid comm=$(cat /proc/$pid/comm 2>/dev/null)"; done >> "$T"
sec 'LOGCAT EFEK AUDIO'
logcat -d -b all -t 12000 2>/dev/null | grep -iE 'sound_universal|sounduniversal|failed to create Fx|EffectsFactory|AudioPolicyEffects|EffectBundle|audio_effects|dlopen failed.*soundfx' | tail -n 50 | cut -c1-260 >> "$T"
sec 'SELINUX DENIAL AUDIO'
{ logcat -d -b all -t 12000 2>/dev/null | grep -E 'avc: +denied' | grep -iE 'hal_audio|audioserver|audio_data_file|sound_universal|soundfx' | tail -n 25 | cut -c1-300; dmesg 2>/dev/null | grep -E 'avc: +denied' | grep -iE 'hal_audio|audioserver|sound_universal' | tail -n 15 | cut -c1-300; } >> "$T"
sec 'CRASH BUFFER (audio)'
logcat -d -b crash 2>/dev/null | grep -iE 'audio|sounduniversal|effect' | tail -n 20 | cut -c1-260 >> "$T"
mv "$T" "$OUT" 2>/dev/null || OUT="$T"
chmod 0644 "$OUT" 2>/dev/null
echo "$OUT"
