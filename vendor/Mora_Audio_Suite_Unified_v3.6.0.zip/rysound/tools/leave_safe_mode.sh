#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Leave RySound safe mode: re-stage the hook (only RySound's own lines are touched), then reboot once.
MODRY=${1:-${0%/*}/..}
MODDIR=${MODRY%/rysound}
. "$MODDIR/lib/mora_lib.sh"
rm -f "$RYS_STATE/safe_mode"
echo 0 > "$RYS_STATE/boot_pending" 2>/dev/null
rm -f "$MODRY/integration.status"
if rys_stage "$MODDIR"; then
  echo 'Hasil: legacy_xml_staged'
  echo 'Hook disiapkan ulang. Reboot satu kali. Jika boot gagal 2x, mode aman aktif lagi otomatis (hanya RySound yang dimatikan).'
else
  echo "Hasil: $(rys_status_mode "$MODDIR")"
  echo "Hook tidak dipasang: $(sed -n 's/^reason=//p' "$MODRY/integration.status" 2>/dev/null | head -n 1)"
fi
exit 0
