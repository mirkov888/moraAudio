#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Re-stage the RySound hook inside the Mora overlays (kept for compatibility with RySound's own tools)
MODRY=${1:-${0%/*}/..}
MODDIR=${MODRY%/rysound}
. "$MODDIR/lib/mora_lib.sh"
rys_stage "$MODDIR"
exit 0
