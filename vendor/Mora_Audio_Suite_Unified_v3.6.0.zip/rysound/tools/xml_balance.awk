# Mora Audio Suite - made by Mora & Claude Code
# Hitung (tag buka - tag tutup) untuk tag penting audio_effects.xml.
# Patch yang benar hanya menambah pasangan tag seimbang, jadi hasilnya harus SAMA
# antara file asli dan file hasil patch.
function cnt(re, s,   t) { t = s; return gsub(re, "&", t) }
{
  lib   += cnt("<libraries([ >])", $0) - cnt("</libraries>", $0)
  eff   += cnt("<effects([ >])", $0) - cnt("</effects>", $0)
  post  += cnt("<postprocess([ >])", $0) - cnt("</postprocess>", $0)
  strm  += cnt("<stream[ >]", $0) - cnt("</stream>", $0)
  root  += cnt("<audio_effects_conf([ >])", $0) - cnt("</audio_effects_conf>", $0)
}
END { printf "lib=%d eff=%d post=%d stream=%d root=%d\n", lib, eff, post, strm, root }
