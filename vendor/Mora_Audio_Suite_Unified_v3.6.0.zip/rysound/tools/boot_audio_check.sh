#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Runs after the module overlay is mounted (service.sh) and whenever the WebUI is opened.
# Verifies the LIVE system view and records the result in integration.status.
MODPATH=${1:-${0%/*}/..}
SU_STATUS="$MODPATH/integration.status"
. "$MODPATH/tools/hook_probe.sh" 2>/dev/null || exit 0

# Mode aman: jangan pernah menyusun ulang overlay otomatis (itu akan membatalkan pengaman bootloop).
[ ! -f "${SU_STATE_DIR:-/data/adb/sound_universal}/safe_mode" ] || exit 0
OLD_MODE=$(su_status_get mode)
REGEN=0
case "$OLD_MODE" in
  webui_only|quarantined) exit 0 ;;
  '')
    # Status file missing: rebuild it instead of leaving the WebUI at "not verified".
    if ls "$MODPATH"/system/etc/audio_effects.xml "$MODPATH"/system/*/etc/audio_effects.xml >/dev/null 2>&1; then
      OLD_MODE=legacy_xml_staged
    else
      sh "$MODPATH/tools/install_audio_hook.sh" "$MODPATH" >/dev/null 2>&1
      OLD_MODE=$(su_status_get mode)
      REGEN=1
    fi
    [ -n "$OLD_MODE" ] && [ "$OLD_MODE" != "webui_only" ] || exit 0
    ;;
esac

# Same boot as the install: the overlay cannot be mounted yet, keep waiting for the reboot.
if [ "$REGEN" = 0 ] && su_pending_reboot; then exit 0; fi

STAGED_CFG=$(su_status_get staged_config)
[ -n "$STAGED_CFG" ] || STAGED_CFG=$(su_status_get config)
[ "$STAGED_CFG" != none ] || STAGED_CFG=''
su_evaluate
su_write_result "$STAGED_CFG"
exit 0
