# Matriks fitur RySound v0.7.0

| Fitur | Status | Catatan |
|---|---|---|
| Native AudioEffect legacy ABI | Tersedia pada build | Tergantung vendor HAL/XML dan proses audio |
| 20-band EQ | Tersedia di native | 20 biquad peaking, ±6 dB |
| Migrasi 10-band lama | Tersedia | Interpolasi 10 posisi ke 20 |
| Smart Bass | Tersedia di native | Low shelf 95 Hz, 0–6 dB |
| Vocal Enhancement | Tersedia di native | Presence sekitar 3.2 kHz, 0–3 dB |
| Dynamic Compressor | Tersedia di native | Basic envelope compressor |
| Soft Peak Limiter | Tersedia di native | Sample peak; bukan true peak |
| Stereo Width | Tersedia di native | Mid/side stereo; bukan HRTF |
| PCM16 / PCM_FLOAT | Tersedia di native | Format lain dipassthrough |
| Preset Manager | Tersedia di WebUI | Simpan hingga 30 preset kustom di file terpisah/browser fallback |
| JSON Save / Import / Export | Tersedia | Simpan sistem butuh API exec root |
| Backup / Rollback | Tersedia | Backup JSON + key/value config |
| Runtime diagnostic | Tersedia | Mengamati config/library/process mapping/logcat |
| WebUI dua halaman | Tersedia | Home dan Audio Control |
| Legacy/HIDL installer | Percobaan terproteksi | Bukan jaminan berhasil di semua ROM |
| AIDL Audio Effects HAL | Belum tersedia | Installer skip ke WebUI-only |
| HRTF / Spatial Audio | Belum tersedia | Tidak ada renderer 3D |
| Real-time Audio Analyzer | Belum tersedia | Tidak ada PCM tap |
| Auto Game/Music/Movie Profile | Belum tersedia | Belum ada foreground app service |
| Speaker/Headset/Bluetooth auto-detect | Belum tersedia | Belum ada route listener |
| True Peak Limiter | Belum tersedia | Tidak ada oversampling |
| Hardware DSP acceleration | Tidak diklaim | Pemrosesan yang ada adalah software |
| Android 10–17 physical device validation | Belum dilakukan | Butuh matriks pengujian perangkat |
