# RySound v0.7.0 — Native DSP audit

## Scope

Audited and modified the uploaded `Sound_universal_Rye_v0_6_1_CleanWebUI.zip`. The existing module ID (`sound_universal`), UUID and persistent settings paths are intentionally retained so an in-place upgrade keeps the previous module state and legacy effect identity.

## Findings in the supplied v0.6.1 source

1. The native DSP had ten peaking EQ bands, while the requested interface and release target required twenty.
2. Descriptor flag bit positions for insert-first, input-direct and output-direct did not match the AOSP `effect_flags_t` bit fields. The v0.7.0 source uses the AOSP bit positions.
3. The native command callback returned success for unsupported/failed commands instead of returning their status.
4. No CMake/Android NDK build project or reproducible NDK build script was present.
5. The WebUI was effectively one long page, not the requested two-page navigation. Its engine status card was hidden by CSS.
6. Android 14+ AIDL Audio Effects HAL was not implemented. The existing installer detects AIDL in VINTF and skips the legacy XML hook, which is retained.
7. The old 10-band config format needed a deterministic upgrade path to avoid dropping previous EQ values.
8. Documentation mixed historic release state and current feature claims; rewritten to separate tested and untested behavior.

## v0.7.0 changes

### Native source

- Expanded software EQ from 10 to 20 logarithmically spaced peaking biquads (31.5 Hz to approximately 15.6 kHz), ±6 dB per band.
- Legacy 10-band settings are interpolated across the 20 new center frequencies in the native parser and in WebUI migration.
- Corrected AudioEffect descriptor flags to the AOSP fields: `INSERT_FIRST` bit 3, input-direct bit 12 and output-direct bit 14; post-process bit remains bit 2.
- Unsupported native commands return `-ENOSYS`; reply size is zero for commands without a reply payload.
- Retained the background settings watcher so disk I/O is not performed in the PCM callback.
- Added finite-value sanitization and safe sample bounds, buffer size checks and Nyquist filter bypass behavior.
- Descriptor branding changed to `RySound 20-band DSP`.
- Added `CMakeLists.txt` and `build_android.sh` for Android NDK builds.

### DSP features actually present in native source

| Feature | Implementation | Limit |
|---|---|---|
| 20-band EQ | 20 peaking biquads | Software; ±6 dB/band |
| Smart Bass | 95 Hz low-shelf biquad | 0 to +6 dB |
| Vocal enhancement | 3.2 kHz presence biquad | 0 to +3 dB |
| Dynamic compression | Shared peak envelope with fixed attack/release | Basic single-band compressor |
| Limiter | Soft sample-peak tanh curve | Not true-peak; no oversampling |
| Stereo width | Mid/side gain adjustment | Stereo only; not HRTF/spatial rendering |
| PCM | PCM16 and PCM_FLOAT processing | Other recognized formats pass through |

### Installer / config / WebUI

- Retained the previous root-manager installer and postboot diagnosis rather than replacing the working overlay logic.
- Preserved module id, state folder, config file, type UUID and implementation UUID.
- Default and preset configuration expanded to twenty band values.
- Settings synchronization emits twenty keys for schema v5 and keeps legacy schema v4 settings in their original ten-key representation until saved by the new UI; native parsing interpolates them.
- Import schema validation checks accepted schema versions, value types and EQ arrays of ten or twenty numeric values; parameter values are normalized to bounded engine ranges.
- WebUI now has exactly two page containers: `page-home` and `page-advanced`, with no page reload on navigation, 250 ms fade/slide, reduced-motion support, and responsive layout.
- Backup and rollback actions operate on the root-persisted JSON and DSP key/value file. They require a compatible root manager WebUI `exec` API and report failure if it is unavailable.
- UI labels unsupported features as unavailable instead of pretending they are running.

## Build provenance

The environment did not contain a complete official Android NDK/sysroot. The bundled ARM64 and ARMv7 shared objects were compiled using Clang 17 with Android API 21 target triples and verified as ELF AArch64 / ARM EABI5, with `AELI` exported and Android libc/libm dynamic imports. Minimal target-ABI link stubs were used only to provide libc/libm SONAME dependencies during linking; those stubs are **not** packaged. This is not claimed as an official NDK build. For reproducible official NDK builds use `native_effect/build_android.sh`.

## Tests performed in this build session

- Host DSP smoke test: PASS for PCM float + PCM16 processing, finite/bounded output, disabled passthrough, and legacy ten-band EQ migration.
- Shell syntax: PASS for every `.sh` file using `sh -n`.
- Configuration synchronization: PASS; schema v5 emits twenty EQ lines; schema v4 preserves ten old lines.
- XML injector fixture: PASS; patched XML includes library/effect UUID and tag balance remains unchanged.
- WebUI JavaScript syntax: PASS using Node.js `--check`.
- WebUI page count: PASS; exactly two page containers (`home`, `advanced`).
- ELF inspection: PASS; AArch64 and ARM EABI5 shared objects, expected SONAME, `AELI` exported, expected Android libc/libm imports.

## Not tested / not implemented

- No physical Android phone or vendor HAL was available. No actual audio playback, audioserver loading, SELinux runtime, latency, audio dropout, CPU load, thermal behavior or subjective sound test was performed.
- No official NDK build was run in this environment. The provided NDK build recipe is included for reproducibility.
- No AIDL `IFactory`/`IEffect` implementation. AIDL HAL devices remain `WEBUI ONLY`.
- No real-time PCM analyzer, audio spectrum tap, app foreground automation, per-app profiles, speaker/headphone/Bluetooth detection, HRTF renderer, or true-peak oversampling limiter.
- ABI files being present does not guarantee that vendor policy, soundfx paths, XML schema, root mount behavior, or direct/offload routes accept the plugin.

## References

- AOSP `hardware/audio_effect.h`: effect descriptor flags and legacy AudioEffect ABI.
- AOSP AIDL Audio HAL implementation: AIDL uses its own factory/effect service interface; legacy XML patching is not an AIDL implementation.
