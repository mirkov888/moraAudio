# Native library build

This folder contains the AudioEffect legacy ABI source, a CMake project and a build helper.

## Rebuild with Android NDK

Run from a shell that has CMake and a complete Android NDK installed:

```sh
export ANDROID_NDK_HOME=/path/to/android-ndk
sh ./build_android.sh
```

The helper builds `arm64-v8a` and `armeabi-v7a` with Android API 21 and writes:

- `build/libsounduniversal.so` (ARM64)
- `build/libsounduniversal_arm.so` (ARMv7)

ARMv7 is best-effort and must be validated on the target ROM. Do not overwrite the packaged libraries with a host/Linux build. The library depends on Android bionic libc/libm and is loaded by the device audio framework.

## Current package provenance

The build environment used for this release did not have the complete official NDK toolchain/sysroot. The included binaries were cross-targeted with Clang 17 for Android API 21 ELF ABIs; they were not built by running the NDK helper. Use the helper above to reproduce with an official NDK installation.
