#!/system/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
NDK=${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}
[ -n "$NDK" ] && [ -f "$NDK/build/cmake/android.toolchain.cmake" ] || {
  echo "ERROR: Set ANDROID_NDK_HOME to an installed Android NDK." >&2
  exit 2
}
OUT="$ROOT/build"
mkdir -p "$OUT"
for ABI in arm64-v8a armeabi-v7a; do
  BUILD="$OUT/cmake-$ABI"
  cmake -S "$ROOT" -B "$BUILD" \
    -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="$ABI" -DANDROID_PLATFORM=android-21 \
    -DANDROID_STL=none -DCMAKE_BUILD_TYPE=Release
  cmake --build "$BUILD" --parallel
  case "$ABI" in
    arm64-v8a) cp "$BUILD/libsounduniversal.so" "$OUT/libsounduniversal.so" ;;
    armeabi-v7a) cp "$BUILD/libsounduniversal.so" "$OUT/libsounduniversal_arm.so" ;;
  esac
done
printf 'Built Android shared libraries in %s\n' "$OUT"
