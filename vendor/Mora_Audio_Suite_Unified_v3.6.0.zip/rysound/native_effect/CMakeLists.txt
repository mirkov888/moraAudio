cmake_minimum_required(VERSION 3.22.1)
project(RySoundNativeEffect VERSION 0.7.0 LANGUAGES C)

if(NOT ANDROID)
    message(FATAL_ERROR "Build this shared library with the Android NDK toolchain.")
endif()

add_library(sounduniversal SHARED src/sound_universal_effect.c)
target_include_directories(sounduniversal PRIVATE include)
target_compile_features(sounduniversal PRIVATE c_std_11)
target_compile_definitions(sounduniversal PRIVATE SU_CONFIG_PATH=\"/data/misc/audio/sound_universal.conf\")
target_compile_options(sounduniversal PRIVATE
    -O2 -fPIC -fno-builtin -fvisibility=hidden -Wall -Wextra
    -Wno-unused-parameter -Wno-missing-field-initializers
)
target_link_libraries(sounduniversal PRIVATE m)
target_link_options(sounduniversal PRIVATE
    -Wl,-z,nodelete
    -Wl,--hash-style=both
    -Wl,-soname,libsounduniversal.so
)
set_target_properties(sounduniversal PROPERTIES
    OUTPUT_NAME sounduniversal
    C_VISIBILITY_PRESET hidden
    VISIBILITY_INLINES_HIDDEN YES
)

# Android NDK ABIs supported by the supplied installer. arm64-v8a is the
# primary target; armeabi-v7a is best-effort and must be validated per ROM.
