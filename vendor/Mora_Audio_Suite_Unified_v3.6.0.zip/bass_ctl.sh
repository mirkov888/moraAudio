#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Usage: bass_ctl.sh status | apply | set KEY VALUE   (KEY: BB_BASS BB_STRENGTH BB_LOUDNESS BB_TARGET BB_DP BB_GAIN)
MODDIR="${0%/*}"
. "$MODDIR/lib/mora_lib.sh"
cfg_init
status() {
    local inst=0 st=0
    bb_installed && inst=1
    bb_staged && st=1
    printf '{"staged":%s,"installed":%s,"bass":%s,"strength":%s,"loudness":%s,"target":%s,"dp":%s,"gain":%s}\n' \
        "$st" "$inst" "$(cfg_get BB_BASS)" "$(cfg_get BB_STRENGTH)" "$(cfg_get BB_LOUDNESS)" "$(cfg_get BB_TARGET)" "$(cfg_get BB_DP)" "$(cfg_get BB_GAIN)"
}
case "$1" in
    set)
        case "$2" in BB_*) ;; *) printf '{"status":"error","message":"key"}\n'; exit 1 ;; esac
        if cfg_set "$2" "$3"; then
            case "$2" in
                BB_BASS) a=SET_BASS_ENABLED ;; BB_STRENGTH) a=SET_BASS_STRENGTH ;; BB_LOUDNESS) a=SET_LOUDNESS_ENABLED ;;
                BB_TARGET) a=SET_LOUDNESS_TARGET ;; BB_DP) a=SET_DP_ENABLED ;; BB_GAIN) a=SET_LOW_GAIN ;;
            esac
            bb_installed && bb_send "$a" "$3"
            printf '{"status":"success","key":"%s","value":"%s","live":%s}\n' "$2" "$3" "$(bb_installed && echo 1 || echo 0)"
        else printf '{"status":"error","message":"invalid value"}\n'; exit 1; fi ;;
    apply) if bb_apply; then printf '{"status":"success"}\n'; else printf '{"status":"error","message":"BassBoost app not installed yet (reboot once)"}\n'; exit 1; fi ;;
    *) status ;;
esac
