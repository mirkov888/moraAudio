#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Battery + temperature snapshot as JSON.
B=/sys/class/power_supply/battery
rd() { cat "$1" 2>/dev/null | head -n 1; }
lvl="$(rd $B/capacity)"; bt="$(rd $B/temp)"; st="$(rd $B/status)"; cur="$(rd $B/current_now)"; volt="$(rd $B/voltage_now)"
max=0
for z in /sys/class/thermal/thermal_zone*/temp; do
    t="$(rd "$z")"; case "$t" in ''|*[!0-9-]*) continue ;; esac
    [ "$t" -gt 1000 ] && t=$((t / 1000)); [ "$t" -gt 120 ] && continue
    [ "$t" -gt "$max" ] && max="$t"
done
bt_c=0; [ -n "$bt" ] && bt_c=$((bt / 10))
cur_ma=0; [ -n "$cur" ] && { cur_ma=$((cur / 1000)); [ "${cur#-}" -lt 20000 ] && cur_ma=$cur; }
volt_mv=0; [ -n "$volt" ] && volt_mv=$((volt / 1000))
printf '{"level":%s,"status":"%s","bat_temp":%s,"max_temp":%s,"current_ma":%s,"voltage_mv":%s}\n' "${lvl:-0}" "${st:-?}" "$bt_c" "$max" "$cur_ma" "$volt_mv"
