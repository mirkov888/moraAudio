#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
MODDIR=${0%/*}
. "$MODDIR/lib/mora_lib.sh"
mlog "=== post-fs-data (Mora Audio Suite $(grep '^version=' "$MODDIR/module.prop" | cut -d= -f2)) ==="
cfg_init

# 1. A user may have installed NLSound / Audio Misc / a ViPER module on top of this suite
if [ "$(cfg_get GUARD)" = 1 ]; then
    for id in $(conflict_disable); do touch "$MORA_DATA/conflict_$id"; done
fi

# 2. ViPER registration: keep it present in every audio_effects overlay (also after ROM updates)
v4a_refresh "$MODDIR"

# 2a0. Effect Hub (other modules' effect libraries), with its own boot guard
fx_boot "$MODDIR"

# 2a. RySound software DSP effect: patch / undo / boot-guard (touches only its own lines and library)
rys_boot "$MODDIR"

# 2b. USB sample-rate modules ship their own patched libalsautils: step aside while they are active
OTHERS=/data/adb/modules
if { [ -d $OTHERS/usb-samplerate-unlocker ] && [ ! -e $OTHERS/usb-samplerate-unlocker/disable ]; } || \
   { [ -d $OTHERS/audio-samplerate-changer ] && [ ! -e $OTHERS/audio-samplerate-changer/disable ]; }; then
    for base in "$MODDIR/system/vendor" "$MODDIR/vendor"; do
        for d in lib lib64; do for l in libalsautils.so libalsautilsv2.so audio_usb_aoc.so; do
            [ -r "$base/$d/$l" ] && { rel="${base#$MODDIR}"; mkdir -p "$MODDIR/save$rel/$d" 2>/dev/null; mv -f "$base/$d/$l" "$MODDIR/save$rel/$d/$l"; mlog "stepped aside: $l"; }
        done; done
    done
else
    for s in $(find "$MODDIR/save" -type f 2>/dev/null); do
        t="$MODDIR${s#$MODDIR/save}"
        [ -d "${t%/*}" ] && mv -f "$s" "$t" && chmod 644 "$t"
    done
fi

# 2c. Dolby DAX config variant (only does anything when a non-stock state was saved)
dax_boot

# 2d. WebUI banner (re-applied because module updates restore the default file)
banner_apply "$MODDIR"

# 3. Some ROMs read /odm/etc directly and ignore the overlay; bind our copy explicitly
for f in "$MODDIR"/odm/etc/audio_effects* "$MODDIR"/system/odm/etc/audio_effects*; do
    [ -f "$f" ] || continue
    t="/odm/etc/$(basename "$f")"
    [ -f "$t" ] && mount -o bind "$f" "$t" 2>/dev/null && mlog "bound $t"
done

# 4. Properties: one owner for everything audio-related (Mora, Audio Misc and NLSound values merged)
apply_mode_props "$(cfg_get MODE)"
exit 0
