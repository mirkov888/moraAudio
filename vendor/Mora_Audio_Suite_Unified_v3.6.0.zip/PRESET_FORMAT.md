# Mora Audio Preset Format

The WebUI imports/exports JSON with schema `mora-audio-preset`, version 1. Fields: `name`, `route` (`iem_dac`, `phone_speaker`, `other`), `bass`, `mids`, `treble`, and `preamp` (dB target values). These are guidance values only and are not directly loaded by ViPER or Android's audio engine.
