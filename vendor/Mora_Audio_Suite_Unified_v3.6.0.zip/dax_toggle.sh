#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Usage: dax_toggle.sh status | set <stock|new|bal3|bal6|bal9|bal12> | next
MODDIR="${0%/*}"
. "$MODDIR/lib/mora_lib.sh"
js() { printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }
status() {
    local sup=0 st hash="" match=0 stockhash=""
    dax_supported && sup=1
    st="$(dax_state)"
    if [ -f "$DAX_DIR/stock.xml" ]; then stockhash="$(sha256sum "$DAX_DIR/stock.xml" 2>/dev/null | cut -d' ' -f1)"; elif dolby_present; then stockhash="$(sha256sum "$DAX_TARGET" 2>/dev/null | cut -d' ' -f1)"; fi
    [ "$stockhash" = "$DAX_STOCK_HASH" ] && match=1
    printf '{"supported":%s,"dolby":%s,"state":"%s","stock_matches":%s,"device":"%s"}\n' "$sup" "$(dolby_present && echo 1 || echo 0)" "$st" "$match" "$(js "$(getprop ro.product.device)")"
}
case "$1" in
    set|next)
        if [ "$1" = next ]; then
            case "$(dax_state)" in stock) t=new ;; new) t=bal3 ;; bal3) t=bal6 ;; bal6) t=bal9 ;; bal9) t=bal12 ;; *) t=stock ;; esac
        else t="$2"; fi
        dax_set "$MODDIR" "$t"; rc=$?
        case $rc in
            0) [ "$NO_RESTART" = 1 ] || dax_reload; printf '{"status":"success","state":"%s"}\n' "$t" ;;
            3) printf '{"status":"error","message":"Dolby (dms-hal-2-0) not found on this ROM"}\n'; exit 1 ;;
            2) printf '{"status":"error","message":"unknown state"}\n'; exit 1 ;;
            *) printf '{"status":"error","message":"mount failed, reverted to stock"}\n'; exit 1 ;;
        esac ;;
    *) status ;;
esac
