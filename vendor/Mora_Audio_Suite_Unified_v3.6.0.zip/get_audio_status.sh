#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code

MODDIR="${0%/*}"
. "$MODDIR/lib/mora_lib.sh"
cfg_init

# Audio Misc Settings - Audio Output Session & Status Query Script
# Outputs JSON to stdout for KernelSU WebUI

proc_cards="$(cat /proc/asound/cards 2>/dev/null)"
proc_streams="$(cat /proc/asound/card*/stream0 /proc/asound/card*/usbmix 2>/dev/null)"
proc_hwparams="$(cat /proc/asound/card*/pcm*/sub*/hw_params 2>/dev/null)"

dumpsys_audio="$(timeout 1 dumpsys audio 2>/dev/null | grep -iE "USB|A2DP|BLUETOOTH|WIRED|device|mDevice|name=|alias=" | head -n 50)"
dumpsys_policy="$(timeout 1 dumpsys media.audio_policy 2>/dev/null | grep -iE "USB|A2DP|BLUETOOTH|WIRED|device|stream" | head -n 30)"
dumpsys_flinger="$(timeout 1 dumpsys media.audio_flinger 2>/dev/null | grep -iE "Sample rate|format|bits|PCM|rate:" | head -n 30)"

combined="${dumpsys_audio}
${dumpsys_policy}
${dumpsys_flinger}"

# 1. Accurate USB DAC Hardware Detection
is_usb=0
if echo "$proc_cards" | grep -qi "USB" || [ -n "$proc_streams" ]; then
    is_usb=1
fi

# 2. Accurate Bluetooth Audio Connection Detection
is_bt=0
bt_dump=""
if [ -n "$(getprop bluetooth.profile.a2dp.source.enabled)" ] || [ -n "$(getprop init.svc.bluetooth)" ]; then
    bt_dump="$(timeout 1 dumpsys bluetooth_manager 2>/dev/null | tr -d '\r')"
    if [ -n "$bt_dump" ]; then
        bt_a2dp_active="$(echo "$bt_dump" | grep -A 2 "Profile: A2dpService" | grep "mActiveDevice:" | grep -v "null")"
        bt_peer_active="$(echo "$bt_dump" | grep -A 2 "A2DP Peers State:" | grep -i "active peer:" | grep -v "null")"
        if [ -n "$bt_a2dp_active" ] || [ -n "$bt_peer_active" ]; then
            is_bt=1
        fi
    fi
fi

# 3. DAC Name & USB Sync Mode
dac_name=""
sync_mode="ASYNC Mode"

if [ "$is_usb" -eq 1 ]; then
    if [ -n "$proc_streams" ]; then
        dac_name="$(echo "$proc_streams" | grep -iE "^[A-Za-z0-9]" | head -n 1 | sed 's/ at usb.*//' | tr -d '"' | xargs 2>/dev/null)"
    fi

    if [ -z "$dac_name" ] && [ -n "$proc_cards" ]; then
        dac_name="$(echo "$proc_cards" | grep -i "USB" | head -n 1 | sed 's/.*- //' | tr -d '"' | xargs 2>/dev/null)"
    fi

    if [ -z "$dac_name" ]; then
        dac_name="External USB Audio DAC"
    fi

    if echo "$proc_streams" | grep -q "ASYNC"; then
        sync_mode="ASYNC (Asynchronous Mode)"
    elif echo "$proc_streams" | grep -q "ADAPTIVE"; then
        sync_mode="ADAPTIVE (Adaptive Mode)"
    elif echo "$proc_streams" | grep -q "SYNC"; then
        sync_mode="SYNC (Synchronous Mode)"
    fi
fi

# 4. Bluetooth Name & Codec
bt_name=""
bt_codec=""
if [ "$is_bt" -eq 1 ]; then
    active_mac_suffix="$(echo "$bt_dump" | grep -A 2 "Profile: A2dpService" | grep "mActiveDevice:" | head -n 1 | sed 's/.*mActiveDevice:[[:space:]]*//' | tr -d ' ' | tail -c 6)"

    if [ -n "$active_mac_suffix" ]; then
        bt_name="$(echo "$bt_dump" | grep -i "$active_mac_suffix" | grep "name:" | head -n 1 | sed 's/.*name:["]*//' | sed 's/["]* sec_prop:.*//' | sed 's/["]*$//' | xargs 2>/dev/null)"
    fi

    if [ -z "$bt_name" ]; then
        bt_name="$(echo "$bt_dump" | grep -i "name:" | grep -v "POCO" | grep -v "Xiaomi" | grep -v "Android" | grep -v "Player name" | head -n 1 | sed 's/.*name:["]*//' | sed 's/["]* sec_prop:.*//' | sed 's/["]*$//' | xargs 2>/dev/null)"
    fi

    if [ -z "$bt_name" ]; then bt_name="Bluetooth Headset"; fi

    raw_codec="$(echo "$bt_dump" | grep "Current Codec:" | head -n 1 | sed 's/.*Current Codec:[[:space:]]*//' | xargs 2>/dev/null)"
    if [ -z "$raw_codec" ]; then
        raw_codec="$(echo "$bt_dump" | grep -o "codecName:[A-Za-z0-9 _-]*" | head -n 1 | sed 's/codecName://' | xargs 2>/dev/null)"
    fi

    if echo "$raw_codec" | grep -qi "LDAC"; then
        ldac_mode="$(echo "$bt_dump" | grep -i "LDAC quality mode" | head -n 1 | sed 's/.*:[[:space:]]*//' | tr -d '\r' | xargs 2>/dev/null)"
        ldac_bitrate="$(echo "$bt_dump" | grep -i "LDAC transmission bitrate" | head -n 1 | tr -cd '0-9')"
        
        if [ "$ldac_mode" = "ABR" ]; then
            if [ -n "$ldac_bitrate" ] && [ "$ldac_bitrate" -gt 0 ]; then
                bt_codec="LDAC (Adaptive / ${ldac_bitrate} kbps)"
            else
                bt_codec="LDAC (Adaptive Quality)"
            fi
        elif [ "$ldac_mode" = "HIGH" ] || [ "$ldac_bitrate" = "990" ]; then
            bt_codec="LDAC (Sound Quality ~990 kbps)"
        elif [ "$ldac_mode" = "MID" ] || [ "$ldac_bitrate" = "660" ]; then
            bt_codec="LDAC (Balanced ~660 kbps)"
        elif [ "$ldac_mode" = "LOW" ] || [ "$ldac_bitrate" = "330" ]; then
            bt_codec="LDAC (Connection Priority ~330 kbps)"
        elif [ -n "$ldac_mode" ]; then
            bt_codec="LDAC (${ldac_mode})"
        else
            bt_codec="LDAC (Mastering Quality)"
        fi
    elif echo "$raw_codec" | grep -qiE "aptX[-_ ]*Adaptive|aptX-adaptive"; then
        bt_codec="aptX Adaptive"
    elif echo "$raw_codec" | grep -qiE "aptX[-_ ]*HD|aptX-HD"; then
        bt_codec="aptX HD (High Definition)"
    elif echo "$raw_codec" | grep -qi "aptX"; then
        bt_codec="aptX"
    elif echo "$raw_codec" | grep -qi "AAC"; then
        bt_codec="AAC"
    elif echo "$raw_codec" | grep -qi "SBC"; then
        bt_codec="SBC"
    elif echo "$raw_codec" | grep -qi "LHDC"; then
        bt_codec="LHDC / Hi-Res Audio"
    elif [ -n "$raw_codec" ]; then
        bt_codec="$raw_codec"
    else
        bt_codec="A2DP Audio"
    fi
fi

# 5. Active Route Name
active_route="Built-in Speaker"
if [ "$is_usb" -eq 1 ]; then
    active_route="USB DAC ($dac_name)"
elif [ "$is_bt" -eq 1 ]; then
    active_route="Bluetooth ($bt_name)"
elif echo "$dumpsys_audio" | grep -qi "WIRED_HEADSET" || echo "$dumpsys_audio" | grep -qi "WIRED_HEADPHONE"; then
    active_route="3.5mm Headphone Jack"
fi

# 6. Active Sample Rate & Bit Depth Detection
sample_rate_num=0
bit_depth=24
format_lbl="PCM"

# If Bluetooth is active, check Bluetooth over-the-air sample rate and bit depth first
if [ "$is_bt" -eq 1 ]; then
    bt_sr="$(echo "$bt_dump" | grep 'Config: Rate=' | grep -v 'Invalid' | head -n 1 | sed 's/.*Rate=//' | sed 's/[[:space:]].*//' | tr -cd '0-9')"
    if [ -n "$bt_sr" ] && [ "$bt_sr" -gt 0 ]; then
        sample_rate_num="$bt_sr"
    fi

    bt_bits="$(echo "$bt_dump" | grep 'Config: Rate=' | grep -v 'Invalid' | head -n 1 | sed 's/.*Bits=//' | sed 's/[[:space:]].*//' | tr -cd '0-9')"
    if [ -n "$bt_bits" ] && [ "$bt_bits" -gt 0 ]; then
        bit_depth="$bt_bits"
    fi
fi

# Direct query active un-standby output thread in AudioFlinger (Standby: no)
if [ "$sample_rate_num" -eq 0 ]; then
    active_sr="$(timeout 1 dumpsys media.audio_flinger 2>/dev/null | grep -v '^-' | grep -A 5 -B 1 'Standby: no' | grep 'Sample rate:' | tr -cd '0-9\n' | grep -E '^[0-9]+$' | sort -nr | head -n 1)"
    if [ -n "$active_sr" ] && [ "$active_sr" -gt 0 ]; then
        sample_rate_num="$active_sr"
    fi
fi

active_fmt="$(timeout 1 dumpsys media.audio_flinger 2>/dev/null | grep -A 8 -B 1 'Standby: no' | grep -iE 'HAL format:|Processing format:' | head -n 1)"
if echo "$active_fmt" | grep -qiE "32|FLOAT"; then bit_depth=32;
elif echo "$active_fmt" | grep -qi "24"; then bit_depth=24;
elif echo "$active_fmt" | grep -qi "16"; then bit_depth=16;
fi

# Fallback check ALSA proc hw_params if active playback
if [ "$sample_rate_num" -eq 0 ] && [ -n "$proc_hwparams" ] && ! echo "$proc_hwparams" | grep -q "closed"; then
    sr="$(echo "$proc_hwparams" | grep -i "rate:" | head -n 1 | tr -cd '0-9')"
    if [ -n "$sr" ]; then sample_rate_num="$sr"; fi

    fmt="$(echo "$proc_hwparams" | grep -i "format:" | head -n 1 | tr -d '"')"
    if echo "$fmt" | grep -q "32"; then bit_depth=32;
    elif echo "$fmt" | grep -q "16"; then bit_depth=16;
    fi
fi

# Fallback check ALSA stream0 for Momentary freq
if [ "$sample_rate_num" -eq 0 ] && [ -n "$proc_streams" ]; then
    sr="$(echo "$proc_streams" | grep -i "Momentary freq" | head -n 1 | tr -cd '0-9')"
    if [ -n "$sr" ]; then sample_rate_num="$sr"; fi
fi

# Fallback check any AudioFlinger sample rate thread
if [ "$sample_rate_num" -eq 0 ] && [ -n "$dumpsys_flinger" ]; then
    sr="$(echo "$dumpsys_flinger" | grep -i "Sample rate:" | head -n 1 | tr -cd '0-9')"
    if [ -n "$sr" ]; then sample_rate_num="$sr"; fi
fi

# Sanitize sample_rate_num
case "$sample_rate_num" in
    ''|*[!0-9]*) sample_rate_num=0 ;;
esac

sample_rate_str="48,000 Hz (48 kHz)"
bitrate_str="16-bit / 1536 kbps PCM"

if [ "$sample_rate_num" -gt 0 ]; then
    khz=$((sample_rate_num / 1000))
    sample_rate_str="${sample_rate_num} Hz (${khz} kHz)"
    calculated_bitrate=$(( (sample_rate_num * bit_depth * 2) / 1000 ))
    bitrate_str="${bit_depth}-bit PCM / ${calculated_bitrate} kbps (${format_lbl})"
elif [ "$is_usb" -eq 1 ]; then
    sample_rate_str="USB DAC Connected (Active Stream)"
    bitrate_str="24-bit / 4608 kbps High-Res PCM"
fi

vol_steps="$(getprop ro.config.media_vol_steps)"
if [ -z "$vol_steps" ]; then vol_steps="100"; fi

resampler="$(getprop af.resampler.quality)"
if [ -z "$resampler" ]; then resampler="Default (Dynamic Hi-Fi)"; fi

offload_24bit="$(getprop audio.offload.pcm.24bit.enable)"
if [ -z "$offload_24bit" ]; then offload_24bit="false"; fi

flinger_standby="$(getprop ro.audio.flinger_standbytime_ms)"
if [ -z "$flinger_standby" ]; then flinger_standby="default"; fi

psd_stopband="$(getprop ro.audio.resampler.psd.stopband)"
if [ -z "$psd_stopband" ]; then psd_stopband="default"; fi

ignore_fx="$(getprop ro.audio.ignore_effects)"
spatializer="$(getprop ro.audio.spatializer_enabled)"
safemedia="$(getprop audio.safemedia.bypass)"
usb_period="$(getprop vendor.audio.usb.perio)"
platform="$(getprop ro.board.platform)"
arch="$(getprop ro.product.cpu.abi)"
audioserver_pid="$(getprop init.svc_debug_pid.audioserver)"

mode_val="$(cfg_get MODE)"

int_codec="$(getprop persist.vendor.audio.hifi.int_codec)"
if [ -z "$int_codec" ]; then int_codec="true"; fi

adm_buffering="$(getprop vendor.audio.adm.buffering.ms)"
if [ -z "$adm_buffering" ]; then adm_buffering="6"; fi

deep_buffer="$(getprop audio.deep_buffer.media)"
if [ -z "$deep_buffer" ]; then deep_buffer="false"; fi

# ViPER driver status: registered in a config file, and actually loaded by AudioFlinger
viper_registered=0
if grep -rqs "v4a_standard_re" /vendor/etc /odm/etc /system/etc /product/etc 2>/dev/null; then viper_registered=1; fi
viper_loaded=0
if timeout 2 dumpsys media.audio_flinger 2>/dev/null | grep -qi "90380da3-8536-4744-a6a3-5731970e640f"; then viper_loaded=1; fi
viper_lib=0
for l in /vendor/lib64/soundfx/libv4a_re.so /vendor/lib/soundfx/libv4a_re.so; do [ -f "$l" ] && viper_lib=1; done
android_ver="$(getprop ro.build.version.release)"
device_name="$(getprop ro.product.model)"

has_tinymix=0
if type tinymix >/dev/null 2>&1 || type tinymix_ext >/dev/null 2>&1; then has_tinymix=1; fi

# Sanitize string variables for clean JSON output
dac_name="$(echo "$dac_name" | tr -d '"\\\r\n' | xargs 2>/dev/null || echo "$dac_name" | tr -d '"\\\r\n')"
active_route="$(echo "$active_route" | tr -d '"\\\r\n' | xargs 2>/dev/null || echo "$active_route" | tr -d '"\\\r\n')"
sample_rate_str="$(echo "$sample_rate_str" | tr -d '"\\\r\n' | xargs 2>/dev/null || echo "$sample_rate_str" | tr -d '"\\\r\n')"
bitrate_str="$(echo "$bitrate_str" | tr -d '"\\\r\n' | xargs 2>/dev/null || echo "$bitrate_str" | tr -d '"\\\r\n')"
bt_name="$(echo "$bt_name" | tr -d '"\\\r\n' | xargs 2>/dev/null || echo "$bt_name" | tr -d '"\\\r\n')"
bt_codec="$(echo "$bt_codec" | tr -d '"\\\r\n' | xargs 2>/dev/null || echo "$bt_codec" | tr -d '"\\\r\n')"
mode_val="$(echo "$mode_val" | tr -d '"\\\r\n' | xargs 2>/dev/null || echo "$mode_val" | tr -d '"\\\r\n')"

jstr() { printf '%s' "$1" | tr -d '"\\\r\n' ; }
J=""
ja() { J="${J}${J:+,}\"$1\":\"$(jstr "$2")\""; }
jn() { J="${J}${J:+,}\"$1\":$2"; }
jn is_usb "$is_usb"; jn is_bt "$is_bt"
ja dac_name "$dac_name"; ja sync_mode "$sync_mode"; ja bt_name "$bt_name"; ja bt_codec "$bt_codec"
ja active_route "$active_route"; ja sample_rate "$sample_rate_str"; ja bitrate "$bitrate_str"
ja vol_steps "$vol_steps"; ja resampler "$resampler"; ja ignore_fx "$ignore_fx"; ja spatializer "$spatializer"
ja safemedia "$safemedia"; ja usb_period "$usb_period"; ja platform "$platform"; ja arch "$arch"
ja audioserver_pid "$audioserver_pid"; ja mode "$mode_val"; ja int_codec "$int_codec"
ja adm_buffering "$adm_buffering"; ja deep_buffer "$deep_buffer"; jn has_tinymix "$has_tinymix"
ja offload_24bit "$offload_24bit"; ja flinger_standby "$flinger_standby"; ja psd_stopband "$psd_stopband"
ja viper_reason "$(V4A_ENGINE=$viper_loaded v4a_reason "$MODDIR" 2>/dev/null)"; jn viper_registered "$viper_registered"; jn viper_loaded "$viper_loaded"; jn viper_lib "$viper_lib"
ja android "$android_ver"; ja device "$device_name"
ja version "$(grep '^version=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)"
for k in VOLSTEPS100 SAFEVOL_OFF SPATIALIZER_OFF VOLLISTENER_OFF DOLBY_OFF NOEFFECTS AOC_STOP GUARD RESTART_BOOT RYSOUND; do
    jn "cfg_$(echo $k | tr 'A-Z' 'a-z')" "$(cfg_get $k)"
done
ja cfg_usb_period "$(cfg_get USB_PERIOD)"
for k in YAYANG_SONY YAYANG_V2 YAYANG_SPK_GAIN YAYANG_HP_GAIN; do jn "cfg_$(echo $k | tr 'A-Z' 'a-z')" "$(cfg_get $k)"; done
yg=0; for f in /sys/kernel/sound_control/speaker_gain /sys/class/misc/snd_soc_card/speaker_gain /sys/kernel/sound_control/headphone_gain /sys/class/misc/snd_soc_card/headphone_gain; do [ -w "$f" ] && yg=1; done
jn yayang_gain_supported "$yg"
if [ -r "$MODDIR/settings.nls" ]; then nls_inst=1; else nls_inst=0; fi
jn nls_installed "$nls_inst"
ja nls_volsteps "$(nls_get VOLSTEPS)"; ja nls_bitnes "$(nls_get BITNES)"; ja nls_samplerate "$(nls_get SAMPLERATE)"
ja nls_effects "$(nls_get STEP12)"
nls_on=""
for n in 6 7 8 9 10 11 13 14; do [ "$(nls_get STEP$n)" = true ] && nls_on="${nls_on}${nls_on:+,}$n"; done
ja nls_steps "$nls_on"
ja conflicts "$(conflict_scan | tr '\n' ',' | sed 's/,$//')"
if [ -e "$MORA_DATA/ota_changed" ]; then jn ota_changed 1; else jn ota_changed 0; fi
ja rys_mode "$(rys_status_mode "$MODDIR")"
ja rys_reason "$(sed -n 's/^reason=//p' "$MODDIR/rysound/integration.status" 2>/dev/null | head -n 1)"
if grep -q '"enabled"[[:space:]]*:[[:space:]]*true' "$RYS_STATE/settings.json" 2>/dev/null; then jn rys_dsp 1; else jn rys_dsp 0; fi
if dax_supported; then jn dax_supported 1; else jn dax_supported 0; fi
ja dax_state "$(dax_state)"
_h="$(sha256sum "$DAX_DIR/stock.xml" 2>/dev/null | cut -d' ' -f1)"; [ -n "$_h" ] || _h="$(sha256sum "$DAX_TARGET" 2>/dev/null | cut -d' ' -f1)"
if [ "$_h" = "$DAX_STOCK_HASH" ]; then jn dax_stock_match 1; else jn dax_stock_match 0; fi
if bb_installed; then jn bb_installed 1; else jn bb_installed 0; fi
for k in BB_BASS BB_STRENGTH BB_LOUDNESS BB_TARGET BB_DP BB_GAIN; do jn "cfg_$(echo $k | tr 'A-Z' 'a-z')" "$(cfg_get $k)"; done
if fx_enabled; then jn fx_enabled 1; else jn fx_enabled 0; fi
jn fx_count "$(fx_count)"
ja fx_list "$(cut -d'|' -f2,4 "$FX_LIST" 2>/dev/null | sed 's/|/ ← /' | tr '\n' ',' | sed 's/,$//')"
ja fx_safe "$(head -n 1 "$FX_SAFE" 2>/dev/null)"
for k in FXHUB FXPATH; do jn "cfg_$(echo $k | tr 'A-Z' 'a-z')" "$(cfg_get $k)"; done
printf '{%s}\n' "$J"
