#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Watches the foreground app and switches the audio mode (no audioserver restart, 20 s hold-down).
MODDIR="${0%/*}"
. "$MODDIR/lib/mora_lib.sh"
P="$MORA_DATA/app_profiles"; ON="$MORA_DATA/profiles_on"; PID="$MORA_DATA/profile_daemon.pid"
echo $$ > "$PID"
last=""; lastsw=0
while [ -e "$ON" ]; do
    top="$(dumpsys activity activities 2>/dev/null | grep -m1 -E 'topResumedActivity|mResumedActivity' | sed -n 's/.* u[0-9]* \([A-Za-z0-9._]*\)\/.*/\1/p')"
    if [ -n "$top" ] && [ "$top" != "$last" ]; then
        last="$top"
        want="$(grep -m1 "^$top=" "$P" 2>/dev/null | cut -d= -f2)"
        now="$(date +%s)"
        if [ -n "$want" ] && [ "$want" != "$(cfg_get MODE)" ] && [ $((now - lastsw)) -ge 20 ]; then
            NO_RESTART=1 sh "$MODDIR/set_audio_mode.sh" "$want" >/dev/null 2>&1
            lastsw="$now"; mlog "profile: $top -> $want"
        fi
    fi
    sleep 4
done
rm -f "$PID"
