#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
MODDIR=${0%/*}
. "$MODDIR/lib/mora_lib.sh"
mlog "=== service ==="

# NLSound's boot script (tinymix controls, volume steps, mixer flags) runs on its own timeline
if [ -f "$MODDIR/nlsound_service.sh" ]; then
    ( sh "$MODDIR/nlsound_service.sh" >> "$MORA_LOG" 2>&1 & ) 
fi

( rys_service "$MODDIR" >/dev/null 2>&1 & )
( i=0; while [ "$(getprop sys.boot_completed)" != 1 ] && [ $i -lt 120 ]; do sleep 2; i=$((i + 1)); done; sleep 30; [ "$(getprop sys.boot_completed)" = 1 ] && . "$MODDIR/lib/mora_lib.sh" && fx_service_ok ) >/dev/null 2>&1 &

( sleep 20; sh "$MODDIR/profile_ctl.sh" start ) >/dev/null 2>&1 &

# ViPER driver: after boot, repair whatever the root manager's mount did not deliver, then restart audio once
(
    i=0
    while [ "$(getprop sys.boot_completed)" != 1 ] && [ $i -lt 120 ]; do sleep 2; i=$((i + 1)); done
    sleep 8
    r="$(v4a_reason "$MODDIR")"
    mlog "viper: boot check = $r"
    if [ "$r" != ok ] && [ "$r" != no_module_lib ] && [ "$r" != other_viper ] && [ "$r" != aidl_hal ]; then
        n="$(v4a_ensure "$MODDIR")"
        if [ "${n:-0}" -gt 0 ] || [ "$r" = not_loaded ]; then V4A_ENGINE= v4a_restart_and_wait; mlog "viper: after repair = $(v4a_reason "$MODDIR")"; fi
    fi
) &

# BassBoost: wait for the app (priv-app starts itself at boot), then push the saved values once
(
    i=0
    while [ "$(getprop sys.boot_completed)" != 1 ] && [ $i -lt 120 ]; do sleep 2; i=$((i + 1)); done
    sleep 25
    bb_apply >/dev/null 2>&1 || mlog "bassboost: app not installed (first boot after flash needs one more reboot)"
) &

(
    n=0
    while [ "$(getprop sys.boot_completed)" != "1" ] && [ $n -lt 120 ]; do sleep 2; n=$((n+1)); done
    sleep 20
    cfg_init
    force=0

    # Other modules' system.prop is loaded after our post-fs-data; re-assert what must not be overridden
    if [ "$(cfg_get NOEFFECTS)" != 1 ] && [ "$(getprop ro.audio.ignore_effects)" = true ]; then
        prop_set ro.audio.ignore_effects false; force=1; mlog "ro.audio.ignore_effects was true: reset (ViPER needs the effect framework)"
    fi
    apply_mode_props "$(cfg_get MODE)"
    yayang_apply "$MODDIR"
    [ "$PROPS_CHANGED" = 1 ] && force=1

    if [ "$(cfg_get SPATIALIZER_OFF)" = 1 ] && [ "$(getprop ro.audio.spatializer_enabled)" = true ]; then
        prop_set ro.audio.spatializer_enabled false; force=1
    fi

    # Tensor offload daemons add large jitter
    if [ "$(cfg_get AOC_STOP)" = 1 ]; then
        for s in aocd aocxd; do
            [ "$(getprop init.svc.$s)" = running ] && { setprop ctl.stop $s; force=1; mlog "stopped $s"; }
        done
    fi

    # Volume listener libraries apply a mild compressor on some Qualcomm / Motorola devices
    if [ "$(cfg_get VOLLISTENER_OFF)" = 1 ]; then
        DLB="/vendor/lib/soundfx/libdlbvol.so /vendor/lib64/soundfx/libdlbvol.so"
        # keep Dolby's own volume leveler while a Dolby ROM is being tuned through the DAX switch
        if [ "$(dax_state)" != stock ]; then DLB=""; fi
        if dolby_present && [ "$(cfg_get DOLBY_OFF)" != 1 ]; then DLB=""; fi
        for l in /vendor/lib/soundfx/libvolumelistener.so /vendor/lib64/soundfx/libvolumelistener.so $DLB; do
            [ -r "$l" ] || continue
            grep -q " $l " /proc/mounts 2>/dev/null && continue
            mount -o bind /dev/null "$l" 2>/dev/null && { force=1; mlog "nullified $l"; }
        done
    fi

    # Android settings database values
    steps="$(nls_get VOLSTEPS)"
    case "$steps" in ''|*[!0-9]*) steps=""; [ "$(cfg_get VOLSTEPS100)" = 1 ] && steps=100 ;; esac
    [ -n "$steps" ] && settings put system volume_steps_music "$steps" >/dev/null 2>&1
    if [ "$(cfg_get SAFEVOL_OFF)" = 1 ]; then
        settings put global safe_media_volume_enabled 0 >/dev/null 2>&1
        settings put global audio_safe_csd_next_warning 999999.0 >/dev/null 2>&1
        case "$(getprop ro.board.platform)" in gs*|zuma*|laguna*|malibu*) settings put global audio_safe_volume_state 3 >/dev/null 2>&1 ;; esac
    fi

    # ALSA mixer controls for the saved listening mode
    NO_RESTART=1 sh "$MODDIR/set_audio_mode.sh" tinymix_only >> "$MORA_LOG" 2>&1

    sdk="$(getprop ro.build.version.sdk)"; case "$sdk" in ''|*[!0-9]*) sdk=0 ;; esac
    if [ "$force" = 1 ] || { [ "$sdk" -ge 31 ] && [ "$(cfg_get RESTART_BOOT)" = 1 ]; }; then
        restart_audioserver; mlog "audioserver restarted after boot settings"
    fi
    mlog "boot tuning done"
) >/dev/null 2>&1 &
exit 0
