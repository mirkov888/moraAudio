# Mora Audio Suite - made by Mora & Claude Code
# ==============================================================================
#  Mora Audio Suite v3 - installer
#  1. resolve conflicts with standalone copies of the bundled modules
#  2. NLSound (patched: safe for ViPER, one owner for audio properties)
#  3. ViPER4Android RE driver registration (works on top of NLSound's edited configs)
#  4. Audio Misc features (USB period patch, de-spatialized BT policy)
#  5. merge system.prop, record stock checksums, first-run config
# ==============================================================================

MODDIR="$MODPATH"
. "$MODPATH/lib/mora_lib.sh"

MORA_SEP="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
case "$(settings get system system_locales 2>/dev/null)" in
  in-*|id-*|in_*|id_*|in,*|id,*) MORA_ID=true ;;
  *) MORA_ID=false ;;
esac
# t "indonesian" "english"
t() { if [ "$MORA_ID" = true ]; then echo "$1"; else echo "$2"; fi; }

mkdir -p "$MORA_DATA" 2>/dev/null

# ------------------------------------------------------------------------------
#  helpers
# ------------------------------------------------------------------------------
mora_key() {
  # waits for VOL+ / VOL-; prints up | down | timeout
  local out
  if type timeout >/dev/null 2>&1; then
    out="$(timeout 45 getevent -lq 2>/dev/null | grep -m 1 -E 'KEY_VOLUME(UP|DOWN).*DOWN')"
  else
    out="$(getevent -lq 2>/dev/null | grep -m 1 -E 'KEY_VOLUME(UP|DOWN).*DOWN')"
  fi
  case "$out" in
    *KEY_VOLUMEUP*) echo up ;;
    *KEY_VOLUMEDOWN*) echo down ;;
    *) echo timeout ;;
  esac
}

# mora_menu "opt1" "opt2" ...  -> returns the chosen index (1-based); VOL+ cycles, VOL- selects, silence = option 1
mora_menu() {
  local sel=1 total=$# cur k
  while true; do
    eval "cur=\"\${$sel}\""
    ui_print "➔ $cur"
    k="$(mora_key)"
    case "$k" in
      up) sel=$((sel % total + 1)) ;;
      down) return $sel ;;
      *) ui_print "  ($(t 'tidak ada input, memakai pilihan pertama' 'no input, using the first option'))"; return 1 ;;
    esac
  done
}

# NLSound presets (called from the patched NLSound installer)
mora_nls_preset() {
  case "$1" in
    recommended)
      # Only options that NLSound itself recommends plus property-only tweaks. Hardware patches
      # (limiters/speaker protection, mixer paths, tinymix, direct PCM, ACDB) stay opt-in via Manual.
      VOLSTEPS=100; VOLMEDIA=false; VOLMIC=false; BITNES=24; SAMPLERATE=96000
      STEP6=false; STEP7=false; STEP8=false; STEP9=true; STEP10=true; STEP11=false
      STEP12=part; STEP13=false; STEP14=false; PATCHACDB=false; DELETEACDB=false ;;
    restore)
      if [ -f "$RESTORE_SETTINGS" ]; then source "$RESTORE_SETTINGS"; fi ;;
    *)
      VOLSTEPS=false; VOLMEDIA=false; VOLMIC=false; BITNES=false; SAMPLERATE=false
      STEP6=false; STEP7=false; STEP8=false; STEP9=false; STEP10=false; STEP11=false
      STEP12=false; STEP13=false; STEP14=false; PATCHACDB=false; DELETEACDB=false ;;
  esac
  export SAMPLERATE BITNES VOLMIC VOLMEDIA VOLSTEPS STEP6 STEP7 STEP8 STEP9 STEP10 STEP11 STEP12 STEP13 STEP14 PATCHACDB DELETEACDB
}

# Every audio_effects config on the device (real paths, one per line)
mora_find_effects() {
  local d
  for d in /system /vendor /odm /product /system_ext /my_product /mi_ext; do
    [ -d "$d" ] || continue
    find -H "$d" \( -path "*/lib" -o -path "*/lib64" -o -path "*/framework" -o -path "*/fonts" -o -path "*/bin" \) -prune -o \
      \( -type f -o -type l \) \( -name 'audio_effects*.xml' -o -name 'audio_effects*.conf' \) -print 2>/dev/null
  done
}

mora_norm() {
  if type normalize_path >/dev/null 2>&1; then normalize_path "$1"
  elif [ "$KSU" = "true" ] || [ "$APATCH" = "true" ]; then echo "${1#/system}" | sed 's|^$|/|'
  else case "$1" in /system/*) echo "$1" ;; *) echo "/system/$1" ;; esac; fi
}

# ------------------------------------------------------------------------------
#  1. duplicate modules
# ------------------------------------------------------------------------------
ui_print " "
ui_print "$MORA_SEP"
ui_print " $(t 'MODULE DUPLIKAT' 'DUPLICATE MODULES')"
ui_print "$MORA_SEP"
DUPS="$(conflict_disable)"
if [ -n "$DUPS" ]; then
  for id in $DUPS; do ui_print "  [!] $(t 'Dinonaktifkan' 'Disabled'): $id"; done
  ui_print "  $(t 'Fiturnya sudah ada di Mora. Hapus modul itu dari daftar bila sudah tidak perlu.' 'Its features are already inside Mora. Remove it from the list when you no longer need it.')"
else
  ui_print "  $(t 'Tidak ada. Bagus.' 'None found. Good.')"
fi
ui_print " "

# ------------------------------------------------------------------------------
#  2. NLSound
# ------------------------------------------------------------------------------
if [ -z "$MORA_NLS_PRESET" ]; then
  NLS_PREV=false
  [ -f "/data/adb/modules/$MODID/settings.nls" ] || [ -f /data/adb/modules/NLSound/settings.nls ] && NLS_PREV=true
  ui_print "$MORA_SEP"
  ui_print " $(t 'NLSOUND - TWEAK AUDIO PERANGKAT' 'NLSOUND - DEVICE AUDIO TWEAKS')"
  ui_print "$MORA_SEP"
  ui_print " "
  ui_print " $(t 'Pilih cara memasang NLSound.' 'Choose how to install NLSound.')"
  ui_print " $(t '[VOL+] Ganti pilihan   [VOL-] Pilih' '[VOL+] Next option   [VOL-] Select')"
  ui_print " $(t '(tanpa input 45 detik = pilihan pertama)' '(no input for 45 s = first option)')"
  ui_print " "
  if [ "$NLS_PREV" = true ]; then
    mora_menu "$(t '1. Rekomendasi Mora (aman untuk ViPER)' '1. Mora recommended (ViPER-safe)')" \
              "$(t '2. Manual (15 langkah)' '2. Manual (15 steps)')" \
              "$(t '3. Pulihkan pengaturan sebelumnya' '3. Restore previous settings')" \
              "$(t '4. Lewati NLSound' '4. Skip NLSound')"
    case $? in 1) MORA_NLS_PRESET=recommended ;; 2) MORA_NLS_PRESET=manual ;; 3) MORA_NLS_PRESET=restore ;; *) MORA_NLS_PRESET=skip ;; esac
  else
    mora_menu "$(t '1. Rekomendasi Mora (aman untuk ViPER)' '1. Mora recommended (ViPER-safe)')" \
              "$(t '2. Manual (15 langkah)' '2. Manual (15 steps)')" \
              "$(t '3. Lewati NLSound' '3. Skip NLSound')"
    case $? in 1) MORA_NLS_PRESET=recommended ;; 2) MORA_NLS_PRESET=manual ;; *) MORA_NLS_PRESET=skip ;; esac
  fi
  ui_print " "
fi
export MORA_NLS_PRESET
mlog "install: NLSound preset = $MORA_NLS_PRESET"

# NLSound writes to $MODPATH/nlsound_service.sh (shipped with the original boot script as its first lines)
. "$MODPATH/common/nlsound_install.sh"

# ------------------------------------------------------------------------------
#  3. ViPER4Android RE driver
# ------------------------------------------------------------------------------
ui_print " "
ui_print "$MORA_SEP"
ui_print " ViPER4Android RE"
ui_print "$MORA_SEP"

LIBSRC="$MODPATH/common/files"
case "$ARCH" in
  arm64) A64=arm64-v8a; A32=armeabi-v7a ;;
  arm)   A64=;          A32=armeabi-v7a ;;
  x64)   A64=x86_64;    A32=x86 ;;
  x86)   A64=;          A32=x86 ;;
  *)     A64=;          A32= ;;
esac
HAS32="$(getprop ro.product.cpu.abilist32)"
V4A_OK=false
if [ -n "$A64" ] && [ "$IS64BIT" = true ] && [ -f "$LIBSRC/libv4a_re_$A64.so" ]; then
  d="$MODPATH$(mora_norm /system/vendor/lib64/soundfx)"
  mkdir -p "$d" && cp -f "$LIBSRC/libv4a_re_$A64.so" "$d/libv4a_re.so" && ui_print "  [+] $(t 'Library 64-bit' '64-bit library') ($A64)" && V4A_OK=true
fi
if [ -n "$A32" ] && { [ -n "$HAS32" ] || [ "$IS64BIT" != true ]; } && [ -f "$LIBSRC/libv4a_re_$A32.so" ]; then
  d="$MODPATH$(mora_norm /system/vendor/lib/soundfx)"
  mkdir -p "$d" && cp -f "$LIBSRC/libv4a_re_$A32.so" "$d/libv4a_re.so" && ui_print "  [+] $(t 'Library 32-bit' '32-bit library') ($A32)" && V4A_OK=true
fi
[ "$V4A_OK" = true ] || ui_print "  [!] $(t 'Library ViPER untuk ABI ini tidak ditemukan' 'No ViPER library for this ABI')"

V4A_FILES=0; V4A_BAD=0
for real in $(mora_find_effects); do
  dest="$MODPATH$(mora_norm "$real")"
  if [ ! -f "$dest" ]; then
    # not touched by NLSound: start from the pristine partition (mirror) rather than any overlay
    src="$real"; [ -n "$ORIGDIR" ] && [ -f "$ORIGDIR$real" ] && src="$ORIGDIR$real"
    mkdir -p "$(dirname "$dest")"; cp -f "$src" "$dest" 2>/dev/null || continue
    fresh=true
  else
    fresh=false
  fi
  if v4a_patch_file "$dest"; then
    V4A_FILES=$((V4A_FILES+1)); ui_print "  [+] $(t 'Terdaftar di' 'Registered in') $real"
  else
    V4A_BAD=$((V4A_BAD+1))
    # a file without <libraries>/<effects> (e.g. only xi:include) needs no change
    [ "$fresh" = true ] && rm -f "$dest"
  fi
done
if [ "$V4A_FILES" -eq 0 ]; then
  ui_print "  [!] $(t 'Tidak ada file audio_effects yang bisa ditambal' 'No audio_effects file could be patched')"
fi

# ------------------------------------------------------------------------------
#  3b. RySound (software DSP effect) - shares the overlays registered above
# ------------------------------------------------------------------------------
ui_print " "
ui_print "$MORA_SEP"
ui_print " RySound DSP"
ui_print "$MORA_SEP"
RYS_MODE=skipped
if [ "$(cfg_get RYSOUND)" != 1 ]; then
  ui_print "  [i] $(t 'RySound dimatikan di pengaturan Mora (dilewati)' 'RySound is turned off in Mora settings (skipped)')"
elif [ "$V4A_OK" != true ] || [ "$V4A_FILES" -eq 0 ]; then
  ui_print "  [i] $(t 'Tidak ada konfigurasi efek yang terpasang: RySound dilewati' 'No effects config was set up: RySound skipped')"
else
  for f in "$MODPATH"/rysound/tools/*.sh "$MODPATH"/rysound/verify_audio.sh; do [ -f "$f" ] && chmod 0755 "$f"; done
  mkdir -p /data/adb/sound_universal 2>/dev/null
  rm -f /data/adb/sound_universal/safe_mode 2>/dev/null
  echo 0 > /data/adb/sound_universal/boot_pending 2>/dev/null
  sh "$MODPATH/rysound/tools/sync_settings.sh" "$MODPATH/rysound" >/dev/null 2>&1
  if rys_stage "$MODPATH"; then
    RYS_MODE=staged
    ui_print "  [+] $(t 'Efek RySound didaftarkan bersama ViPER (DSP mati sampai kamu menyalakannya)' 'RySound effect registered next to ViPER (DSP stays off until you turn it on)')"
  else
    RYS_MODE="$(rys_status_mode "$MODPATH")"
    ui_print "  [i] $(t 'Hook RySound tidak dipasang' 'RySound hook not installed'): $(sed -n 's/^reason=//p' "$MODPATH/rysound/integration.status" 2>/dev/null | head -n 1)"
    ui_print "  [i] $(t 'Halaman pengaturan RySound tetap bisa dibuka di WebUI' 'The RySound settings page is still available in the WebUI')"
  fi
fi

# ------------------------------------------------------------------------------
#  3c. Dolby DAX config switch (only when the ROM ships Dolby)
# ------------------------------------------------------------------------------
if dax_device_ok && dolby_present; then
  ui_print " "
  ui_print "$MORA_SEP"
  ui_print " Dolby DAX"
  ui_print "$MORA_SEP"
  dax_prepare "$MODPATH"
  if [ -f "$DAX_DIR/stock.xml" ]; then
    ui_print "  [+] $(t 'Config Dolby asli dicadangkan; varian uji siap di tab Tuning' 'Original Dolby config backed up; test variants are ready in the Tuning tab')"
  else
    ui_print "  [!] $(t 'Gagal mencadangkan dax-default.xml' 'Could not back up dax-default.xml')"
  fi
  ui_print "  [i] $(t 'Dolby bawaan ROM dibiarkan aktif (opsi matikan Dolby default mati)' 'ROM Dolby is left on (the turn-off-Dolby option defaults to off)')"
fi

# ------------------------------------------------------------------------------
#  3d. BassBoost (global bass / loudness / dynamics effects)
# ------------------------------------------------------------------------------
ui_print " "
ui_print "$MORA_SEP"
ui_print " BassBoost"
ui_print "$MORA_SEP"
if [ "${API:-0}" -lt 33 ] 2>/dev/null; then
  rm -rf "$MODPATH/system/priv-app/BassBoost"
  ui_print "  [i] $(t 'BassBoost butuh Android 13+, dilewati' 'BassBoost needs Android 13+, skipped')"
else
  set_perm_recursive "$MODPATH/system/priv-app/BassBoost" 0 0 0755 0644
  ui_print "  [+] $(t 'BassBoost terpasang; efek mati sampai dinyalakan di tab Bass' 'BassBoost installed; effects stay off until enabled in the Bass tab')"
fi

# ------------------------------------------------------------------------------
#  3e. Effect Hub (AML-style)
# ------------------------------------------------------------------------------
ui_print " "
ui_print "$MORA_SEP"
ui_print " Effect Hub"
ui_print "$MORA_SEP"
mkdir -p "$MORA_DATA" 2>/dev/null
FX_N="$(fx_apply "$MODPATH")"
ui_print "  [+] Effect Hub: ${FX_N:-0} $(t 'library efek modul lain didaftarkan' 'effect libraries from other modules registered')"

# ------------------------------------------------------------------------------
#  4. Audio Misc features
# ------------------------------------------------------------------------------
ui_print " "
ui_print "$MORA_SEP"
ui_print " Audio misc. settings"
ui_print "$MORA_SEP"

toHexLE() { printf "%2.2x%2.2x%2.2x%2.2x" $(( $1 % 256 )) $(( $1 / 256 % 256 )) $(( $1 / 65536 % 256 )) $(( $1 / 16777216 % 256 )); }
toHexString() {
  local tmp="$(printf '%s' "$1" | xxd -p | tr -d ' \n')"
  if [ -n "$2" ]; then
    while [ ${#tmp} -lt "$2" ]; do tmp="${tmp}0"; done
    printf '%s' "$tmp" | cut -c1-"$2"
  else printf '%s' "$tmp"; fi
}
# libalsautils reads ro.audio.usb.period_us, which SELinux hides from the HAL on newer Android:
# point it at vendor.audio.usb.perio (set by Mora) instead
patchMapProperty() {
  local pat1 pat2
  pat1="$(toHexString 'ro.audio.usb.period_us')"
  pat2="$(toHexString 'vendor.audio.usb.perio' ${#pat1})"
  xxd -p < "$1" | tr -d ' \n' | sed -e "s/$pat1/$pat2/" \
    | awk 'BEGIN{w=60; getline buf; n=length(buf); for(i=1;i<=n;i+=w) print substr(buf,i,w); exit}' \
    | xxd -r -p > "$2"
}
USBLIBS=0
if type xxd >/dev/null 2>&1 && [ -n "$ORIGDIR" ] && [ -d "$ORIGDIR/vendor" ]; then
  for d in lib lib64; do
    for l in libalsautils.so libalsautilsv2.so audio_usb_aoc.so; do
      src="$ORIGDIR/vendor/$d/$l"
      [ -r "$src" ] || continue
      dest="$MODPATH$(mora_norm /system/vendor/$d/$l)"
      mkdir -p "$(dirname "$dest")"
      if patchMapProperty "$src" "$dest" && [ -s "$dest" ]; then
        chmod 644 "$dest"; chcon u:object_r:vendor_file:s0 "$dest" 2>/dev/null
        USBLIBS=$((USBLIBS+1)); ui_print "  [+] $(t 'Periode USB dipetakan' 'USB period mapped'): $d/$l"
      else rm -f "$dest"; fi
    done
  done
else
  ui_print "  [i] $(t 'xxd/mirror tidak tersedia: patch periode USB dilewati' 'xxd/mirror unavailable: USB period patch skipped')"
fi

# Bluetooth audio policy: drop the spatializer flag (a common source of errors/jitter on Android 13+)
for real in /vendor/etc/bluetooth_audio_policy_configuration_7_0.xml; do
  [ -r "$real" ] || continue
  dest="$MODPATH$(mora_norm "$real")"
  if [ -f "$dest" ]; then src="$dest"; else src="$real"; [ -n "$ORIGDIR" ] && [ -r "$ORIGDIR$real" ] && src="$ORIGDIR$real"; fi
  if grep -q 'AUDIO_OUTPUT_FLAG_SPATIALIZER' "$src" 2>/dev/null; then
    mkdir -p "$(dirname "$dest")"
    [ "$src" = "$dest" ] || cp -f "$src" "$dest"
    sed -i 's/flags[[:space:]]*=[[:space:]]*"AUDIO_OUTPUT_FLAG_SPATIALIZER"//' "$dest"
    chmod 644 "$dest"; chcon u:object_r:vendor_configs_file:s0 "$dest" 2>/dev/null
    ui_print "  [+] $(t 'Spatializer dilepas dari' 'Spatializer flag removed from') $(basename "$real")"
  fi
done

# Motorola only: pre-installed Dolby apps add large jitter (MotorolaSettingsProvider must stay: bootloop)
if [ "$(getprop ro.product.manufacturer)" = "motorola" ]; then
  for p in /system_ext/priv-app/MotoDolbyDax3 /system_ext/priv-app/daxService /system_ext/priv-app/DaxUI /system_ext/app/MotoSignatureApp; do
    [ -n "$ORIGDIR" ] && [ -d "$ORIGDIR$p" ] || continue
    r="$(mora_norm "$p")"
    mkdir -p "$MODPATH$r"; REPLACE="$REPLACE $r"
    ui_print "  [+] $(t 'Dinonaktifkan' 'Disabled'): $p"
  done
fi

# ------------------------------------------------------------------------------
#  5. system.prop (single, de-duplicated), stock checksums, first-run config
# ------------------------------------------------------------------------------
OWNED='^(ro\.config\.media_vol_steps|audio\.safemedia\..*|ro\.audio\.spatializer_enabled|ro\.audio\.ignore_effects|ro\.vendor\.audio\.dolby\.dax\.support|vendor\.audio\.dolby\.control\.support|persist\.audio\.dolby\.enabled|vendor\.audio\.usb\.perio|vendor\.audio\.usb\.out\..*|vendor\.audio_hal\.period_.*|vendor\.audio\.adm\.buffering\.ms|af\.resampler\.quality|ro\.audio\.resampler\.psd\..*|ro\.audio\.flinger_standbytime_ms|audio\.deep_buffer\.media|persist\.vendor\.audio\.hifi(\.int_codec)?|audio\.offload\.pcm\.24bit\.enable|audio\.offload\.pcm\.16bit\.enable|audio\.offload\.disable|persist\.bluetooth\.sbc_hd_higher_bitrate)$'
if [ -f "$MODPATH/system.prop" ]; then
  awk -F= -v owned="$OWNED" '
    { sub(/^[ \t]+/, ""); sub(/[ \t\r]+$/, "") }
    /^#/ || NF < 2 { next }
    { key = $1; gsub(/[ \t]+$/, "", key) }
    key ~ owned { next }
    { if (!(key in seen)) { order[++n] = key; seen[key] = 1 } last[key] = $0 }
    END { for (i = 1; i <= n; i++) print last[order[i]] }
  ' "$MODPATH/system.prop" > "$MODPATH/system.prop.new" && mv -f "$MODPATH/system.prop.new" "$MODPATH/system.prop"
  ui_print " "
  ui_print "  [+] system.prop: $(wc -l < "$MODPATH/system.prop") $(t 'properti statis, nilai utama diatur Mora saat boot' 'static properties; Mora sets the main values at boot')"
fi

# stock checksums let the boot script notice ROM updates (overlays built on an old ROM can misbehave)
: > "$MODPATH/stock.sum"
for f in $(find "$MODPATH" \( -path "$MODPATH/webroot" -o -path "$MODPATH/common" -o -path "$MODPATH/lib" \) -prune -o -type f \( -name '*.xml' -o -name '*.conf' \) -print 2>/dev/null); do
  real="$(real_of "$f" "$MODPATH")"
  for base in "$ORIGDIR" ""; do
    [ -f "$base$real" ] || continue
    s="$(sum_of "$base$real")"
    [ -n "$s" ] && echo "$s $real" >> "$MODPATH/stock.sum"
    break
  done
done

cfg_init
# an installed NLSound setting of 30/50 steps is honoured; otherwise 100 steps
banner_apply "$MODPATH" 2>/dev/null   # keep the banner the user picked across updates
mlog "installed v$(grep '^version=' "$MODPATH/module.prop" | cut -d= -f2); NLSound=$MORA_NLS_PRESET; ViPER files=$V4A_FILES; USB libs=$USBLIBS; RySound=$RYS_MODE"

ui_print " "
ui_print "$MORA_SEP"
ui_print " $(t 'SELESAI' 'DONE')"
ui_print "$MORA_SEP"
ui_print "  $(t '1. Reboot.' '1. Reboot.')"
ui_print "  $(t '2. Pasang aplikasi ViPER4Android RE (APK terpisah).' '2. Install the ViPER4Android RE app (separate APK).')"
ui_print "  $(t '3. Buka WebUI Mora: tab Sistem menampilkan status driver.' '3. Open the Mora WebUI: the System tab shows the driver status.')"
ui_print " "
