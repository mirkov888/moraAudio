#!/bin/bash
# Mora Audio Suite - made by Mora & Claude Code
# Installer menu descriptions for Indonesian localization (Mora Audio Suite)

SELECTE="- [*] Dipilih:"
SMENU="pasang lewati"
SMENU1="lewati 30 50 100"
SMENU2="lewati 78 84 90 96 102 108"
SMENU4="lewati 16_bit 24_bit 32_bit Float"
SMENU5="lewati 44100 48000 96000 192000 384000"
SMENU12="lewati sebagian nonaktifkan_semua"
SMENU15="lewati dasar General_cal speaker"

INSTALLSKIP="
  [VOL+] Pasang     ┃   [VOL-] Lewati
"
SMENUAUTOSKIP="  Tidak didukung di perangkat ini (dilewati)"
SMENUSKIP="- Pengaturan sebelumnya dilewati"

RESTORE="
 PENGATURAN SEBELUMNYA DITEMUKAN
$SEPARATOR

 Profil dari pemasangan sebelumnya
 ditemukan di perangkat ini.

 Pulihkan profil tersebut?

  [VOL+] Pulihkan profil
  [VOL-] Atur manual dari awal
"

STRINGSTEP1="
 [01/15] LANGKAH VOLUME
$SEPARATOR

 Mengubah jumlah langkah pada slider volume
 media (Android bawaan hanya 15).

 [*] 100 langkah dipakai Mora agar volume
 sangat halus. 30 atau 50 juga nyaman.

  [VOL+] Item berikutnya   ┃   [VOL-] Pilih

 1. Lewati     • Bawaan (15 langkah)
 2. 30 langkah • Seimbang
 3. 50 langkah • Halus
 4. 100 langkah • [Disarankan] Paling halus
"

STRINGSTEP2="
 [02/15] VOLUME MAKSIMUM HARDWARE (MIXER)
$SEPARATOR

 Mengatur gain preamp digital di mixer_paths
 untuk speaker internal dan headphone kabel.

 [i] Nilai bawaan adalah 84.
 [!] Di atas 96 dapat menyebabkan clipping.
 [!] Tidak memengaruhi audio Bluetooth.

  [VOL+] Item berikutnya   ┃   [VOL-] Pilih

 1. Lewati    • Pakai level bawaan
 2. 78        • Lebih pelan dari bawaan
 3. 84        • Level bawaan [Aman]
 4. 90        • Naik sedang
 5. 96        • Naik terasa [Batas bersih]
 6. 102       • Naik tinggi (risiko distorsi)
 7. 108       • Gain maksimum (distorsi tinggi)
"

STRINGSTEP3="
 [03/15] SENSITIVITAS MIKROFON (DEC)
$SEPARATOR

 Mengatur gain rekaman digital untuk panggilan,
 catatan suara, dan rekaman video.

 [i] Nilai bawaan adalah 84. Nilai tinggi juga
 menguatkan derau latar, gema, dan desis.

  [VOL+] Item berikutnya   ┃   [VOL-] Pilih

 1. Lewati    • Pakai sensitivitas bawaan
 2. 78        • Gain lebih rendah (tempat bising)
 3. 84        • Level bawaan [Aman]
 4. 90        • Naik sedikit
 5. 96        • Untuk suara yang pelan
 6. 102       • Sensitivitas tinggi
 7. 108       • Gain maksimum (risiko distorsi)
"

STRINGSTEP4="
 [04/15] KEDALAMAN BIT AUDIO
$SEPARATOR

 Menetapkan kedalaman bit PCM bawaan pada
 file kebijakan dan platform audio.

 [*] 24-bit disarankan. 32-bit dan Float
 tidak didukung semua codec hardware.

  [VOL+] Item berikutnya   ┃   [VOL-] Pilih

 1. Lewati    • Bawaan sistem
 2. 16 bit    • PCM 16-bit standar
 3. 24 bit    • [Disarankan] PCM 24-bit
 4. 32 bit    • PCM 32-bit
 5. Float     • Floating point 32-bit
"

STRINGSTEP5="
 [05/15] SAMPLE RATE AUDIO
$SEPARATOR

 Menetapkan sample rate output hardware utama
 pada file konfigurasi audio sistem.

 [i] Bawaan Android adalah 48 kHz. Memilih 96 kHz
 memungkinkan pemutaran Hi-Res asli tanpa downsampling.

  [VOL+] Item berikutnya   ┃   [VOL-] Pilih

 1. Lewati    • Bawaan sistem
 2. 44100 Hz  • Standar CD
 3. 48000 Hz  • Standar Android / video
 4. 96000 Hz  • [Disarankan] Hi-Res
 5. 192000 Hz • Rate tinggi (beban CPU lebih besar)
 6. 384000 Hz • Rate maksimum
"

STRINGSTEP6="
 [06/15] MATIKAN LIMITER & DRC
$SEPARATOR

 Mematikan Dynamic Range Compression (DRC),
 soft-clipping, dan limiter volume perangkat lunak.

 • Mengembalikan dinamika audio yang alami
 • Menghilangkan pembatasan dan ducking volume
 [!] Speaker kecil dapat distorsi di volume maksimum.
$INSTALLSKIP"

STRINGSTEP7="
 [07/15] BUKA FITUR HI-FI VENDOR
$SEPARATOR

 Mengaktifkan flag audio tersembunyi pada konfigurasi
 OEM Xiaomi, OnePlus, Realme, dan Oppo:

 • Membuka rekaman suara HD 24-bit
 • Mengaktifkan mode Hi-Fi DAC bawaan
 • Menambahkan izin sistem Pro-Audio
"

STRINGSTEP8="
 [08/15] HIGH-PASS FILTER HEADPHONE (4 HZ)
$SEPARATOR

 Menurunkan cutoff High-Pass Filter (HPF) headphone
 bawaan di mixer_paths dari ~25 Hz menjadi 4 Hz.

 • Mengembalikan sub-bass yang dalam
 • Mengalihkan amplifier headphone ke mode daya Hi-Fi
$INSTALLSKIP"

STRINGSTEP9="
 [09/15] TWEAK PROPERTI SISTEM
$SEPARATOR

 Menyetel properti audio Android tingkat rendah:

 • Mengatur latensi stack AAudio MMAP
 • Menyiapkan fitur Hi-Fi codec internal
 • Mematikan kompresi dinamis pada AAC
 (Resampler dan buffer diatur oleh Mora.)
$INSTALLSKIP"

STRINGSTEP10="
 [10/15] OPTIMASI AUDIO BLUETOOTH
$SEPARATOR

 Mengoptimalkan konfigurasi audio nirkabel:

 • Mengaktifkan bitrate tinggi SBC (SBC HD)
 • Mengoptimalkan parameter AptX Adaptive
 • Mematikan Absolute Volume (memperbaiki bug
   volume kecil pada headphone nirkabel tertentu)
$INSTALLSKIP"

STRINGSTEP11="
 [11/15] ROUTING AUDIO DIRECT PCM
$SEPARATOR

 Menambahkan flag DIRECT_PCM pada kebijakan output audio.

 Memungkinkan pemutar yang kompatibel (Poweramp, UAPP,
 Neutron) mengirim audio langsung ke DAC, melewati
 mixer AudioFlinger standar.
"

STRINGSTEP12="
 [12/15] KEBIJAKAN EFEK AUDIO
$SEPARATOR

 Mengatur pemrosesan audio bawaan sistem
 (audio spasial, reverb, equalizer vendor).

 [!] 'Nonaktifkan semua' tidak tersedia di Mora
     karena akan mematikan driver ViPER;
     pilihan itu otomatis menjadi 'Sebagian'.

  [VOL+] Item berikutnya   ┃   [VOL-] Pilih

 1. Lewati        • Biarkan semua equalizer aktif
 2. Sebagian      • [Disarankan] Hapus 3D palsu
                    dan reverb, equalizer tetap ada
 3. Nonaktifkan   • Diubah otomatis menjadi 'Sebagian'
"

STRINGSTEP13="
 [13/15] TWEAK KHUSUS HARDWARE (TINYMIX)
$SEPARATOR

 Menerapkan penyesuaian mixer ALSA saat boot
 yang disesuaikan dengan model perangkatmu:

 • Mengoptimalkan chip smart amplifier (Cirrus, TAS, SmartPA)
 • Menyesuaikan daya output headphone dan gain ADC
$INSTALLSKIP"

STRINGSTEP14="
 [14/15] PENYETELAN DOLBY ATMOS
$SEPARATOR

 Mengonfigurasi ulang parameter pemrosesan Dolby Atmos:

 • Mematikan volume leveler (mencegah volume naik turun)
 • Mematikan delay surround palsu dan kompresi dialog
 • Menghasilkan output lebih bersih dan seimbang
"

STRINGSTEP15="
 [15/15] OVERRIDE KALIBRASI ACDB
$SEPARATOR

 File ACDB Qualcomm menyimpan batas volume DSP
 dan limiter hardware bawaan pabrik.

 Opsi ini mengosongkan file kalibrasi terpilih:

  [VOL+] Item berikutnya   ┃   [VOL-] Pilih

 1. Lewati    • Pakai kalibrasi bawaan
 2. Dasar     • [Aman] Membuka AUX, BT, dan HDMI
 3. General   • Dasar + kalibrasi umum
 4. Speaker   • [Hati-hati] Menghapus batas speaker
                (bisa bergetar di volume maksimum)
"

STRINGSTEP151="
 [15/15] PASANG ACDB YANG SUDAH DITAMBAL
$SEPARATOR

 Profil ACDB khusus untuk modelmu ditemukan.

 Mengangkat batas volume hardware dengan aman
 tanpa membuat driver tidak stabil.
"

final_print_text() {
  cat <<EOF
$SEPARATOR
          RINGKASAN KONFIGURASI
$SEPARATOR

  01 Jumlah langkah volume     : $VOLSTEPS
  02 Level volume maksimum     : $VOLMEDIA
  03 Sensitivitas mikrofon     : $VOLMIC
  04 Kedalaman bit audio       : $BITNES
  05 Sample rate audio         : $SAMPLERATE
  06 Limiter & DRC dimatikan   : $STEP6
  07 Fitur Hi-Fi vendor        : $STEP7
  08 Patch sub-bass & mixer    : $STEP8
  09 Tweak properti sistem     : $STEP9
  10 Peningkatan Bluetooth     : $STEP10
  11 Routing Direct PCM        : $STEP11
  12 Kebijakan efek audio      : $STEP12
  13 Tweak hardware perangkat  : $STEP13
  14 Profil Hi-Fi Dolby Atmos  : $STEP14
  15 Perubahan ACDB            : $([ "$PATCHACDB" != "false" ] && echo "$PATCHACDB" || echo "$DELETEACDB")

$SEPARATOR
  Model perangkat : $DEVICE
  Versi module    : $VERSION
$SEPARATOR

 Memasang dan menambal file...
 Mohon tunggu...
EOF
}

HW_HEADER="          [ HARDWARE AUDIO TERDETEKSI ]"
HW_CIRRUS="Amplifier Speaker    : Cirrus Logic (CS35L41)"
HW_TFA="Amplifier Speaker    : NXP / Goodix TFA"
HW_TAS="Amplifier Speaker    : Texas Instruments (TAS)"
HW_AWINIC="Amplifier Speaker    : Awinic (AW88xx)"
HW_MAXIM="Amplifier Speaker    : Maxim Integrated"
HW_WSA="Amplifier Speaker    : Qualcomm WSA"
HW_WCD="Codec Audio Utama    : Qualcomm WCD (Aqstic Hi-Fi)"
HW_ESS="DAC Hi-Fi Khusus     : ESS Sabre"
HW_AKM="DAC Hi-Fi Khusus     : Asahi Kasei (AKM)"
HW_SOC="Codec Audio Utama    : Codec prosesor terintegrasi (SoC)"
