# Third-party notices

Mora Audio Suite is made by Mora & Claude Code. It bundles and adapts the following projects.
Their licenses require these notices to stay with the module; they are not a claim of authorship over Mora's own code.

| Component | Origin | License / terms |
|---|---|---|
| Audio misc. settings 1.3.12 (USB period, safe-volume, spatializer and volume-listener tweaks) | zyhk | AGPL-3.0 - full text in LICENSE; source is the module's shell scripts |
| NLSound 4.5 (installer, tinymix tweaks) | NLSound Team | as published with the original module |
| RySound 0.7.0 (software DSP effect, prebuilt libraries and source in rysound/native_effect) | ryetechnologia | as published with the original module |
| DAX Test Toggle [sweet] 2.0 (dax variants in dax/) | manipvlator | as published with the original module |
| BassBoost 1.1 (prebuilt system app in system/priv-app/BassBoost) | kazuyoo-stuff | as published with the original module |
| ViPER4Android RE driver libraries and the MMT-Extended installer framework | pittvandewitt, Zackptg5 and contributors | as published with the originals |
| Audio Modification Library, Ryuki Mod (effect/UUID table in fxhub/libs.tsv; the hub logic itself is Mora's own code) | Rei Ryuki the Fixer, based on Zackptg5 & ahrion | MIT - fxhub/LICENSE.aml |

Removing these notices would breach the licenses above (especially AGPL-3.0), so they stay in this file and in LICENSE.


## YayangProject AudioSony+ dan Yayang Audio Sound V2
- Penulis asli: **YayangShibainu / YayangProject** (modul Magisk, tanpa berkas lisensi).
- Yang diambil: daftar nama properti audio untuk profil opsional "Sony+" dan "Speaker V2" (`yayang/*.props`) serta gambar `free walpaper.jpg` dari zip tersebut sebagai banner b15 (gambar bergaya logo ASUS ROG; pembuat aslinya tidak diketahui, milik pemegang haknya).
- Yang tidak diambil dan alasannya: lihat `yayang/NOT_USED.md`.
- Profil ini mati secara bawaan. Karena tanpa lisensi, hak cipta tetap pada penulis aslinya.
