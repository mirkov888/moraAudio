#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Per-app audio mode. Usage: profile_ctl.sh list | set <package> <audiophile|movie|power_saver> | del <package> | enable <0|1>
MODDIR="${0%/*}"
. "$MODDIR/lib/mora_lib.sh"
cfg_init
P="$MORA_DATA/app_profiles"; ON="$MORA_DATA/profiles_on"; PID="$MORA_DATA/profile_daemon.pid"
touch "$P"
daemon_running() { [ -s "$PID" ] && kill -0 "$(cat "$PID")" 2>/dev/null; }
daemon_stop() { daemon_running && kill "$(cat "$PID")" 2>/dev/null; rm -f "$PID"; }
daemon_start() { daemon_running && return 0; ( nohup sh "$MODDIR/profile_daemon.sh" >/dev/null 2>&1 & ); }
list() {
    j=""; while IFS='=' read -r k v; do [ -n "$k" ] && j="${j}${j:+,}{\"pkg\":\"$k\",\"mode\":\"$v\"}"; done < "$P"
    printf '{"enabled":%s,"running":%s,"profiles":[%s]}\n' "$([ -e "$ON" ] && echo 1 || echo 0)" "$(daemon_running && echo 1 || echo 0)" "$j"
}
case "$1" in
    set)
        case "$2" in *[!A-Za-z0-9._]*|"") echo '{"status":"error","message":"bad package"}'; exit 1 ;; esac
        case "$3" in audiophile|movie|power_saver) ;; *) echo '{"status":"error","message":"bad mode"}'; exit 1 ;; esac
        grep -v "^$2=" "$P" > "$P.n" 2>/dev/null; echo "$2=$3" >> "$P.n"; mv -f "$P.n" "$P"; list ;;
    del)
        grep -v "^$2=" "$P" > "$P.n" 2>/dev/null; mv -f "$P.n" "$P"; list ;;
    enable)
        if [ "$2" = 1 ]; then touch "$ON"; daemon_start; else rm -f "$ON"; daemon_stop; fi; sleep 1; list ;;
    start) [ -e "$ON" ] && daemon_start ;;
    *) list ;;
esac
