# Dibuang dari modul Yayang (dan alasannya)
Mora Audio Suite - made by Mora & Claude Code

| Dari modul asli | Alasan tidak dipakai |
|---|---|
| `setenforce 0` (SELinux permissive) | Menurunkan keamanan seluruh sistem; tidak diperlukan untuk audio. |
| `killall audioserver/mediaserver` saat boot | Mora sudah me-restart audio hanya bila perlu. |
| `chmod -R 0771 /vendor/etc/audio`, salin mixer_paths ke /vendor | Mengubah partisi vendor; bisa merusak izin/boot. |
| `echo ... /proc/asound/.../hw_params` | Bukan antarmuka tulis; tidak berpengaruh. |
| `persist.audio.hwui.use.cpu`, `persist.media.audiopolicy.forcelegacy` | Tidak terkait audio / memaksa kebijakan lama; berisiko. |
| `persist.bluetooth.a2dp_offload.enabled=true` | Bisa memutus audio Bluetooth di perangkat tanpa offload. |
| `ro.config.hw_dolby`, `ro.config.hw_dts` | Membuat ROM mengira Dolby/DTS ada; bentrok dengan deteksi Mora. |
| `persist.vendor.audio.limiter.enable=false` | Mematikan pelindung speaker. |
| `persist.vendor.audio.fluence.*`, `ro.vendor.audio.speaker.mic_switch` | Mengubah jalur mikrofon. |
| Volume steps (30/50) | Mora sudah punya opsi 100 langkah. |
| Properti yang juga diatur Mode Mora (`audio.offload.*`, `audio.deep_buffer.media`, standby, buffer) | Mode Musik/Film/Hemat yang menang agar tidak saling timpa. |
| `service.sh` V2 memakai `sp` (perintah tidak ada) | Semua barisnya gagal di modul asli. |
| Membuka tautan Telegram saat instalasi, `sleep` ~40 detik | Tidak perlu. |
| Gain speaker 14 / headphone 3 tetap | Diganti slider 0-10 dengan default 0 (mati). |
