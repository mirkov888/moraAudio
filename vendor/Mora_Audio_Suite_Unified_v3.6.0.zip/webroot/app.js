/* Mora Audio Suite - made by Mora & Claude Code */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const safe = fn => { try { return fn(); } catch (_) { return null; } };

  /* ================================================================
     Root bridge (KernelSU / KernelSU Next / APatch / MMRL WebUI)
     ================================================================ */
  const hasBridge = () => !!(window.ksu && typeof window.ksu.exec === 'function');
  const DEMO = !hasBridge();

  function exec(cmd, timeout = 9000) {
    return new Promise(resolve => {
      if (!hasBridge()) return resolve({ ok: false, out: '', err: 'no-bridge' });
      let done = false;
      const cb = 'mora_cb_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
      const finish = r => { if (done) return; done = true; clearTimeout(t); try { delete window[cb]; } catch (_) {} resolve(r); };
      const t = setTimeout(() => finish({ ok: false, out: '', err: 'timeout' }), timeout);
      window[cb] = (errno, stdout, stderr) => finish({ ok: Number(errno) === 0, out: String(stdout || '').trim(), err: String(stderr || '').trim() });
      try {
        const r = window.ksu.exec(cmd, '{}', cb);
        // Some WebUI hosts return the result directly instead of calling back.
        if (r && typeof r.then === 'function') r.then(v => finish({ ok: true, out: String(v && v.stdout !== undefined ? v.stdout : v || '').trim(), err: '' }), e => finish({ ok: false, out: '', err: String(e) }));
        else if (typeof r === 'string' && r.length) finish({ ok: true, out: r.trim(), err: '' });
      } catch (e) { finish({ ok: false, out: '', err: String(e && e.message || e) }); }
    });
  }

  // Locate this module on KernelSU / Magisk / APatch layouts, then run a script from it.
  const FIND = 'for d in /data/adb/modules/mora_audio_suite /data/adb/ksu/modules/mora_audio_suite /data/adb/ap/modules/mora_audio_suite; do [ -d "$d" ] && break; done; ';
  const runModule = (script, args = '', timeout) => exec(`${FIND}sh "$d/${script}" ${args}`, timeout);

  /* ================================================================
     Log + toast
     ================================================================ */
  const logLines = [];
  function log(msg) {
    const t = new Date().toLocaleTimeString('id-ID', { hour12: false });
    logLines.push(`[${t}] ${msg}`);
    if (logLines.length > 80) logLines.shift();
    const el = $('#console'); if (el) el.textContent = logLines.join('\n');
  }
  function toast(msg, err) {
    const el = document.createElement('div');
    el.className = 'toast' + (err ? ' err' : '');
    el.textContent = msg;
    $('#toasts').appendChild(el);
    setTimeout(() => el.remove(), 2600);
  }

  /* ================================================================
     Status
     ================================================================ */
  const MOCK = {
    is_usb: 1, is_bt: 0, dac_name: 'USB-C DAC (contoh)', sync_mode: 'ASYNC', bt_name: '', bt_codec: '',
    active_route: 'USB DAC (contoh)', sample_rate: '96000 Hz (96 kHz)', bitrate: '24-bit PCM / 4608 kbps (PCM)',
    vol_steps: '100', resampler: '7', ignore_fx: '', spatializer: '', safemedia: 'true', usb_period: '2000',
    platform: 'bengal', arch: 'arm64-v8a', audioserver_pid: '1234', mode: 'audiophile', int_codec: 'true',
    adm_buffering: '6', deep_buffer: 'false', has_tinymix: 1, offload_24bit: 'true', flinger_standby: '200',
    psd_stopband: '179', viper_registered: 1, viper_loaded: 1, viper_lib: 1, android: '16', device: 'Perangkat contoh',
    version: '3.0', cfg_volsteps100: 1, cfg_safevol_off: 1, cfg_spatializer_off: 1, cfg_vollistener_off: 1, cfg_dolby_off: 1,
    cfg_noeffects: 0, cfg_aoc_stop: 1, cfg_guard: 1, cfg_restart_boot: 1, cfg_rysound: 1, rys_mode: 'legacy_xml_runtime_loaded', rys_reason: '', rys_dsp: 0, cfg_usb_period: 'auto',
    nls_installed: 1, nls_volsteps: '100', nls_bitnes: '24', nls_samplerate: '96000', nls_effects: 'part', nls_steps: '9,10',
    conflicts: '', ota_changed: 0, dax_supported: 1, dax_state: 'stock', dax_stock_match: 0,
    bb_installed: 1, cfg_bb_bass: 0, cfg_bb_strength: 600, cfg_bb_loudness: 0, cfg_bb_target: 300, cfg_bb_dp: 0, cfg_bb_gain: 4, fx_enabled: 1, fx_count: 1, fx_list: 'jamesdsp ← jd', fx_safe: '', cfg_fxhub: 1, cfg_fxpath: 1, cfg_yayang_sony: 0, cfg_yayang_v2: 0, cfg_yayang_spk_gain: 0, cfg_yayang_hp_gain: 0, yayang_gain_supported: 1
  };
  let S = null;

  async function loadStatus() {
    if (DEMO) { S = Object.assign({}, MOCK, S && S.mode ? { mode: S.mode } : {}); return S; }
    const r = await runModule('get_audio_status.sh', '', 12000);
    if (!r.out) { log('Status kosong: ' + (r.err || 'tidak ada respons')); toast('Status gagal dimuat: ' + (r.err || 'kosong'), true); return S; }
    const line = r.out.split('\n').reverse().find(l => l.trim().startsWith('{'));
    try { S = JSON.parse(line); }
    catch (e) { log('JSON status tidak valid: ' + e.message); toast('Status tidak valid', true); }
    return S;
  }

  const num = v => { const n = parseInt(String(v).replace(/[^0-9]/g, ''), 10); return Number.isFinite(n) ? n : 0; };

  function parseFormat(s) {
    // The backend prints "48,000 Hz (48 kHz)" (with a comma) only as an idle placeholder.
    const rateStr = String(s.sample_rate || '');
    const idle = rateStr.includes(',') || /Connected/i.test(rateStr);
    const hz = idle ? 0 : num((rateStr.match(/^\s*(\d+)/) || [])[1]);
    const bits = num((String(s.bitrate).match(/(\d+)-bit/) || [])[1]) || 0;
    return { hz, bits, idle };
  }

  function render() {
    if (!S) return;
    const f = parseFormat(S);
    const usb = Number(S.is_usb) === 1, bt = Number(S.is_bt) === 1;
    const jack = /3\.5/.test(S.active_route || '');

    $('#sub-device').textContent = [S.device, S.android ? 'Android ' + S.android : ''].filter(Boolean).join(' · ') || 'Mora Audio Suite';

    // route chip
    const icon = usb ? '#i-usb' : bt ? '#i-bt' : jack ? '#i-jack' : '#i-speaker';
    $('#route-icon').setAttribute('href', icon);
    $('#route-label').textContent = usb ? (S.dac_name || 'USB DAC') : bt ? (S.bt_name || 'Bluetooth') : jack ? 'Jack 3,5 mm' : 'Speaker internal';

    // hero numbers
    if (f.hz) {
      const k = f.hz / 1000;
      $('#hero-rate').textContent = Number.isInteger(k) ? String(k) : k.toFixed(1);
      $('#hero-unit').textContent = 'kHz' + (f.bits ? ' · ' + f.bits + '-bit' : '');
    } else {
      $('#hero-rate').textContent = '—';
      $('#hero-unit').textContent = '';
    }
    let q = 'idle', ql = 'Siaga';
    const codec = String(S.bt_codec || '');
    if (bt && /LDAC|LHDC|aptX Adaptive|aptX HD/i.test(codec)) { q = 'hires'; ql = codec.split(' ')[0] + ' Hi-Res'; }
    else if (f.hz >= 88200 && f.bits >= 24) { q = 'hires'; ql = 'Hi-Res'; }
    else if (f.hz >= 44100) { q = 'cd'; ql = f.bits >= 24 ? '24-bit' : 'CD'; }
    else if (bt && codec) { q = 'cd'; ql = codec.split(' ')[0]; }
    const qb = $('#quality-badge'); qb.dataset.q = q; qb.textContent = ql;

    const subs = [];
    if (usb && S.sync_mode) subs.push(S.sync_mode.replace(/\s*\(.*$/, ''));
    if (bt && codec) subs.push(codec);
    if (f.hz) subs.push(S.bitrate || '');
    $('#hero-sub').textContent = f.hz ? subs.filter(Boolean).join(' · ') : (usb || bt ? 'Terhubung. Putar sesuatu untuk melihat format yang aktif.' : 'Putar musik atau video untuk melihat format yang aktif');

    // signal chain
    const rq = num(S.resampler);
    setNode('res', rq >= 7 ? 'Maks' : rq ? 'Q' + rq : 'Bawaan', rq >= 6 ? 'ok' : '');
    setNode('fx', Number(S.viper_loaded) ? 'Aktif' : Number(S.viper_registered) ? 'Reboot' : 'Tidak ada', Number(S.viper_loaded) ? 'ok' : 'bad');
    setNode('out', usb ? 'USB' : bt ? 'BT' : jack ? 'Jack' : 'Speaker', '');
    setNode('src', f.bits ? f.bits + '-bit' : 'PCM', '');

    // modes
    $$('.mode').forEach(b => b.setAttribute('aria-checked', String(b.dataset.mode === S.mode)));
    renderTips();

    // system
    setCheck('#ck-lib', Number(S.viper_lib) ? 'ok' : 'bad');
    setCheck('#ck-reg', Number(S.viper_registered) ? 'ok' : 'bad');
    setCheck('#ck-load', Number(S.viper_loaded) ? 'ok' : (Number(S.viper_registered) && Number(S.viper_lib) ? 'warn' : 'bad'));
    $('#viper-verdict').innerHTML = viperVerdict();
    renderTuning();

    const yn = v => (v === true || v === 'true' || v === '1') ? 'Aktif' : 'Mati';
    kv('#props', [
      ['Langkah volume', S.vol_steps || '—'],
      ['Kualitas resampler', S.resampler || 'Bawaan'],
      ['Stopband PSD', S.psd_stopband === 'default' ? 'Bawaan' : S.psd_stopband + ' dB'],
      ['Codec HiFi internal', yn(S.int_codec)],
      ['Offload PCM 24-bit', yn(S.offload_24bit)],
      ['Deep buffer', yn(S.deep_buffer)],
      ['Buffer ADM', (S.adm_buffering || '—') + ' ms'],
      ['Standby AudioFlinger', S.flinger_standby === 'default' ? 'Bawaan' : S.flinger_standby + ' ms'],
      ['Bypass safe volume', yn(S.safemedia)],
      ['Periode USB', S.usb_period ? S.usb_period + ' µs' : 'Bawaan'],
      ['Mixer ALSA (tinymix)', Number(S.has_tinymix) ? 'Tersedia' : 'Tidak ada']
    ]);
    kv('#devinfo', [
      ['Perangkat', S.device || '—'],
      ['Platform', S.platform || '—'],
      ['Arsitektur', S.arch || '—'],
      ['Android', S.android || '—'],
      ['PID audioserver', S.audioserver_pid || '—']
    ]);
  }

  function setNode(id, text, state) {
    const n = $('#node-' + id), v = $('#node-' + id + '-v');
    if (v) v.textContent = text;
    if (n) n.dataset.s = state || '';
  }
  function setCheck(sel, s) { const el = $(sel); if (el) el.dataset.s = s; }
  function kv(sel, rows) {
    const el = $(sel); el.textContent = '';
    rows.forEach(([k, v]) => {
      const d = document.createElement('div');
      const a = document.createElement('span'); a.textContent = k;
      const b = document.createElement('span'); b.textContent = v;
      d.append(a, b); el.append(d);
    });
  }
  function viperVerdict() {
    const lib = Number(S.viper_lib), reg = Number(S.viper_registered), ld = Number(S.viper_loaded);
    const why = { not_mounted: 'Root manager tidak me-mount file modul. KernelSU 3.x butuh metamodule (mis. meta-overlayfs); di Hybrid Mount cek blacklist. Tekan <b>Perbaiki driver ViPER</b>.', other_viper: 'Ada modul ViPER lain yang aktif dan bentrok. Nonaktifkan salah satunya lalu reboot.', aidl_hal: 'HAL efek audio perangkat ini AIDL; driver HIDL tidak dimuat. Perlu build ViPER versi AIDL.', ignore_effects: 'Opsi ro.audio.ignore_effects aktif. Tekan <b>Perbaiki driver ViPER</b>.', not_registered: 'ROM tidak memuat konfigurasi ViPER. Tekan <b>Perbaiki driver ViPER</b>.' }[S.viper_reason];
    if (!ld && why) return '<b>Driver belum aktif.</b> ' + why;
    if (ld) return '<b>Driver siap.</b> Buka aplikasi ViPER4Android RE; Driver Status seharusnya menampilkan <i>Normal</i>.';
    if (!lib) return '<b>Library tidak ditemukan.</b> Pasang ulang module ini dan reboot.';
    if (!reg) return '<b>Belum terdaftar di konfigurasi audio.</b> Pasang ulang module, reboot, lalu cek log pemasangan di bawah.';
    return '<b>Sudah terdaftar tetapi belum dimuat.</b> Reboot dulu. Kalau tetap begini, cek SELinux (<code>getenforce</code>) dan log pemasangan. Driver baru terlihat setelah ada audio yang diputar atau aplikasi ViPER dibuka.';
  }


  /* ================================================================
     Tuning tab
     ================================================================ */
  const TOGGLES = [
    ['VOLSTEPS100', 'Volume 100 langkah', 'Slider volume musik jauh lebih halus daripada 15 langkah bawaan.', true],
    ['SAFEVOL_OFF', 'Matikan peringatan volume', 'Menghilangkan batas dan pop-up volume aman saat memakai headphone.', false],
    ['SPATIALIZER_OFF', 'Matikan spatializer', 'Audio spasial Android menambah jitter dan bisa bentrok dengan ViPER.', true],
    ['VOLLISTENER_OFF', 'Matikan volume listener', 'Melepas kompresor ringan milik vendor (Dolby/Qualcomm) pada volume tertentu.', true],
    ['DOLBY_OFF', 'Matikan Dolby bawaan', 'Mencegah Dolby vendor memproses ulang sinyal sebelum ViPER.', true],
    ['AOC_STOP', 'Hentikan AOC (Pixel)', 'Daemon offload Tensor yang menambah jitter. Tidak berpengaruh di perangkat lain.', true],
    ['GUARD', 'Penjaga modul ganda', 'Menonaktifkan NLSound atau Audio Misc terpisah agar tidak bentrok dengan Mora.', false],
    ['RESTART_BOOT', 'Mulai ulang audioserver saat boot', 'Memastikan driver ViPER dimuat dengan benar setelah menyala.', false],
    ['RYSOUND', 'Daftarkan efek RySound', 'Memasang hook RySound di konfigurasi audio. Boot guard mematikan hanya RySound bila boot gagal.', false],
    ['NOEFFECTS', 'Matikan semua efek sistem', 'Hanya untuk tanpa ViPER. Mengaktifkan ini mematikan driver ViPER.', false]
  ];

  const cfgOf = k => Number(S && S['cfg_' + k.toLowerCase()]) === 1;

  function renderTuning() {
    if (!S) return;
    const box = $('#tuning-list'); box.textContent = '';
    const rebootKeys = ['RYSOUND', 'SPATIALIZER_OFF', 'VOLLISTENER_OFF', 'DOLBY_OFF', 'AOC_STOP'];
    TOGGLES.forEach(([key, title, desc]) => {
      const row = document.createElement('div'); row.className = 'tg';
      const tx = document.createElement('div');
      const b = document.createElement('b'); b.textContent = title;
      if (rebootKeys.includes(key)) { const r = document.createElement('i'); r.className = 'rb'; r.textContent = 'reboot'; b.append(r); }
      const d = document.createElement('span'); d.className = 'd'; d.textContent = desc;
      tx.append(b, d);
      const lab = document.createElement('label'); lab.className = 'switch';
      const inp = document.createElement('input'); inp.type = 'checkbox'; inp.checked = cfgOf(key); inp.dataset.key = key;
      inp.setAttribute('aria-label', title);
      const sp = document.createElement('span');
      lab.append(inp, sp); row.append(tx, lab); box.append(row);
      inp.addEventListener('change', () => setCfg(key, inp.checked ? '1' : '0', inp));
    });
    $('#usb-period').value = [...$('#usb-period').options].some(o => o.value === S.cfg_usb_period) ? S.cfg_usb_period : 'auto';

    // notices
    const nb = $('#notices'); nb.textContent = '';
    const add = (cls, html) => { const n = document.createElement('div'); n.className = 'notice ' + cls; n.innerHTML = html; nb.append(n); };
    if (S.conflicts) add('', '<b>Modul ganda terdeteksi:</b> ' + String(S.conflicts).replace(/[<>&]/g, '') + '. Fiturnya sudah ada di Mora. Hapus modul itu dari daftar agar tidak saling menimpa.');
    if (Number(S.ota_changed)) add('', '<b>Sistem baru saja diperbarui.</b> Pasang ulang Mora agar konfigurasi audio sesuai ROM terbaru.');
    if (Number(S.cfg_noeffects)) add('bad', '<b>Efek sistem dimatikan.</b> Driver ViPER tidak akan dimuat selama opsi ini aktif.');

    const RYS = { legacy_xml_runtime_loaded: 'Dimuat di proses audio', legacy_xml_config_active: 'Aktif, menunggu audio diputar', legacy_xml_staged: 'Disiapkan, menunggu reboot',
      quarantined: 'Mode aman (dimatikan otomatis)', disabled: 'Dimatikan', webui_only: 'Hanya pengaturan (hook tidak didukung)',
      legacy_xml_overlay_not_active: 'Overlay belum terbaca', legacy_xml_load_error: 'Gagal dimuat', legacy_xml_config_active_library_missing: 'Library tidak ditemukan' };
    kv('#rys-info', [
      ['Hook audio', RYS[S.rys_mode] || 'Belum diverifikasi'],
      ['DSP RySound', Number(S.rys_dsp) ? 'Menyala' : 'Mati'],
      ...(S.rys_reason ? [['Catatan', S.rys_reason]] : [])
    ]);
    if (S.rys_mode === 'quarantined') add('', '<b>RySound dimatikan otomatis</b> karena boot gagal atau crash di proses audio. ViPER tidak terpengaruh. Buka halaman RySound untuk keluar dari mode aman.');
    renderDax();
    renderBass(); renderYayang(); renderFx();
    const steps = String(S.nls_steps || '').split(',').filter(Boolean);
    const eff = { part: 'Sebagian (aman untuk ViPER)', false: 'Tidak diubah', true: 'Dinonaktifkan' }[S.nls_effects];
    kv('#nls-info', Number(S.nls_installed) ? [
      ['Langkah volume', S.nls_volsteps && S.nls_volsteps !== 'false' ? S.nls_volsteps : 'Bawaan'],
      ['Kedalaman bit', S.nls_bitnes && S.nls_bitnes !== 'false' ? S.nls_bitnes + '-bit' : 'Bawaan'],
      ['Sample rate', S.nls_samplerate && S.nls_samplerate !== 'false' ? S.nls_samplerate + ' Hz' : 'Bawaan'],
      ['Kebijakan efek', eff || 'Tidak diubah'],
      ['Tweak aktif', steps.length ? steps.map(n => '#' + n).join(' ') : 'Tidak ada']
    ] : [['Status', 'NLSound dilewati saat pemasangan']]);
  }

  const BB = [['bass', 'bb-bass', 'BB_BASS', 'check'], ['dp', 'bb-dp', 'BB_DP', 'check'], ['loud', 'bb-loud', 'BB_LOUDNESS', 'check'],
    ['strength', 'bb-strength', 'BB_STRENGTH', 'range', v => v], ['gain', 'bb-gain', 'BB_GAIN', 'range', v => v + ' dB'], ['target', 'bb-target', 'BB_TARGET', 'range', v => v + ' mB']];
  let bbTimer = null;
  function renderBass() {
    const inst = Number(S.bb_installed);
    $('#bb-state').textContent = inst ? '' : 'Aplikasi BassBoost belum aktif. Restart sekali setelah memasang module; pengaturan tetap tersimpan.';
    BB.forEach(([, id, key, type, fmt]) => {
      const el = $('#' + id); const val = Number(S['cfg_' + key.toLowerCase()]);
      if (type === 'check') el.checked = val === 1; else { el.value = val; $('#' + id + '-v').textContent = fmt(val); }
    });
  }
  // ---- banner picker ----
  const BANNERS = Array.from({ length: 16 }, (_, i) => 'b' + String(i).padStart(2, '0'));
  function setBannerCss(url) { document.documentElement.style.setProperty('--banner', 'url("' + url + '")'); }
  function markBanner(name) {
    document.querySelectorAll('#banner-grid button').forEach(b => b.classList.toggle('on', b.dataset.b === name));
  }
  // downscale a picked image to <=900px JPEG so it fits comfortably through the shell
  function shrinkImage(file) {
    return new Promise((resolve, reject) => {
      const img = new Image(), u = URL.createObjectURL(file);
      img.onload = () => {
        const k = Math.min(1, 900 / img.width), c = document.createElement('canvas');
        c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(u);
        resolve(c.toDataURL('image/jpeg', 0.8));
      };
      img.onerror = () => reject(new Error('gambar tidak bisa dibuka'));
      img.src = u;
    });
  }
  async function chooseBanner(name) {
    setBannerCss('banners/' + name + '.jpg'); markBanner(name); curBanner = name; applyAccentFrom('banners/' + name + '.jpg');
    if (DEMO) { toast('Banner diganti (pratinjau)'); return; }
    const r = await runModule('banner_ctl.sh', 'set ' + name);
    toast(/success/.test(r.out || '') ? 'Banner tersimpan' : 'Gagal menyimpan banner', !/success/.test(r.out || ''));
  }
  async function uploadBanner(file) {
    try {
      const dataUrl = await shrinkImage(file);
      setBannerCss(dataUrl); markBanner(''); curBanner = 'custom'; applyAccentFrom(dataUrl);
      if (DEMO) { toast('Banner diganti (pratinjau)'); return; }
      const b64 = dataUrl.split(',')[1], CH = 40000;
      for (let i = 0, n = 0; i < b64.length; i += CH, n++) {
        const r = await runModule('banner_ctl.sh', 'put ' + n + ' ' + b64.slice(i, i + CH), 15000);
        if (!/success/.test(r.out || '')) throw new Error('unggah gagal');
      }
      const r = await runModule('banner_ctl.sh', 'commit');
      if (!/success/.test(r.out || '')) throw new Error('simpan gagal');
      setBannerCss('banner.jpg?t=' + Date.now()); toast('Banner tersimpan');
    } catch (e) { toast('Banner gagal: ' + e.message, true); }
  }
  function bindBanner() {
    const grid = $('#banner-grid'); if (!grid) return;
    BANNERS.forEach(n => {
      const b = document.createElement('button'); b.dataset.b = n; b.setAttribute('aria-label', 'Banner ' + n);
      const im = document.createElement('img'); im.src = 'banners/' + n + '.jpg'; im.loading = 'lazy'; im.alt = '';
      b.appendChild(im); b.addEventListener('click', () => chooseBanner(n)); grid.appendChild(b);
    });
    $('#btn-banner-file').addEventListener('click', () => $('#banner-file').click());
    $('#banner-file').addEventListener('change', e => { const f = e.target.files[0]; if (f) uploadBanner(f); e.target.value = ''; });
    $('#btn-banner-reset').addEventListener('click', async () => {
      setBannerCss('banners/b00.jpg'); markBanner('b00');
      if (!DEMO) await runModule('banner_ctl.sh', 'reset');
      toast('Banner bawaan');
    });
    markBanner('b00'); loadBannerInit();
  }

  // ---- accent colour taken from the banner ----
  const ls = { get: k => { try { return localStorage.getItem(k); } catch (_) { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch (_) {} } };
  function applyAccentFrom(url) {
    if (ls.get('mora_accent') !== '1') { document.documentElement.style.removeProperty('--accent'); document.documentElement.style.removeProperty('--accent-ink'); return; }
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas'); c.width = c.height = 24;
      const g = c.getContext('2d'); g.drawImage(img, 0, 0, 24, 24);
      let d; try { d = g.getImageData(0, 0, 24, 24).data; } catch (_) { return; }
      let sx = 0, sy = 0, w = 0;
      for (let i = 0; i < d.length; i += 4) {
        const r = d[i] / 255, gg = d[i + 1] / 255, b = d[i + 2] / 255, mx = Math.max(r, gg, b), mn = Math.min(r, gg, b), sat = mx - mn;
        if (sat < 0.15 || mx < 0.2) continue;
        let h = mx === r ? ((gg - b) / sat) % 6 : mx === gg ? (b - r) / sat + 2 : (r - gg) / sat + 4; h *= 60; if (h < 0) h += 360;
        sx += Math.cos(h * Math.PI / 180) * sat; sy += Math.sin(h * Math.PI / 180) * sat; w += sat;
      }
      if (!w) return;
      const hue = Math.round((Math.atan2(sy, sx) * 180 / Math.PI + 360) % 360);
      document.documentElement.style.setProperty('--accent', `hsl(${hue} 72% 62%)`);
      document.documentElement.style.setProperty('--accent-ink', '#0b0f14');
    };
    img.src = url;
  }
  let curBanner = 'b00';

  const clipCopy = async txt => {
    try { await navigator.clipboard.writeText(txt); return true; } catch (_) {}
    try { const t = document.createElement('textarea'); t.value = txt; document.body.appendChild(t); t.select(); const ok = document.execCommand('copy'); t.remove(); return ok; } catch (_) { return false; }
  };
  const parseJson = o => { try { return JSON.parse((o || '').trim().split('\n').filter(l => l.startsWith('{')).pop()); } catch (_) { return null; } };
  const esc = x => String(x).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  // ---- setup check ----
  async function runSetup() {
    const box = $('#setup-list'); box.innerHTML = '<p class="muted">Memeriksa…</p>';
    let j;
    if (DEMO) j = { items: [{ id: 'root', title: 'Root manager', status: 'ok', detail: 'KernelSU' }, { id: 'meta', title: 'Metamodule mount', status: 'warn', detail: 'Tidak ada metamodule. Pasang meta-overlayfs jika file modul tidak muncul.' }, { id: 'viper', title: 'Driver ViPER', status: 'ok', detail: 'Aktif' }] };
    else j = parseJson((await runModule('setup_check.sh', '', 20000)).out);
    if (!j) { box.innerHTML = '<p class="muted">Gagal membaca hasil.</p>'; return; }
    box.innerHTML = j.items.map(i => `<div class="it"><i class="dot ${i.status}"></i><div><b>${esc(i.title)}</b><span>${esc(i.detail)}</span></div></div>`).join('');
  }

  // ---- report / monitor / tone ----
  async function copyReport() {
    toast('Menyusun laporan…');
    const r = DEMO ? { out: '== Mora Audio Suite report ==\n(contoh)' } : await runModule('report.sh', '', 25000);
    const out = $('#report-out'); out.hidden = false; out.textContent = r.out || r.err || '(kosong)';
    toast(await clipCopy(r.out || '') ? 'Laporan disalin' : 'Salin manual dari kotak', !r.out);
  }
  async function pollMonitor() {
    if ($('#tab-system').hidden || document.hidden) return;
    let j = DEMO ? { level: 76, status: 'Discharging', bat_temp: 33, max_temp: 41, current_ma: -420 } : parseJson((await runModule('monitor.sh', '', 6000)).out);
    if (!j) return;
    $('#mon-lvl').textContent = j.level + '% ' + (j.status || '');
    $('#mon-bt').textContent = j.bat_temp + ' °C';
    $('#mon-mx').textContent = j.max_temp + ' °C';
    $('#mon-cur').textContent = j.current_ma + ' mA';
  }
  let toneCtx = null;
  function toggleTone() {
    const b = $('#btn-tone');
    if (toneCtx) { toneCtx.close(); toneCtx = null; b.textContent = 'Nada tes'; return; }
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) { toast('Audio web tidak didukung', true); return; }
    toneCtx = new AC(); const o = toneCtx.createOscillator(), g = toneCtx.createGain();
    o.frequency.setValueAtTime(80, toneCtx.currentTime); o.frequency.exponentialRampToValueAtTime(12000, toneCtx.currentTime + 12);
    g.gain.value = 0.12; o.connect(g); g.connect(toneCtx.destination); o.start(); o.stop(toneCtx.currentTime + 12);
    b.textContent = 'Hentikan'; o.onended = () => { if (toneCtx) { toneCtx.close(); toneCtx = null; } b.textContent = 'Nada tes'; };
    toast('Sapuan 80 Hz - 12 kHz, bandingkan sebelum/sesudah efek');
  }

  // ---- backup / update ----
  async function backup(kind) {
    toast(kind === 'export' ? 'Membuat cadangan…' : 'Memulihkan…');
    if (DEMO) { toast('Selesai (pratinjau)'); return; }
    const j = parseJson((await runModule('backup_ctl.sh', kind, 30000)).out);
    toast(j ? j.message : 'Gagal', !j || j.status !== 'success');
    if (j && j.status === 'success' && kind === 'import') { loadBannerInit(); }
  }
  const verNum = v => String(v).replace(/^v/i, '').split(/[.\-]/).map(x => parseInt(x, 10) || 0);
  function newer(a, b) { const x = verNum(a), y = verNum(b); for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; }
  async function checkUpdate() {
    const repo = $('#upd-repo').value.trim(); const out = $('#upd-out');
    if (!/^[\w.-]+\/[\w.-]+$/.test(repo)) { out.textContent = 'Isi dengan format pengguna/repo.'; return; }
    ls.set('mora_repo', repo); out.textContent = 'Memeriksa…';
    try {
      const r = await fetch('https://api.github.com/repos/' + repo + '/releases/latest', { headers: { Accept: 'application/vnd.github+json' } });
      if (!r.ok) throw new Error(r.status === 404 ? 'belum ada rilis' : 'HTTP ' + r.status);
      const d = await r.json(); const cur = (S && S.version) || '0';
      out.innerHTML = newer(d.tag_name, cur) ? 'Versi baru <b>' + esc(d.tag_name) + '</b> tersedia (terpasang ' + esc(cur) + '). <a href="' + esc(d.html_url) + '" target="_blank" rel="noopener">Buka rilis</a>' : 'Sudah terbaru (' + esc(cur) + ').';
    } catch (e) { out.textContent = 'Gagal memeriksa: ' + e.message; }
  }

  // ---- per-app profiles ----
  const QUICK = [['Spotify', 'com.spotify.music', 'audiophile'], ['YT Music', 'com.google.android.apps.youtube.music', 'audiophile'], ['Poweramp', 'com.maxmpz.audioplayer', 'audiophile'], ['YouTube', 'com.google.android.youtube', 'movie'], ['Netflix', 'com.netflix.mediaclient', 'movie']];
  const MODE_NAME = { audiophile: 'Musik', movie: 'Film', power_saver: 'Hemat' };
  let demoProf = { enabled: 0, profiles: [{ pkg: 'com.spotify.music', mode: 'audiophile' }] };
  async function profCall(args) {
    if (DEMO) { const [a, p, m] = args.split(' '); if (a === 'set') { demoProf.profiles = demoProf.profiles.filter(x => x.pkg !== p).concat({ pkg: p, mode: m }); } if (a === 'del') demoProf.profiles = demoProf.profiles.filter(x => x.pkg !== p); if (a === 'enable') demoProf.enabled = Number(p); return demoProf; }
    return parseJson((await runModule('profile_ctl.sh', args, 12000)).out);
  }
  function renderProf(j) {
    if (!j || !j.profiles) return;
    $('#prof-on').checked = !!j.enabled;
    $('#prof-list').innerHTML = j.profiles.map(p => `<div class="it"><div style="flex:1"><b>${esc(p.pkg)}</b><span>${MODE_NAME[p.mode] || p.mode}</span></div><button class="btn ghost small" data-del="${esc(p.pkg)}">Hapus</button></div>`).join('') || '<p class="muted">Belum ada profil.</p>';
    $$('#prof-list [data-del]').forEach(b => b.addEventListener('click', async () => renderProf(await profCall('del ' + b.dataset.del))));
  }
  function bindProfiles() {
    $('#prof-quick').innerHTML = QUICK.map(q => `<button class="btn ghost small" data-pkg="${q[1]}" data-mode="${q[2]}">${q[0]}</button>`).join('');
    $$('#prof-quick button').forEach(b => b.addEventListener('click', async () => { renderProf(await profCall('set ' + b.dataset.pkg + ' ' + b.dataset.mode)); toast('Ditambahkan'); }));
    $('#btn-prof-add').addEventListener('click', async () => {
      const pkg = $('#prof-pkg').value.trim(); if (!/^[A-Za-z0-9._]+$/.test(pkg)) { toast('Nama paket tidak valid', true); return; }
      renderProf(await profCall('set ' + pkg + ' ' + $('#prof-mode').value)); $('#prof-pkg').value = ''; toast('Ditambahkan');
    });
    $('#prof-on').addEventListener('change', async e => { renderProf(await profCall('enable ' + (e.target.checked ? 1 : 0))); toast(e.target.checked ? 'Profil aktif' : 'Profil mati'); });
    profCall('list').then(renderProf);
  }
  function bindExtras() {
    $('#btn-setup').addEventListener('click', runSetup);
    $('#btn-report').addEventListener('click', copyReport);
    $('#btn-tone').addEventListener('click', toggleTone);
    $('#btn-bk-export').addEventListener('click', () => backup('export'));
    $('#btn-bk-import').addEventListener('click', () => backup('import'));
    $('#btn-upd').addEventListener('click', checkUpdate);
    $('#upd-repo').value = ls.get('mora_repo') || '';
    $('#accent-banner').checked = ls.get('mora_accent') === '1';
    $('#accent-banner').addEventListener('change', e => { ls.set('mora_accent', e.target.checked ? '1' : '0'); applyAccentFrom(curBanner === 'custom' ? 'banner.jpg' : 'banners/' + curBanner + '.jpg'); });
    $('#banner-rot').addEventListener('change', async e => {
      const v = e.target.value || curBanner.replace(/^rotate.*$/, 'b00') || 'b00';
      if (!DEMO) await runModule('banner_ctl.sh', 'set ' + v);
      toast(e.target.value ? 'Banner akan berganti otomatis' : 'Banner tetap');
    });
    bindProfiles(); runSetupQuiet();
    setInterval(pollMonitor, 5000); pollMonitor();
  }
  function runSetupQuiet() { /* checklist runs on demand only */ }
  function loadBannerInit() {
    if (DEMO) { applyAccentFrom('banner.jpg'); return; }
    runModule('banner_ctl.sh', 'status').then(r => {
      const j = parseJson(r.out); if (!j) return;
      if (/^rotate_/.test(j.choice)) { $('#banner-rot').value = j.choice; curBanner = 'b00'; setBannerCss('banner.jpg?t=' + Date.now()); }
      else { curBanner = j.choice; markBanner(j.choice); }
      applyAccentFrom('banner.jpg?t=' + Date.now());
    });
  }

  // ---- Yayang profiles ----
  function bindYayang() {
    if (!$('#yy-card')) return;
    const set = (k, v) => DEMO ? Promise.resolve({ out: '{"status":"success"}' }) : runModule('mora_cfg.sh', 'set ' + k + ' ' + v);
    [['yy-sony', 'YAYANG_SONY'], ['yy-v2', 'YAYANG_V2']].forEach(([id, key]) => {
      $('#' + id).addEventListener('change', async e => {
        const r = await set(key, e.target.checked ? 1 : 0);
        toast(/success/.test(r.out || '') ? (e.target.checked ? 'Profil aktif' : 'Profil mati, reboot untuk kembali normal') : 'Gagal menyimpan', !/success/.test(r.out || ''));
      });
    });
    [['yy-spk', 'YAYANG_SPK_GAIN'], ['yy-hp', 'YAYANG_HP_GAIN']].forEach(([id, key]) => {
      const el = $('#' + id), lab = $('#' + id + '-v');
      el.addEventListener('input', () => { lab.textContent = el.value === '0' ? 'mati' : el.value; });
      el.addEventListener('change', async () => { const r = await set(key, el.value); toast(/success/.test(r.out || '') ? 'Tersimpan' : 'Gagal menyimpan', !/success/.test(r.out || '')); });
    });
  }
  function renderYayang() {
    if (!S || !$('#yy-card')) return;
    $('#yy-sony').checked = !!S.cfg_yayang_sony; $('#yy-v2').checked = !!S.cfg_yayang_v2;
    [['yy-spk', S.cfg_yayang_spk_gain], ['yy-hp', S.cfg_yayang_hp_gain]].forEach(([id, v]) => { $('#' + id).value = v || 0; $('#' + id + '-v').textContent = v ? v : 'mati'; });
    $('#yy-gain').hidden = S.yayang_gain_supported === 0;
  }

  // ---- Effect Hub ----
  function bindFx() {
    if (!$('#fx-card')) return;
    const set = (k, v) => DEMO ? Promise.resolve({ out: '{"status":"success"}' }) : runModule('mora_cfg.sh', 'set ' + k + ' ' + v);
    [['fx-sw', 'FXHUB'], ['fp-sw', 'FXPATH']].forEach(([id, key]) => {
      $('#' + id).addEventListener('change', async e => {
        const r = await set(key, e.target.checked ? 1 : 0);
        toast(/success/.test(r.out || '') ? 'Tersimpan, reboot untuk menerapkan' : 'Gagal menyimpan', !/success/.test(r.out || ''));
      });
    });
  }
  function renderFx() {
    if (!S || !$('#fx-card')) return;
    $('#fp-sw').checked = !!S.cfg_fxpath; $('#fx-sw').checked = !!S.cfg_fxhub; 
    const esc = x => String(x || '').replace(/[<>&]/g, '');
    let d = !S.cfg_fxhub ? 'Mati' : S.fx_safe ? 'Dimatikan pengaman boot: ' + esc(S.fx_safe) : S.fx_count > 0 ? S.fx_count + ' efek terdaftar: ' + esc(S.fx_list) : 'Aktif, belum ada library efek dari modul lain';
    $('#fx-d').textContent = d;
  }

  function bindBass() {
    BB.forEach(([, id, key, type, fmt]) => {
      const el = $('#' + id);
      if (type === 'range') el.addEventListener('input', () => { $('#' + id + '-v').textContent = fmt(Number(el.value)); });
      el.addEventListener('change', async () => {
        const v = type === 'check' ? (el.checked ? 1 : 0) : Number(el.value);
        S['cfg_' + key.toLowerCase()] = v; log('Bass ' + key + '=' + v);
        if (DEMO) { toast('Tersimpan (pratinjau)'); return; }
        const r = await runModule('bass_ctl.sh', `set ${key} ${v}`, 8000);
        if (/success/.test(r.out)) toast(Number(S.bb_installed) ? 'Diterapkan' : 'Tersimpan, aktif setelah restart');
        else { toast('Gagal menyimpan', true); log('Bass gagal: ' + (r.out || r.err)); }
      });
    });
  }

  const DAX = [['stock', 'Stock', 'asli ROM'], ['new', 'New', 'tuning baru'], ['bal3', 'Bal 3', 'bawah -3 dB'], ['bal6', 'Bal 6', 'bawah -6 dB'], ['bal9', 'Bal 9', 'bawah -9 dB'], ['bal12', 'Bal 12', 'bawah -12 dB']];
  function renderDax() {
    const sec = $('#dax-sec'); sec.hidden = !Number(S.dax_supported);
    if (sec.hidden) return;
    const g = $('#dax-grid'); g.textContent = '';
    DAX.forEach(([id, name, sub]) => {
      const b = document.createElement('button'); b.type = 'button'; b.setAttribute('role', 'radio');
      b.className = S.dax_state === id ? 'on' : ''; b.setAttribute('aria-checked', String(S.dax_state === id));
      b.append(name); const sm = document.createElement('small'); sm.textContent = sub; b.append(sm);
      b.addEventListener('click', () => setDax(id, b));
      g.append(b);
    });
    $('#dax-note').textContent = Number(S.dax_stock_match)
      ? 'Config asli ROM cocok dengan yang dipakai saat varian dibuat. Balance hanya menurunkan speaker bawah (kanan); atas (kiri) tidak berubah.'
      : 'Config asli ROM-mu berbeda dari yang dipakai membuat varian (dibuat untuk Redmi Note 10 Pro). Varian akan mengganti seluruh tuning Dolby. Cocok untuk uji A/B; kembali ke Stock bila suara terasa aneh.';
  }
  async function setDax(id, btn) {
    if (S.dax_state === id) return;
    btn.classList.add('busy'); log('DAX: ' + id);
    let ok = true;
    if (DEMO) { await new Promise(res => setTimeout(res, 600)); S.dax_state = id; }
    else {
      const r = await runModule('dax_toggle.sh', 'set ' + id, 30000);
      ok = /success/.test(r.out);
      if (ok) S.dax_state = id; else log('DAX gagal: ' + (r.out || r.err));
    }
    toast(ok ? 'Dolby: ' + id + (DEMO ? ' (pratinjau)' : '') : 'Gagal mengganti config Dolby', !ok);
    renderDax();
  }

  async function setCfg(key, val, el) {
    if (el) el.disabled = true;
    log('Konfigurasi ' + key + ' = ' + val);
    let ok = true;
    if (DEMO) { S['cfg_' + key.toLowerCase()] = key === 'USB_PERIOD' ? val : Number(val); }
    else {
      const r = await runModule('mora_cfg.sh', `set ${key} ${val}`, 8000);
      ok = /success/.test(r.out);
      if (ok) S['cfg_' + key.toLowerCase()] = key === 'USB_PERIOD' ? val : Number(val);
    }
    if (el) el.disabled = false;
    if (!ok) { toast('Gagal menyimpan ' + key, true); log('Gagal menyimpan konfigurasi'); }
    else if (key === 'NOEFFECTS' && val === '1') toast('Peringatan: ViPER nonaktif saat ini', true);
    else toast('Tersimpan');
    renderTuning();
  }

  async function applyTuning(btn) {
    btn.classList.add('busy');
    let r;
    if (DEMO) { await new Promise(res => setTimeout(res, 500)); r = { out: '"status":"success"' }; }
    else r = await runModule('mora_cfg.sh', 'apply', 20000);
    btn.classList.remove('busy');
    if (/success/.test(r.out)) { toast('Pengaturan diterapkan'); log('Terapkan: ' + r.out); }
    else { toast('Gagal menerapkan', true); log('Terapkan gagal: ' + (r.err || r.out)); }
    await new Promise(res => setTimeout(res, 800));
    await refresh(true);
  }

  async function runDiag(kind, btn) {
    const out = $('#diag-out'); out.hidden = false; out.textContent = 'Memuat…';
    btn.classList.add('busy'); log('Diagnostik: ' + kind);
    if (DEMO) { await new Promise(res => setTimeout(res, 400)); out.textContent = '(pratinjau) Hasil diagnostik ' + kind + ' tampil di sini pada perangkat.'; btn.classList.remove('busy'); return; }
    const r = await exec(FIND + 'MORA_CLI=1 sh "$d/nlsound_tools.sh" ' + kind + ' 2>&1', 40000);
    btn.classList.remove('busy');
    out.textContent = r.out || r.err || 'Tidak ada keluaran.';
    out.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  /* ================================================================
     Listening modes
     ================================================================ */
  const TIPS = {
    audiophile: ['Matikan EQ dan efek lain di aplikasi pemutar supaya tidak menumpuk dengan ViPER.',
      'Pakai preset Musik di tab Suara; preamp negatif menjaga puncak tidak terpotong.',
      'Untuk DAC USB, atur volume aplikasi tinggi dan kecilkan lewat volume sistem atau DAC.'],
    movie: ['Preset Film Dialog mengangkat 1–4 kHz supaya suara orang lebih jelas.',
      'Di aplikasi streaming, pilih audio stereo/AAC bila surround membuat dialog pelan.',
      'Di Bluetooth, buffer yang lebih besar membantu menjaga sinkron suara dan gambar.'],
    power_saver: ['Cocok untuk pemakaian sehari-hari, podcast, dan video singkat.',
      'Kualitas resampler turun ke menengah, perbedaannya kecil di speaker dan earphone biasa.']
  };
  function renderTips() {
    const m = S && S.mode || 'audiophile';
    $('#tip-title').textContent = m === 'movie' ? 'Saran untuk film' : m === 'power_saver' ? 'Saran hemat daya' : 'Saran untuk musik';
    const ul = $('#tip-list'); ul.textContent = '';
    (TIPS[m] || TIPS.audiophile).forEach(t => { const li = document.createElement('li'); li.textContent = t; ul.append(li); });
  }
  const MODE_LABEL = { audiophile: 'Musik Hi-Res', movie: 'Film & Streaming', power_saver: 'Hemat Daya' };

  async function setMode(mode, btn) {
    if (S && S.mode === mode) return;
    btn.classList.add('busy');
    log('Mengganti mode ke ' + mode);
    if (DEMO) { S.mode = mode; render(); btn.classList.remove('busy'); toast(MODE_LABEL[mode] + ' aktif (pratinjau)'); return; }
    const r = await runModule('set_audio_mode.sh', mode, 15000);
    btn.classList.remove('busy');
    if (/success/.test(r.out)) {
      toast(MODE_LABEL[mode] + ' aktif'); log('Mode diterapkan: ' + r.out);
      await new Promise(res => setTimeout(res, 900));
      await refresh(true);
    } else { toast('Gagal mengganti mode', true); log('Gagal: ' + (r.err || r.out || 'tanpa respons')); }
  }

  async function action(btn, label, cmdFn) {
    btn.classList.add('busy');
    log(label + '…');
    let r;
    if (DEMO) { await new Promise(res => setTimeout(res, 500)); r = { ok: true, out: 'success' }; }
    else r = await cmdFn();
    btn.classList.remove('busy');
    if (r.ok || /success/.test(r.out)) { toast(label + ' selesai'); log(label + ' selesai'); }
    else { toast(label + ' gagal', true); log(label + ' gagal: ' + (r.err || r.out)); }
    await new Promise(res => setTimeout(res, 700));
    await refresh(true);
  }

  /* ================================================================
     EQ
     ================================================================ */
  const FREQS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
  const FLABEL = ['31', '62', '125', '250', '500', '1k', '2k', '4k', '8k', '16k'];
  const FNAME = f => f >= 1000 ? (f / 1000) + ' kHz' : f + ' Hz';

  const PRESETS = [
    { id: 'flat', g: 'musik', name: 'Referensi', route: 'iem_dac', bands: [0,0,0,0,0,0,0,0,0,0],
      note: 'Datar. Titik awal untuk menilai DAC dan IEM tanpa pewarnaan.' },
    { id: 'clarity', g: 'musik', name: 'Jernih Hi-Res', route: 'iem_dac', bands: [1.5,1.5,1,0,0,0.5,0.5,0,-0.5,-0.5],
      note: 'Dasar bass tipis, vokal sedikit maju, treble sedikit diredam agar tidak menumpuk kecerahan. Cocok untuk IEM terang.' },
    { id: 'vocal', g: 'musik', name: 'Vokal', route: 'iem_dac', bands: [-1,-1,-1,0,0.5,1,1.5,1,0.5,0],
      note: 'Bass dikurangi, vokal dan instrumen akustik lebih dekat. Turunkan 2 kHz kalau terdengar sengau.' },
    { id: 'warm', g: 'musik', name: 'Hangat', route: 'iem_dac', bands: [2,2,1.5,0.5,0,0,0,-0.5,-1,-1],
      note: 'Hangat dan rileks. Kalau bass menutupi vokal, turunkan 31–125 Hz dulu.' },
    { id: 'dialog', g: 'film', name: 'Dialog Jernih', route: 'other', bands: [-1,-0.5,0,0,0.5,1.5,2,1.5,0.5,0],
      note: 'Mengangkat 1–4 kHz, area kejelasan suara manusia. Cocok untuk drama, podcast, dan video bicara.' },
    { id: 'cinema', g: 'film', name: 'Sinematik', route: 'other', bands: [3,2.5,1,0,-0.5,0,1,1.5,1,0.5],
      note: 'Dentuman dan efek lebih berisi, detail atas ringan. Pakai volume wajar; bass besar cepat melelahkan.' },
    { id: 'night', g: 'film', name: 'Malam Hari', route: 'other', bands: [-3,-2,-1,0,0.5,1,1.5,1,0.5,0],
      note: 'Bass ditahan agar ledakan tidak mengganggu, dialog tetap terdengar pada volume kecil.' },
    { id: 'spk', g: 'speaker', name: 'Speaker Aman', route: 'phone_speaker', bands: [-6,-4,-2,0,0,0.5,1,1,0,0],
      note: 'Speaker HP tidak bisa memainkan sub-bass. Memangkasnya mengurangi distorsi dan membuat volume lebih bersih.' },
    { id: 'spk-voice', g: 'speaker', name: 'Speaker Vokal', route: 'phone_speaker', bands: [-6,-5,-3,-1,0,1,2,1.5,0.5,0],
      note: 'Untuk video dan panggilan lewat speaker: suara bicara lebih jelas, tanpa bass yang dipaksakan.' }
  ];

  const RECIPES = {
    musik: [
      ['on', 'Nyalakan', 'Equalizer (angka dari grafik) · Master limiter · ViPER Clarity tingkat rendah mode Natural · Convolver/DDC khusus IEM bila punya.'],
      ['off', 'Matikan', 'Surround, Reverb, Tube, Playback gain control, FET compressor, Dynamic system, Bass tambahan.']
    ],
    film: [
      ['on', 'Nyalakan', 'Equalizer (preset film) · Master limiter · ViPER Clarity Natural untuk dialog · Field/Differential Surround tingkat kecil jika ingin ruang lebih luas di headphone.'],
      ['off', 'Hindari', 'Reverb dan Dynamic system (membuat dialog berdengung), Playback gain control bila dialog terasa naik turun.']
    ],
    speaker: [
      ['on', 'Nyalakan', 'Equalizer (preset speaker) · Master limiter · Speaker Optimization.'],
      ['off', 'Matikan', 'Bass tambahan dan Convolver untuk IEM. Jangan pakai preset IEM di speaker.']
    ]
  };

  const eq = { bands: PRESETS[1].bands.slice(), preamp: -2.5, auto: true, sel: 3, preset: 'clarity', group: 'musik', name: 'Jernih Hi-Res', route: 'iem_dac' };
  const clampDb = v => Math.max(-12, Math.min(12, Math.round(v * 2) / 2));
  const fmt = v => (v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(v).toFixed(1).replace('.0', '') + ' dB';
  const autoHead = () => { const m = Math.max(0, ...eq.bands); return m <= 0 ? 0 : -Math.min(12, Math.round((m + 1) * 2) / 2); };

  // geometry
  const W = 340, H = 200, PL = 24, PR = 10, PT = 10, PB = 22;
  const PW = W - PL - PR, PH = H - PT - PB;
  const bx = i => PL + 12 + (PW - 24) * i / 9;
  const by = v => PT + (12 - v) / 24 * PH;
  const NS = 'http://www.w3.org/2000/svg';
  const mk = (tag, attrs, parent) => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); if (parent) parent.appendChild(e); return e; };

  function curvePath() {
    const p = eq.bands.map((v, i) => [bx(i), by(v)]);
    let d = `M${p[0][0]},${p[0][1]}`;
    for (let i = 0; i < p.length - 1; i++) {
      const p0 = p[i - 1] || p[i], p1 = p[i], p2 = p[i + 1], p3 = p[i + 2] || p2;
      const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
      const c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
      d += ` C${c1[0]},${c1[1]} ${c2[0]},${c2[1]} ${p2[0]},${p2[1]}`;
    }
    return d;
  }

  function drawEQ() {
    const svg = $('#eq'); svg.textContent = '';
    const defs = mk('defs', {}, svg);
    const lg = mk('linearGradient', { id: 'eqfill', x1: 0, y1: 0, x2: 0, y2: 1 }, defs);
    mk('stop', { offset: '0', 'stop-color': 'var(--accent)', 'stop-opacity': '.28' }, lg);
    mk('stop', { offset: '1', 'stop-color': 'var(--accent)', 'stop-opacity': '0' }, lg);
    [-12, -6, 0, 6, 12].forEach(v => {
      mk('line', { x1: PL, x2: W - PR, y1: by(v), y2: by(v), class: v === 0 ? 'zero' : 'grid' }, svg);
      const t = mk('text', { x: PL - 4, y: by(v) + 3, 'text-anchor': 'end' }, svg); t.textContent = v > 0 ? '+' + v : String(v);
    });
    FLABEL.forEach((l, i) => {
      const t = mk('text', { x: bx(i), y: H - 6, 'text-anchor': 'middle' }, svg); t.textContent = l;
    });
    const d = curvePath();
    mk('path', { d: d + ` L${bx(9)},${by(0)} L${bx(0)},${by(0)} Z`, fill: 'url(#eqfill)', stroke: 'none' }, svg);
    mk('path', { d, class: 'curve' }, svg);
    mk('line', { x1: bx(eq.sel), x2: bx(eq.sel), y1: PT, y2: PT + PH, class: 'sel-line' }, svg);
    eq.bands.forEach((v, i) => mk('circle', { cx: bx(i), cy: by(v), r: i === eq.sel ? 6 : 4.2, class: 'bn' + (i === eq.sel ? ' sel' : '') }, svg));
    renderEQMeta();
  }

  function renderEQMeta() {
    if (eq.auto) eq.preamp = autoHead();
    $('#eq-name').textContent = eq.name;
    const p = PRESETS.find(x => x.id === eq.preset);
    $('#eq-note').textContent = p ? p.note : 'Profil kustom. Atur band sesuai selera dan rekaman.';
    $('#band-hz').textContent = FNAME(FREQS[eq.sel]);
    $('#band-db').textContent = fmt(eq.bands[eq.sel]);
    $('#preamp').value = eq.preamp; $('#preamp').disabled = eq.auto;
    $('#preamp-v').textContent = fmt(eq.preamp);
    $('#auto-head').checked = eq.auto;
    const t = $('#eq-table'); t.textContent = '';
    eq.bands.forEach((v, i) => {
      const d = document.createElement('div');
      const s = document.createElement('small'); s.textContent = FNAME(FREQS[i]);
      const b = document.createElement('b'); b.textContent = fmt(v).replace(' dB', ''); b.className = v > 0 ? 'pos' : v < 0 ? 'neg' : '';
      d.append(s, b); t.append(d);
    });
    const d = document.createElement('div'); const s = document.createElement('small'); s.textContent = 'Preamp';
    const b = document.createElement('b'); b.textContent = fmt(eq.preamp).replace(' dB', ''); d.append(s, b); t.append(d);
    renderRecipe();
  }

  function renderRecipe() {
    const g = (PRESETS.find(x => x.id === eq.preset) || { g: eq.group }).g;
    const box = $('#recipe'); box.textContent = '';
    RECIPES[g].forEach(([cls, title, body]) => {
      const d = document.createElement('div'); d.className = cls;
      const b = document.createElement('b'); b.textContent = title;
      const s = document.createElement('span'); s.textContent = body;
      d.append(b, s); box.append(d);
    });
  }

  function setBand(i, v) {
    eq.bands[i] = clampDb(v);
    if (eq.preset !== 'custom') { eq.preset = 'custom'; eq.name = eq.name + ' (diubah)'; }
    drawEQ(); markChip();
  }

  function loadPreset(id) {
    const p = PRESETS.find(x => x.id === id); if (!p) return;
    eq.bands = p.bands.slice(); eq.preset = id; eq.name = p.name; eq.route = p.route; eq.group = p.g; eq.auto = true;
    drawEQ(); markChip();
  }

  function renderChips() {
    const box = $('#preset-chips'); box.textContent = '';
    PRESETS.filter(p => p.g === eq.group).forEach(p => {
      const b = document.createElement('button'); b.className = 'chip-btn'; b.textContent = p.name; b.dataset.id = p.id;
      b.addEventListener('click', () => loadPreset(p.id));
      box.append(b);
    });
    $$('#preset-groups button').forEach(b => b.classList.toggle('on', b.dataset.group === eq.group));
    markChip();
  }
  function markChip() { $$('#preset-chips .chip-btn').forEach(b => b.classList.toggle('on', b.dataset.id === eq.preset)); }

  function bindEQ() {
    const svg = $('#eq');
    let drag = false;
    const valFromY = clientY => {
      const r = svg.getBoundingClientRect();
      const y = (clientY - r.top) / r.height * H;
      return clampDb(12 - (y - PT) / PH * 24);
    };
    const nearest = clientX => {
      const r = svg.getBoundingClientRect();
      const x = (clientX - r.left) / r.width * W;
      let best = 0, bd = 1e9;
      for (let i = 0; i < 10; i++) { const dd = Math.abs(bx(i) - x); if (dd < bd) { bd = dd; best = i; } }
      return best;
    };
    svg.addEventListener('pointerdown', e => {
      drag = true; svg.setPointerCapture(e.pointerId);
      eq.sel = nearest(e.clientX); setBand(eq.sel, valFromY(e.clientY));
    });
    svg.addEventListener('pointermove', e => { if (drag) setBand(eq.sel, valFromY(e.clientY)); });
    const end = () => { drag = false; };
    svg.addEventListener('pointerup', end); svg.addEventListener('pointercancel', end);

    $('#band-minus').addEventListener('click', () => setBand(eq.sel, eq.bands[eq.sel] - 0.5));
    $('#band-plus').addEventListener('click', () => setBand(eq.sel, eq.bands[eq.sel] + 0.5));
    $('#eq-reset').addEventListener('click', () => loadPreset('flat'));
    $('#preamp').addEventListener('input', e => { eq.preamp = Number(e.target.value); $('#preamp-v').textContent = fmt(eq.preamp); });
    $('#auto-head').addEventListener('change', e => { eq.auto = e.target.checked; renderEQMeta(); });
    $$('#preset-groups button').forEach(b => b.addEventListener('click', () => { eq.group = b.dataset.group; renderChips(); }));

    $('#btn-copy').addEventListener('click', copyNumbers);
    $('#btn-save').addEventListener('click', saveToModule);
    $('#btn-export').addEventListener('click', exportJSON);
    $('#btn-import').addEventListener('click', () => $('#import-file').click());
    $('#import-file').addEventListener('change', e => { const f = e.target.files && e.target.files[0]; if (f) importJSON(f); e.target.value = ''; });
  }

  const profile = () => ({
    schema: 'mora-audio-preset', schemaVersion: 2, name: eq.name.slice(0, 48), route: eq.route,
    freqs: FREQS, bands: eq.bands.slice(), preamp: eq.preamp, updatedAt: new Date().toISOString()
  });

  async function copyNumbers() {
    const txt = `${eq.name}\n` + eq.bands.map((v, i) => `${FNAME(FREQS[i]).padEnd(8)} ${fmt(v)}`).join('\n') + `\nPreamp   ${fmt(eq.preamp)}`;
    try { await navigator.clipboard.writeText(txt); toast('Angka EQ disalin'); }
    catch (_) {
      const ta = document.createElement('textarea'); ta.value = txt; document.body.appendChild(ta); ta.select();
      const ok = safe(() => document.execCommand('copy')); ta.remove();
      toast(ok ? 'Angka EQ disalin' : 'Salin manual dari tabel di bawah', !ok);
    }
  }
  async function saveToModule() {
    const bytes = new TextEncoder().encode(JSON.stringify(profile(), null, 2));
    let bin = ''; bytes.forEach(b => bin += String.fromCharCode(b));
    const b64 = btoa(bin);
    if (DEMO) { toast('Disimpan (pratinjau)'); return; }
    const r = await exec(`mkdir -p /data/adb/mora_audio_suite && printf '%s' '${b64}' | base64 -d > /data/adb/mora_audio_suite/active_preset.json && echo SAVED`);
    if (r.out.includes('SAVED')) { toast('Profil disimpan ke module'); log('Profil disimpan: /data/adb/mora_audio_suite/active_preset.json'); }
    else { toast('Gagal menyimpan. Gunakan Ekspor.', true); log('Simpan gagal: ' + (r.err || r.out)); }
  }
  function exportJSON() {
    const blob = new Blob([JSON.stringify(profile(), null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url;
    a.download = (eq.name || 'mora-preset').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '.json';
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast('Profil diekspor');
  }
  function importJSON(file) {
    const fr = new FileReader();
    fr.onload = () => {
      try {
        const p = JSON.parse(String(fr.result));
        if (p.schema !== 'mora-audio-preset') throw new Error('Bukan file preset Mora');
        let bands;
        if (Array.isArray(p.bands) && p.bands.length === 10) bands = p.bands.map(Number);
        else if (['bass', 'mids', 'treble'].every(k => Number.isFinite(Number(p[k])))) {
          // v1 files had three broad targets; spread them over the 10 bands.
          const b = Number(p.bass), m = Number(p.mids), t = Number(p.treble);
          bands = [b, b, b, b / 2, m / 2, m, m, t, t, t];
        } else throw new Error('Data band tidak lengkap');
        if (bands.some(v => !Number.isFinite(v))) throw new Error('Nilai band tidak valid');
        eq.bands = bands.map(clampDb); eq.name = String(p.name || 'Profil impor').slice(0, 48);
        eq.route = ['iem_dac', 'phone_speaker', 'other'].includes(p.route) ? p.route : 'other';
        eq.preset = 'custom'; eq.auto = !Number.isFinite(Number(p.preamp));
        if (!eq.auto) eq.preamp = Math.max(-12, Math.min(0, Number(p.preamp)));
        drawEQ(); markChip(); toast('Profil diimpor');
      } catch (e) { toast('Impor gagal: ' + e.message, true); }
    };
    fr.readAsText(file);
  }

  /* ================================================================
     Tabs, refresh, wiring
     ================================================================ */
  function showTab(name) {
    $$('.tab').forEach(t => { t.hidden = t.dataset.tab !== name; });
    $$('.tabbar button').forEach(b => b.classList.toggle('on', b.dataset.tab === name));
    safe(() => localStorage.setItem('mora_tab', name));
    window.scrollTo({ top: 0 });
  }

  let refreshing = false;
  async function refresh(quiet) {
    if (refreshing) return; refreshing = true;
    const b = $('#btn-refresh'); b.classList.add('spin');
    await loadStatus(); render();
    b.classList.remove('spin'); refreshing = false;
    if (!quiet) toast('Status diperbarui');
  }

  document.addEventListener('DOMContentLoaded', () => {
    if (DEMO) $('#demo-banner').hidden = false;
    $$('.tabbar button').forEach(b => b.addEventListener('click', () => showTab(b.dataset.tab)));
    $$('[data-goto]').forEach(b => b.addEventListener('click', () => showTab(b.dataset.goto)));
    $$('.mode').forEach(b => b.addEventListener('click', () => setMode(b.dataset.mode, b)));
    $('#btn-refresh').addEventListener('click', () => refresh(false));

    const restart = () => exec('setprop ctl.restart audioserver');
    $('#btn-restart').addEventListener('click', e => action(e.currentTarget, 'Mulai ulang audio', restart));
    $('#act-restart').addEventListener('click', e => action(e.currentTarget, 'Mulai ulang audio', restart));
    $('#act-volume').addEventListener('click', e => action(e.currentTarget, 'Langkah volume 100', () => exec('settings put system volume_steps_music 100 && echo success')));
    $('#act-alsa').addEventListener('click', e => action(e.currentTarget, 'Kalibrasi gain ALSA', () => runModule('set_audio_mode.sh', 'tinymix_only', 8000)));

    $('#btn-viper-fix').addEventListener('click', async e => {
      const btn = e.currentTarget; btn.classList.add('busy'); log('Perbaiki driver ViPER…');
      let r;
      if (DEMO) { await new Promise(res => setTimeout(res, 600)); r = { ok: true, out: '{"before":"not_mounted","after":"ok","repairs":3,"hint":"Driver aktif. Buka ViPER4Android lalu putar musik."}' }; }
      else r = await runModule('viper_fix.sh', 'fix', 30000);
      btn.classList.remove('busy');
      let j = null; try { j = JSON.parse((r.out || '').trim().split('\n').pop()); } catch (_) {}
      if (j) {
        $('#viper-verdict').innerHTML = '<b>' + (j.after === 'ok' ? 'Driver aktif.' : 'Belum aktif (' + j.after + ').') + '</b> ' + j.hint;
        toast(j.after === 'ok' ? 'Driver ViPER aktif' : 'Perlu langkah lanjut', j.after !== 'ok'); log('ViPER: ' + j.before + ' → ' + j.after);
        if (!DEMO) refresh(true);
      } else { toast('Perbaikan gagal', true); log('viper_fix: ' + (r.err || r.out)); }
    });

    $('#btn-viper-log').addEventListener('click', async () => {
      const el = $('#viper-log');
      if (!el.hidden) { el.hidden = true; return; }
      el.hidden = false; el.textContent = 'Memuat…';
      if (DEMO) { el.textContent = '[12:00:01] install: NLSound preset = recommended\n[12:00:02] installed v3.0; ViPER files=3; USB libs=2'; return; }
      const r = await exec(FIND + 'tail -n 40 /data/adb/mora_audio_suite.log 2>&1; echo; echo "SELinux: $(getenforce 2>&1)"; echo; echo "Diagnosis:"; sh "$d/viper_status.sh" 2>&1', 15000);
      el.textContent = r.out || 'Log belum ada. Reboot setelah memasang module.';
    });

    bindBass();
    bindYayang(); bindFx();
    bindBanner();
    bindExtras();
    $('#usb-period').addEventListener('change', e => setCfg('USB_PERIOD', e.target.value, e.target));
    $('#btn-apply').addEventListener('click', e => applyTuning(e.currentTarget));
    $$('[data-diag]').forEach(b => b.addEventListener('click', () => runDiag(b.dataset.diag, b)));

    bindEQ(); renderChips(); drawEQ();
    const last = safe(() => localStorage.getItem('mora_tab'));
    showTab(['listen', 'sound', 'tuning', 'system'].includes(last) ? last : 'listen');
    log(DEMO ? 'Mode pratinjau (tanpa jembatan root)' : 'Jembatan root terdeteksi');
    refresh(true);
  });
})();
