#!/system/bin/sh
# Mora Audio Suite - made by Mora & Claude Code
# Prints a JSON diagnosis of the ViPER (RE) driver chain for the WebUI.
export PATH="/system/bin:/system/xbin:/vendor/bin:$PATH"
MODDIR="${0%/*}"
. "$MODDIR/lib/mora_lib.sh"
reason="$(v4a_reason "$MODDIR")"
UUID=90380da3-8536-4744-a6a3-5731970e640f

mod64=false; mod32=false
for p in "$MODDIR/system/vendor/lib64/soundfx" "$MODDIR/vendor/lib64/soundfx"; do [ -s "$p/libv4a_re.so" ] && mod64=true; done
for p in "$MODDIR/system/vendor/lib/soundfx" "$MODDIR/vendor/lib/soundfx"; do [ -s "$p/libv4a_re.so" ] && mod32=true; done
[ -s /vendor/lib64/soundfx/libv4a_re.so ] && live64=true || live64=false
[ -s /vendor/lib/soundfx/libv4a_re.so ] && live32=true || live32=false
ctx="$(ls -Z /vendor/lib64/soundfx/libv4a_re.so 2>/dev/null | cut -d' ' -f1)"
[ -z "$ctx" ] && ctx="$(ls -Z /vendor/lib/soundfx/libv4a_re.so 2>/dev/null | cut -d' ' -f1)"

total=0; reg=0
for f in $(find /odm/etc /vendor/etc /system/etc /product/etc -type f \( -name 'audio_effects*.xml' -o -name 'audio_effects*.conf' \) 2>/dev/null); do
    total=$((total+1))
    grep -q 'v4a_standard_re' "$f" 2>/dev/null && reg=$((reg+1))
done

engine=false
if timeout 3 dumpsys media.audio_flinger 2>/dev/null | grep -qi "$UUID"; then engine=true
elif timeout 3 dumpsys media.audio_policy 2>/dev/null | grep -qiE "v4a_standard_re|$UUID"; then engine=true; fi

app="$(pm list packages 2>/dev/null | grep -iE 'viper|v4a' | head -n 1 | sed 's/package://' | tr -d '\r\n"\\')"
sel="$(getenforce 2>/dev/null)"
avc="$(dmesg 2>/dev/null | grep -ciE 'avc.*(v4a|soundfx)')"
case "$avc" in ''|*[!0-9]*) avc=0 ;; esac
sdk="$(getprop ro.build.version.sdk)"
rel="$(getprop ro.build.version.release)"
rom="$(getprop ro.build.display.id | tr -d '"\\\r\n')"
mod="$(grep '^version=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2 | tr -d '\r')"

printf '{"mod64":%s,"mod32":%s,"live64":%s,"live32":%s,"ctx":"%s","cfg_total":%s,"cfg_reg":%s,"engine":%s,"app":"%s","selinux":"%s","avc":%s,"sdk":"%s","android":"%s","rom":"%s","version":"%s","reason":"%s"}\n' \
  "$mod64" "$mod32" "$live64" "$live32" "$ctx" "$total" "$reg" "$engine" "$app" "$sel" "$avc" "$sdk" "$rel" "$rom" "$mod" "$reason"
